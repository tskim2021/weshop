# Talmoschool Shop source package

This package contains the Talmoschool Shop application source, public assets, database schema definition, and migration tooling configuration.

## Intentionally excluded

- Database records and seed data
- SQL migration files
- `node_modules` and generated build output
- External database import/sync scripts and deployment helpers
- `.env` files and secrets

## Local setup

1. Install Node.js and pnpm.
2. Run `pnpm install` from the workspace root (or install the dependencies listed in `package.json`).
3. Copy `.env.example` to `.env` and fill in your own database connection and session secret.
4. Run `pnpm run dev` for development or `pnpm run build && pnpm run start` for production.

A database is required to run the application; no database contents are included in this package.
