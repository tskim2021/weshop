import { drizzle } from "drizzle-orm/mysql2";
import { sql } from "drizzle-orm";
import { categories, products } from "./drizzle/schema";
import * as fs from "fs";
import { fileURLToPath } from "url";
const __dirname = fileURLToPath(new URL(".", import.meta.url));

interface ScrapedProduct {
  category: string;
  itemId: string;
  title: string;
  subtitle: string;
  price: number;
  originalPrice: number | null;
  discount: number | null;
  imageUrl: string;
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9가-힣\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .trim();
}

async function seed() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    console.error("DATABASE_URL is required");
    process.exit(1);
  }

  const db = drizzle(connectionString);

  console.log("Loading product data...");
  const rawData = fs.readFileSync(new URL("seed-data.json", import.meta.url), "utf-8");
  const scrapedProducts: ScrapedProduct[] = JSON.parse(rawData);
  console.log(`Loaded ${scrapedProducts.length} products`);

  console.log("Clearing existing data...");
  await db.execute(sql`DELETE FROM "orderItems"`);
  await db.execute(sql`DELETE FROM "orders"`);
  await db.execute(sql`DELETE FROM "cartItems"`);
  await db.execute(sql`DELETE FROM "wishlistItems"`);
  await db.execute(sql`DELETE FROM "priceAlerts"`);
  await db.execute(sql`DELETE FROM "restockAlerts"`);
  await db.execute(sql`DELETE FROM "productOptions"`);
  await db.execute(sql`DELETE FROM "products"`);
  await db.execute(sql`DELETE FROM "categories"`);
  console.log("Existing data cleared.");

  console.log("Inserting categories...");
  const categoryMap: Record<string, number> = {};
  const categoryData = [
    { name: "탈모헤어", slug: "hair-loss", description: "탈모 치료 및 헤어케어 제품", sortOrder: 1 },
    { name: "성기능", slug: "sexual-health", description: "성기능 개선 제품", sortOrder: 2 },
    { name: "피부미용", slug: "skin-beauty", description: "피부미용 및 스킨케어 제품", sortOrder: 3 },
    { name: "다이어트", slug: "diet", description: "다이어트 및 체중관리 제품", sortOrder: 4 },
  ];

  for (const cat of categoryData) {
    const [{ id }] = await db.insert(categories).values({
      name: cat.name,
      slug: cat.slug,
      description: cat.description,
      sortOrder: cat.sortOrder,
      isActive: 1,
    }).$returningId();
    categoryMap[cat.name] = id;
    console.log(`  Category: ${cat.name} (ID: ${id})`);
  }

  console.log("Inserting products...");
  const usedSlugs = new Set<string>();
  let inserted = 0;
  let skipped = 0;

  for (const sp of scrapedProducts) {
    const catId = categoryMap[sp.category];
    if (!catId) {
      console.warn(`  Skipping: unknown category "${sp.category}" for "${sp.title}"`);
      skipped++;
      continue;
    }

    let baseSlug = slugify(sp.title) || `product-${sp.itemId}`;
    if (baseSlug.length > 200) baseSlug = baseSlug.slice(0, 200);
    let slug = baseSlug;
    let suffix = 1;
    while (usedSlugs.has(slug)) {
      slug = `${baseSlug}-${suffix++}`;
    }
    usedSlugs.add(slug);

    const salePrice = sp.originalPrice && sp.originalPrice > sp.price ? sp.price : null;
    const price = sp.originalPrice && sp.originalPrice > sp.price ? sp.originalPrice : sp.price;

    try {
      await db.insert(products).values({
        categoryId: catId,
        name: sp.title,
        slug,
        description: sp.subtitle || sp.title,
        content: sp.subtitle || null,
        price,
        salePrice,
        stock: 999,
        images: [sp.imageUrl],
        thumbnail: sp.imageUrl,
        status: "active",
        isFeatured: 0,
        isNew: 0,
        isBest: 0,
        viewCount: Math.floor(Math.random() * 500),
        reviewCount: 0,
        pointRate: 1,
        hashtags: [],
      });
      inserted++;
    } catch (err: any) {
      console.warn(`  Failed to insert "${sp.title}": ${err.message}`);
      skipped++;
    }
  }

  console.log(`\nSeed complete: ${inserted} products inserted, ${skipped} skipped.`);
  console.log("Categories:", Object.entries(categoryMap).map(([k, v]) => `${k}=${v}`).join(", "));
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
