/**
 * 상품 이미지 다중 업로드 및 갤러리 관련 테스트
 */

import { describe, it, expect } from "vitest";

describe("상품 이미지 배열 처리", () => {
  it("images 배열이 없으면 thumbnail을 단일 이미지로 사용", () => {
    const product = { images: null, thumbnail: "https://example.com/thumb.jpg" };
    const images = product.images ?? (product.thumbnail ? [product.thumbnail] : []);
    expect(images).toEqual(["https://example.com/thumb.jpg"]);
  });

  it("images 배열이 있으면 그대로 사용", () => {
    const product = {
      images: ["https://example.com/1.jpg", "https://example.com/2.jpg", "https://example.com/3.jpg"],
      thumbnail: "https://example.com/thumb.jpg",
    };
    const images = product.images ?? (product.thumbnail ? [product.thumbnail] : []);
    expect(images).toHaveLength(3);
    expect(images[0]).toBe("https://example.com/1.jpg");
  });

  it("images와 thumbnail 모두 없으면 빈 배열", () => {
    const product = { images: null, thumbnail: null };
    const images = product.images ?? (product.thumbnail ? [product.thumbnail] : []);
    expect(images).toEqual([]);
  });

  it("빈 images 배열은 빈 배열 유지", () => {
    const product = { images: [], thumbnail: "https://example.com/thumb.jpg" };
    const images = product.images.length > 0 ? product.images : (product.thumbnail ? [product.thumbnail] : []);
    expect(images).toEqual(["https://example.com/thumb.jpg"]);
  });
});

describe("thumbnail 자동 동기화", () => {
  it("images[0]이 thumbnail로 설정됨", () => {
    const images = ["https://example.com/main.jpg", "https://example.com/sub.jpg"];
    const thumbnail = images.length > 0 ? images[0] : "";
    expect(thumbnail).toBe("https://example.com/main.jpg");
  });

  it("images가 비어있으면 기존 thumbnail 유지", () => {
    const images: string[] = [];
    const existingThumbnail = "https://example.com/old-thumb.jpg";
    const thumbnail = images.length > 0 ? images[0] : existingThumbnail;
    expect(thumbnail).toBe("https://example.com/old-thumb.jpg");
  });

  it("이미지 순서 변경 시 thumbnail도 변경", () => {
    const images = ["https://example.com/a.jpg", "https://example.com/b.jpg"];
    // 순서 변경: b를 첫 번째로
    const reordered = [images[1], images[0]];
    const thumbnail = reordered[0];
    expect(thumbnail).toBe("https://example.com/b.jpg");
  });
});

describe("이미지 순서 변경 (드래그앤드롭)", () => {
  function moveImage(images: string[], fromIdx: number, toIdx: number): string[] {
    if (toIdx < 0 || toIdx >= images.length) return images;
    const newImages = [...images];
    const [moved] = newImages.splice(fromIdx, 1);
    newImages.splice(toIdx, 0, moved);
    return newImages;
  }

  it("첫 번째 이미지를 두 번째로 이동", () => {
    const images = ["a.jpg", "b.jpg", "c.jpg"];
    const result = moveImage(images, 0, 1);
    expect(result).toEqual(["b.jpg", "a.jpg", "c.jpg"]);
  });

  it("마지막 이미지를 첫 번째로 이동", () => {
    const images = ["a.jpg", "b.jpg", "c.jpg"];
    const result = moveImage(images, 2, 0);
    expect(result).toEqual(["c.jpg", "a.jpg", "b.jpg"]);
  });

  it("범위 밖 인덱스는 원본 유지", () => {
    const images = ["a.jpg", "b.jpg"];
    const result = moveImage(images, 0, -1);
    expect(result).toEqual(["a.jpg", "b.jpg"]);
  });

  it("같은 위치로 이동하면 변경 없음", () => {
    const images = ["a.jpg", "b.jpg", "c.jpg"];
    const result = moveImage(images, 1, 1);
    // splice(1,1) then splice(1,0,item) = same position
    expect(result).toEqual(["a.jpg", "b.jpg", "c.jpg"]);
  });
});

describe("이미지 삭제", () => {
  it("특정 인덱스 이미지 삭제", () => {
    const images = ["a.jpg", "b.jpg", "c.jpg"];
    const result = images.filter((_, i) => i !== 1);
    expect(result).toEqual(["a.jpg", "c.jpg"]);
  });

  it("첫 번째(대표) 이미지 삭제 시 두 번째가 대표로", () => {
    const images = ["a.jpg", "b.jpg", "c.jpg"];
    const result = images.filter((_, i) => i !== 0);
    expect(result[0]).toBe("b.jpg");
  });

  it("마지막 이미지 삭제 시 빈 배열", () => {
    const images = ["a.jpg"];
    const result = images.filter((_, i) => i !== 0);
    expect(result).toEqual([]);
  });
});

describe("이미지 파일 유효성 검증", () => {
  function validateImageFile(file: { type: string; size: number }): { valid: boolean; error?: string } {
    if (!file.type.startsWith("image/")) return { valid: false, error: "이미지 파일만 업로드 가능합니다." };
    if (file.size > 5 * 1024 * 1024) return { valid: false, error: "파일 크기는 5MB 이하여야 합니다." };
    return { valid: true };
  }

  it("유효한 이미지 파일", () => {
    expect(validateImageFile({ type: "image/jpeg", size: 1024 * 1024 })).toEqual({ valid: true });
    expect(validateImageFile({ type: "image/png", size: 2 * 1024 * 1024 })).toEqual({ valid: true });
    expect(validateImageFile({ type: "image/webp", size: 100 })).toEqual({ valid: true });
  });

  it("이미지가 아닌 파일 거부", () => {
    const result = validateImageFile({ type: "application/pdf", size: 1024 });
    expect(result.valid).toBe(false);
    expect(result.error).toContain("이미지 파일만");
  });

  it("5MB 초과 파일 거부", () => {
    const result = validateImageFile({ type: "image/jpeg", size: 6 * 1024 * 1024 });
    expect(result.valid).toBe(false);
    expect(result.error).toContain("5MB");
  });
});
