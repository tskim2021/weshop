/**
 * 커뮤니티 리뷰 게시판 상품 정보 표시 관련 테스트
 */

import { describe, it, expect } from "vitest";

describe("리뷰 게시글 상품 정보 조인", () => {
  it("productId가 있는 게시글은 상품 정보 포함", () => {
    const post = {
      id: 1,
      title: "좋은 상품입니다",
      productId: 123,
      productName: "포시가 10mg 84정",
      productThumbnail: "https://example.com/product.jpg",
    };
    expect(post.productId).toBe(123);
    expect(post.productName).toBe("포시가 10mg 84정");
    expect(post.productThumbnail).toBe("https://example.com/product.jpg");
  });

  it("productId가 없는 게시글은 상품 정보 null", () => {
    const post = {
      id: 2,
      title: "자유 게시글",
      productId: null,
      productName: null,
      productThumbnail: null,
    };
    expect(post.productId).toBeNull();
    expect(post.productName).toBeNull();
    expect(post.productThumbnail).toBeNull();
  });

  it("상품이 삭제된 경우 상품 정보 null", () => {
    const post = {
      id: 3,
      title: "리뷰 작성했는데 상품이 삭제됨",
      productId: 999,
      productName: null,
      productThumbnail: null,
    };
    expect(post.productId).toBe(999);
    expect(post.productName).toBeNull();
    expect(post.productThumbnail).toBeNull();
  });
});

describe("리뷰 목록 UI 렌더링 로직", () => {
  it("상품 썸네일이 있으면 이미지 표시", () => {
    const post = {
      productThumbnail: "https://example.com/thumb.jpg",
      productName: "테스트 상품",
    };
    const shouldShowThumbnail = !!post.productThumbnail;
    expect(shouldShowThumbnail).toBe(true);
  });

  it("상품 썸네일이 없으면 이미지 숨김", () => {
    const post = {
      productThumbnail: null,
      productName: null,
    };
    const shouldShowThumbnail = !!post.productThumbnail;
    expect(shouldShowThumbnail).toBe(false);
  });

  it("상품명이 있으면 텍스트 표시", () => {
    const post = {
      productName: "포시가 10mg 84정",
    };
    const shouldShowProductName = !!post.productName;
    expect(shouldShowProductName).toBe(true);
  });

  it("상품명과 썸네일 모두 있으면 둘 다 표시", () => {
    const post = {
      productThumbnail: "https://example.com/thumb.jpg",
      productName: "포시가 10mg 84정",
    };
    const shouldShowProductInfo = !!(post.productThumbnail && post.productName);
    expect(shouldShowProductInfo).toBe(true);
  });

  it("상품명만 있고 썸네일 없으면 상품명만 표시", () => {
    const post = {
      productThumbnail: null,
      productName: "포시가 10mg 84정",
    };
    const shouldShowThumbnail = !!post.productThumbnail;
    const shouldShowProductName = !!post.productName;
    expect(shouldShowThumbnail).toBe(false);
    expect(shouldShowProductName).toBe(true);
  });
});

describe("리뷰 상세 페이지 상품 링크", () => {
  it("productId와 상품 정보가 있으면 상품 링크 생성", () => {
    const post = {
      productId: 123,
      productThumbnail: "https://example.com/thumb.jpg",
      productName: "포시가 10mg 84정",
    };
    const productLink = `/product/${post.productId}`;
    expect(productLink).toBe("/product/123");
  });

  it("productId가 없으면 상품 링크 생성 안 함", () => {
    const post = {
      productId: null,
      productThumbnail: null,
      productName: null,
    };
    const shouldShowProductLink = !!(post.productId && post.productThumbnail && post.productName);
    expect(shouldShowProductLink).toBe(false);
  });
});

describe("게시글 타입별 상품 정보 표시", () => {
  it("리뷰 게시판(review)은 상품 정보 표시", () => {
    const board = { slug: "review", boardType: "review" };
    const post = {
      productThumbnail: "https://example.com/thumb.jpg",
      productName: "포시가 10mg 84정",
    };
    const shouldShowProductInfo = board.boardType === "review" && !!(post.productThumbnail && post.productName);
    expect(shouldShowProductInfo).toBe(true);
  });

  it("자유 게시판(free)은 상품 정보 표시 안 함", () => {
    const board = { slug: "free", boardType: "free" };
    const post = {
      productThumbnail: null,
      productName: null,
    };
    const shouldShowProductInfo = board.boardType === "review" && !!(post.productThumbnail && post.productName);
    expect(shouldShowProductInfo).toBe(false);
  });

  it("Q&A 게시판(qna)은 상품 정보 표시 가능 (productId 있으면)", () => {
    const board = { slug: "qna", boardType: "qna" };
    const post = {
      productThumbnail: "https://example.com/thumb.jpg",
      productName: "포시가 10mg 84정",
    };
    // Q&A도 상품 연결 가능하므로 상품 정보가 있으면 표시
    const shouldShowProductInfo = !!(post.productThumbnail && post.productName);
    expect(shouldShowProductInfo).toBe(true);
  });
});
