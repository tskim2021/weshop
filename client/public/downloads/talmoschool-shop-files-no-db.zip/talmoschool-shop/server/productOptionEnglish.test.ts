import { describe, it, expect } from "vitest";
import type { OptionValue } from "../drizzle/schema";

describe("Product Option English Value", () => {
  it("should create option value with english value", () => {
    const optionValue: OptionValue = {
      value: "사이즈 L",
      englishValue: "Size L",
      price: 5000,
      stock: 100,
    };

    expect(optionValue.value).toBe("사이즈 L");
    expect(optionValue.englishValue).toBe("Size L");
    expect(optionValue.price).toBe(5000);
    expect(optionValue.stock).toBe(100);
  });

  it("should allow optional english value", () => {
    const optionValue: OptionValue = {
      value: "색상 빨강",
      price: 0,
    };

    expect(optionValue.value).toBe("색상 빨강");
    expect(optionValue.englishValue).toBeUndefined();
    expect(optionValue.price).toBe(0);
  });

  it("should handle multiple option values with english", () => {
    const optionValues: OptionValue[] = [
      { value: "S", englishValue: "Small", price: 0, stock: 50 },
      { value: "M", englishValue: "Medium", price: 2000, stock: 100 },
      { value: "L", englishValue: "Large", price: 5000, stock: 75 },
    ];

    expect(optionValues).toHaveLength(3);
    expect(optionValues[0].englishValue).toBe("Small");
    expect(optionValues[1].englishValue).toBe("Medium");
    expect(optionValues[2].englishValue).toBe("Large");
  });

  it("should preserve english value in json serialization", () => {
    const optionValue: OptionValue = {
      value: "색상 파랑",
      englishValue: "Color Blue",
      price: 1000,
      stock: 80,
    };

    const json = JSON.stringify(optionValue);
    const parsed = JSON.parse(json) as OptionValue;

    expect(parsed.value).toBe("색상 파랑");
    expect(parsed.englishValue).toBe("Color Blue");
    expect(parsed.price).toBe(1000);
  });
});
