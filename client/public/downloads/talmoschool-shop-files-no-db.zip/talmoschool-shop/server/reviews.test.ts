/**
 * 리뷰 작성 기능 테스트
 */

import { describe, it, expect } from "vitest";

describe("리뷰 작성 기능", () => {
  it("리뷰 작성 시 필수 필드 검증", () => {
    const reviewData = {
      orderItemId: 1,
      rating: 5,
      title: "좋은 상품입니다",
      content: "배송도 빠르고 상품 품질도 좋습니다. 추천합니다!",
    };

    expect(reviewData.orderItemId).toBeGreaterThan(0);
    expect(reviewData.rating).toBeGreaterThanOrEqual(1);
    expect(reviewData.rating).toBeLessThanOrEqual(5);
    expect(reviewData.title.length).toBeGreaterThan(0);
    expect(reviewData.content.length).toBeGreaterThanOrEqual(10);
  });

  it("별점 범위 검증 (1-5)", () => {
    const validRatings = [1, 2, 3, 4, 5];
    validRatings.forEach((rating) => {
      expect(rating).toBeGreaterThanOrEqual(1);
      expect(rating).toBeLessThanOrEqual(5);
    });
  });

  it("리뷰 내용 최소 길이 검증 (10자)", () => {
    const shortContent = "짧은 글";
    const validContent = "이 상품은 정말 좋습니다. 배송도 빠르고 품질도 훌륭합니다.";

    expect(shortContent.length).toBeLessThan(10);
    expect(validContent.length).toBeGreaterThanOrEqual(10);
  });

  it("리뷰 작성 시 포인트 계산", () => {
    const basePoints = 100; // 기본 리뷰 포인트
    const photoPoints = 200; // 사진 리뷰 추가 포인트

    // 일반 리뷰
    const normalReviewPoints = basePoints;
    expect(normalReviewPoints).toBe(100);

    // 사진 리뷰
    const photoReviewPoints = basePoints + photoPoints;
    expect(photoReviewPoints).toBe(300);
  });

  it("리뷰 작성 가능 조건 확인", () => {
    const orderStatus = "delivered";
    const hasExistingReview = false;

    // 배송 완료 상태이고 기존 리뷰가 없어야 작성 가능
    const canWriteReview = orderStatus === "delivered" && !hasExistingReview;
    expect(canWriteReview).toBe(true);
  });

  it("중복 리뷰 작성 방지", () => {
    const hasExistingReview = true;
    const canWriteReview = !hasExistingReview;
    expect(canWriteReview).toBe(false);
  });

  it("배송 미완료 시 리뷰 작성 불가", () => {
    const orderStatuses = ["pending", "paid", "preparing", "shipping"];
    orderStatuses.forEach((status) => {
      const canWriteReview = status === "delivered";
      expect(canWriteReview).toBe(false);
    });
  });
});

describe("구매인증 리뷰 배지", () => {
  // 구매인증 판별 로직 함수 (서버 로직과 동일)
  function isVerifiedPurchase(review: { orderItemId?: number | null; orderId?: number | null; orderStatus?: string | null }) {
    return !!(review.orderItemId && review.orderId && review.orderStatus && ["delivered", "paid", "preparing", "shipping"].includes(review.orderStatus));
  }

  it("주문 정보가 있고 유효한 주문 상태일 때 구매인증으로 판별", () => {
    const review = { orderItemId: 1, orderId: 10, orderStatus: "delivered" };
    expect(isVerifiedPurchase(review)).toBe(true);
  });

  it("주문 상태가 paid, preparing, shipping일 때도 구매인증", () => {
    const statuses = ["paid", "preparing", "shipping", "delivered"];
    statuses.forEach(status => {
      const review = { orderItemId: 1, orderId: 10, orderStatus: status };
      expect(isVerifiedPurchase(review)).toBe(true);
    });
  });

  it("orderItemId가 없으면 구매인증 아님", () => {
    const review = { orderItemId: null, orderId: 10, orderStatus: "delivered" };
    expect(isVerifiedPurchase(review)).toBe(false);
  });

  it("orderId가 없으면 구매인증 아님", () => {
    const review = { orderItemId: 1, orderId: null, orderStatus: "delivered" };
    expect(isVerifiedPurchase(review)).toBe(false);
  });

  it("orderStatus가 cancelled/refunded일 때 구매인증 아님", () => {
    const cancelledReview = { orderItemId: 1, orderId: 10, orderStatus: "cancelled" };
    const refundedReview = { orderItemId: 1, orderId: 10, orderStatus: "refunded" };
    expect(isVerifiedPurchase(cancelledReview)).toBe(false);
    expect(isVerifiedPurchase(refundedReview)).toBe(false);
  });

  it("orderStatus가 null일 때 구매인증 아님", () => {
    const review = { orderItemId: 1, orderId: 10, orderStatus: null };
    expect(isVerifiedPurchase(review)).toBe(false);
  });

  it("모든 필드가 없으면 구매인증 아님", () => {
    const review = { orderItemId: null, orderId: null, orderStatus: null };
    expect(isVerifiedPurchase(review)).toBe(false);
  });
});

describe("리뷰 통계 (getProductReviewStats) 로직", () => {
  // 평점 분포 계산 로직 (서버 로직과 동일)
  function calculateRatingDistribution(reviews: { rating: number }[]) {
    const dist: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
    for (const r of reviews) {
      if (r.rating >= 1 && r.rating <= 5) {
        dist[r.rating]++;
      }
    }
    return dist;
  }

  function calculateAvgRating(reviews: { rating: number }[]) {
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, r) => acc + r.rating, 0);
    return Number((sum / reviews.length).toFixed(2));
  }

  it("리뷰가 없을 때 평균 평점 0, 분포 모두 0", () => {
    const reviews: { rating: number }[] = [];
    expect(calculateAvgRating(reviews)).toBe(0);
    const dist = calculateRatingDistribution(reviews);
    expect(dist).toEqual({ 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 });
  });

  it("리뷰 1건(5점)일 때 평균 5.00, 5점 1건", () => {
    const reviews = [{ rating: 5 }];
    expect(calculateAvgRating(reviews)).toBe(5);
    const dist = calculateRatingDistribution(reviews);
    expect(dist[5]).toBe(1);
    expect(dist[4]).toBe(0);
  });

  it("다양한 평점 분포 계산", () => {
    const reviews = [
      { rating: 5 }, { rating: 5 }, { rating: 5 },
      { rating: 4 }, { rating: 4 },
      { rating: 3 },
      { rating: 1 },
    ];
    const dist = calculateRatingDistribution(reviews);
    expect(dist).toEqual({ 1: 1, 2: 0, 3: 1, 4: 2, 5: 3 });
    expect(calculateAvgRating(reviews)).toBe(3.86);
  });

  it("평균 평점 소수점 2자리 반올림", () => {
    const reviews = [{ rating: 5 }, { rating: 4 }, { rating: 4 }];
    expect(calculateAvgRating(reviews)).toBe(4.33);
  });
});

describe("포토 갤러리 (getProductPhotoGallery) 로직", () => {
  // 이미지 평탄화 로직 (서버 로직과 동일)
  function flattenReviewImages(
    reviews: { id: number; images: string[] | null; userName: string | null; rating: number | null }[]
  ) {
    const allImages: { reviewId: number; imageUrl: string; userName: string | null; rating: number | null }[] = [];
    for (const review of reviews) {
      if (review.images && Array.isArray(review.images)) {
        for (const img of review.images) {
          allImages.push({
            reviewId: review.id,
            imageUrl: img,
            userName: review.userName,
            rating: review.rating,
          });
        }
      }
    }
    return allImages;
  }

  it("이미지가 없는 리뷰는 빈 배열 반환", () => {
    const reviews = [{ id: 1, images: null, userName: "테스트", rating: 5 }];
    expect(flattenReviewImages(reviews)).toEqual([]);
  });

  it("빈 이미지 배열도 빈 결과", () => {
    const reviews = [{ id: 1, images: [], userName: "테스트", rating: 5 }];
    expect(flattenReviewImages(reviews)).toEqual([]);
  });

  it("단일 리뷰 이미지 평탄화", () => {
    const reviews = [
      { id: 1, images: ["img1.jpg", "img2.jpg"], userName: "사용자A", rating: 5 },
    ];
    const result = flattenReviewImages(reviews);
    expect(result).toHaveLength(2);
    expect(result[0]).toEqual({ reviewId: 1, imageUrl: "img1.jpg", userName: "사용자A", rating: 5 });
    expect(result[1]).toEqual({ reviewId: 1, imageUrl: "img2.jpg", userName: "사용자A", rating: 5 });
  });

  it("복수 리뷰 이미지 평탄화", () => {
    const reviews = [
      { id: 1, images: ["a.jpg"], userName: "A", rating: 5 },
      { id: 2, images: ["b.jpg", "c.jpg"], userName: "B", rating: 4 },
      { id: 3, images: null, userName: "C", rating: 3 },
    ];
    const result = flattenReviewImages(reviews);
    expect(result).toHaveLength(3);
    expect(result.map(r => r.imageUrl)).toEqual(["a.jpg", "b.jpg", "c.jpg"]);
    expect(result[1].reviewId).toBe(2);
    expect(result[1].userName).toBe("B");
  });

  it("리뷰ID가 각 이미지에 올바르게 매핑", () => {
    const reviews = [
      { id: 10, images: ["x.jpg", "y.jpg", "z.jpg"], userName: "테스트", rating: 4 },
    ];
    const result = flattenReviewImages(reviews);
    expect(result.every(r => r.reviewId === 10)).toBe(true);
  });
});

describe("상품 썸네일 JSON_EXTRACT 처리", () => {
  // MySQL JSON_EXTRACT는 따옴표가 포함된 문자열을 반환할 수 있음
  function cleanThumbnailUrl(raw: string | null): string {
    if (!raw) return "";
    return raw.replace(/^"|"$/g, "");
  }

  it("따옴표가 포함된 URL 정리", () => {
    const raw = '"https://example.com/img.jpg"';
    expect(cleanThumbnailUrl(raw)).toBe("https://example.com/img.jpg");
  });

  it("따옴표가 없는 URL은 그대로", () => {
    const raw = "https://example.com/img.jpg";
    expect(cleanThumbnailUrl(raw)).toBe("https://example.com/img.jpg");
  });

  it("null은 빈 문자열 반환", () => {
    expect(cleanThumbnailUrl(null)).toBe("");
  });
});
