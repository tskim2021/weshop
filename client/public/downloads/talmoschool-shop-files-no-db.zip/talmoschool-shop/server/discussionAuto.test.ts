import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock DB functions
vi.mock("./db", () => {
  const mockSettings = [
    {
      id: 1,
      topic: "건강식품 효과 논쟁",
      categoryId: null,
      generateTime: "10:00",
      keywords: "비타민,오메가3",
      keywordsEn: "vitamin,omega-3",
      promptTemplate: null,
      discussionStyle: "debate",
      autoPublish: 1,
      isEnabled: 1,
      createdAt: new Date("2025-01-01"),
      updatedAt: new Date("2025-01-01"),
    },
    {
      id: 2,
      topic: "운동과 건강",
      categoryId: 1,
      generateTime: "14:00",
      keywords: "운동,헬스",
      keywordsEn: null,
      promptTemplate: null,
      discussionStyle: "opinion",
      autoPublish: 1,
      isEnabled: 0,
      createdAt: new Date("2025-01-02"),
      updatedAt: new Date("2025-01-02"),
    },
  ];

  return {
    getDiscussionAutoSettings: vi.fn().mockResolvedValue(mockSettings),
    getDiscussionAutoSettingById: vi.fn().mockImplementation((id: number) =>
      Promise.resolve(mockSettings.find((s) => s.id === id))
    ),
    getEnabledDiscussionAutoSettings: vi.fn().mockResolvedValue(
      mockSettings.filter((s) => s.isEnabled === 1)
    ),
    createDiscussionAutoSetting: vi.fn().mockResolvedValue({ id: 3 }),
    updateDiscussionAutoSetting: vi.fn().mockResolvedValue(undefined),
    deleteDiscussionAutoSetting: vi.fn().mockResolvedValue(undefined),
    getDiscussionAutoLogs: vi.fn().mockResolvedValue({
      logs: [
        {
          id: 1,
          settingId: 1,
          status: "success",
          discussionId: 100,
          generatedTitle: "비타민 D 보충제, 정말 효과가 있을까?",
          executionTimeMs: 3500,
          triggeredBy: "scheduler",
          errorMessage: null,
          createdAt: new Date("2025-01-15"),
        },
      ],
      total: 1,
    }),
    createDiscussionAutoLog: vi.fn().mockResolvedValue({ id: 1 }),
    createDiscussion: vi.fn().mockResolvedValue(100),
    getDb: vi.fn().mockResolvedValue(null),
  };
});

// Mock LLM
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [
      {
        message: {
          content: JSON.stringify({
            title: "비타민 D 보충제, 정말 효과가 있을까?",
            content: "## 비타민 D 보충제 논쟁\n\n최근 비타민 D 보충제의 효과에 대한 논쟁이 뜨겁습니다...\n\n여러분의 의견은 어떠신가요? 댓글로 의견을 남겨주세요!",
            tags: ["비타민D", "보충제", "건강", "영양제"],
          }),
        },
      },
    ],
  }),
}));

// Mock scheduler
vi.mock("./jobs/discussionScheduler", () => ({
  restartDiscussionScheduler: vi.fn().mockResolvedValue(undefined),
  getDiscussionSchedulerStatus: vi.fn().mockReturnValue({
    isActive: true,
    scheduleTime: "10:00",
  }),
}));

import * as db from "./db";

describe("Discussion Auto - DB Functions", () => {
  it("should get all discussion auto settings", async () => {
    const settings = await db.getDiscussionAutoSettings();
    expect(settings).toHaveLength(2);
    expect(settings[0].topic).toBe("건강식품 효과 논쟁");
    expect(settings[0].discussionStyle).toBe("debate");
  });

  it("should get setting by id", async () => {
    const setting = await db.getDiscussionAutoSettingById(1);
    expect(setting).toBeDefined();
    expect(setting?.topic).toBe("건강식품 효과 논쟁");
  });

  it("should return undefined for non-existent setting", async () => {
    const setting = await db.getDiscussionAutoSettingById(999);
    expect(setting).toBeUndefined();
  });

  it("should get only enabled settings", async () => {
    const settings = await db.getEnabledDiscussionAutoSettings();
    expect(settings).toHaveLength(1);
    expect(settings[0].isEnabled).toBe(1);
  });

  it("should create a new setting", async () => {
    const result = await db.createDiscussionAutoSetting({
      topic: "새 토론 주제",
      categoryId: null,
      generateTime: "11:00",
      keywords: null,
      keywordsEn: null,
      promptTemplate: null,
      discussionStyle: "question",
      autoPublish: 1,
      isEnabled: 1,
    });
    expect(result.id).toBe(3);
  });

  it("should update a setting", async () => {
    await db.updateDiscussionAutoSetting(1, { topic: "수정된 주제" });
    expect(db.updateDiscussionAutoSetting).toHaveBeenCalledWith(1, { topic: "수정된 주제" });
  });

  it("should delete a setting", async () => {
    await db.deleteDiscussionAutoSetting(1);
    expect(db.deleteDiscussionAutoSetting).toHaveBeenCalledWith(1);
  });

  it("should get discussion auto logs", async () => {
    const result = await db.getDiscussionAutoLogs(1, 1, 20);
    expect(result.logs).toHaveLength(1);
    expect(result.logs[0].status).toBe("success");
    expect(result.logs[0].generatedTitle).toBe("비타민 D 보충제, 정말 효과가 있을까?");
    expect(result.total).toBe(1);
  });

  it("should create a discussion auto log", async () => {
    const result = await db.createDiscussionAutoLog({
      settingId: 1,
      status: "success",
      discussionId: 100,
      generatedTitle: "테스트 토론",
      executionTimeMs: 2000,
      triggeredBy: "manual",
      errorMessage: null,
    });
    expect(result.id).toBe(1);
  });
});

describe("Discussion Auto - Generator Service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should generate a discussion post via LLM", async () => {
    const { generateDiscussionPost } = await import("./services/discussionGenerator");
    const setting = (await db.getDiscussionAutoSettingById(1))!;
    const result = await generateDiscussionPost(setting, 1, "manual");

    expect(result.success).toBe(true);
    expect(result.title).toBe("비타민 D 보충제, 정말 효과가 있을까?");
    expect(result.discussionId).toBe(100);
  });

  it("should handle LLM failure gracefully", async () => {
    const { invokeLLM } = await import("./_core/llm");
    (invokeLLM as any).mockResolvedValueOnce({
      choices: [{ message: { content: null } }],
    });

    const { generateDiscussionPost } = await import("./services/discussionGenerator");
    const setting = (await db.getDiscussionAutoSettingById(1))!;
    const result = await generateDiscussionPost(setting, 1, "manual");

    expect(result.success).toBe(false);
    expect(result.error).toBe("AI 토론 주제 생성 실패");
  });

  it("should generate all enabled discussion posts", async () => {
    const { generateAllEnabledDiscussionPosts } = await import("./services/discussionGenerator");
    const result = await generateAllEnabledDiscussionPosts(1, "scheduler");

    expect(result.totalGenerated).toBe(1);
    expect(result.results).toHaveLength(1);
    expect(result.results[0].success).toBe(true);
  });
});

describe("Discussion Auto - Scheduler", () => {
  it("should return scheduler status", async () => {
    const { getDiscussionSchedulerStatus } = await import("./jobs/discussionScheduler");
    const status = getDiscussionSchedulerStatus();
    expect(status.isActive).toBe(true);
    expect(status.scheduleTime).toBe("10:00");
  });
});

describe("Discussion Auto - Style Options", () => {
  it("should support all 5 discussion styles", () => {
    const styles = ["debate", "opinion", "question", "poll", "experience"];
    expect(styles).toHaveLength(5);
    styles.forEach((style) => {
      expect(typeof style).toBe("string");
      expect(style.length).toBeGreaterThan(0);
    });
  });
});
