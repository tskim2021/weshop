import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock db module
vi.mock("./db", () => ({
  getNewsPosts: vi.fn().mockResolvedValue({ posts: [], total: 0 }),
  getNewsPostById: vi.fn().mockResolvedValue(null),
  getLatestNewsByCategory: vi.fn().mockResolvedValue([]),
  getLatestNewsForHome: vi.fn().mockResolvedValue([]),
  createNewsPost: vi.fn().mockResolvedValue(1),
  updateNewsPost: vi.fn().mockResolvedValue(undefined),
  deleteNewsPost: vi.fn().mockResolvedValue(undefined),
  getNewsAutoSettings: vi.fn().mockResolvedValue([]),
  getEnabledNewsAutoSettings: vi.fn().mockResolvedValue([]),
  getNewsAutoSettingByCategory: vi.fn().mockResolvedValue(null),
  updateNewsAutoSetting: vi.fn().mockResolvedValue(undefined),
}));

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function createAdminContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "admin-user",
      email: "admin@example.com",
      name: "Admin",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

function createUserContext(): TrpcContext {
  return {
    user: {
      id: 2,
      openId: "regular-user",
      email: "user@example.com",
      name: "User",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

describe("news router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("news.list (public)", () => {
    it("returns empty list when no news exists", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const result = await caller.news.list({});
      expect(result).toEqual({ posts: [], total: 0 });
    });

    it("accepts optional filters", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const result = await caller.news.list({
        categoryId: 1,
        newsSection: "domestic",
        page: 1,
        limit: 10,
        search: "test",
      });
      expect(result).toBeDefined();
    });
  });

  describe("news.byId (public)", () => {
    it("throws NOT_FOUND when news does not exist", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      await expect(caller.news.byId({ id: 999 })).rejects.toThrow();
    });
  });

  describe("news.latestForHome (public)", () => {
    it("returns empty array when no news exists", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const result = await caller.news.latestForHome({});
      expect(result).toEqual([]);
    });
  });

  describe("news.latestByCategory (public)", () => {
    it("returns empty array for a category with no news", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const result = await caller.news.latestByCategory({ categoryId: 1 });
      expect(result).toEqual([]);
    });
  });

  describe("news.create (admin only)", () => {
    it("rejects unauthenticated users", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      await expect(
        caller.news.create({
          title: "Test",
          content: "Test content",
          categoryId: 1,
          newsSection: "domestic",
        })
      ).rejects.toThrow();
    });

    it("rejects regular users", async () => {
      const caller = appRouter.createCaller(createUserContext());
      await expect(
        caller.news.create({
          title: "Test",
          content: "Test content",
          categoryId: 1,
          newsSection: "domestic",
        })
      ).rejects.toThrow();
    });

    it("allows admin to create news", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.news.create({
        title: "Test News",
        content: "Test content body",
        categoryId: 1,
        newsSection: "domestic",
      });
      expect(result).toEqual({ success: true, postId: 1 });
    });
  });

  describe("news.update (admin only)", () => {
    it("rejects unauthenticated users", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      await expect(
        caller.news.update({ id: 1, title: "Updated" })
      ).rejects.toThrow();
    });

    it("allows admin to update news", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.news.update({
        id: 1,
        title: "Updated Title",
        content: "Updated content",
      });
      expect(result).toEqual({ success: true });
    });
  });

  describe("news.delete (admin only)", () => {
    it("rejects regular users", async () => {
      const caller = appRouter.createCaller(createUserContext());
      await expect(caller.news.delete({ id: 1 })).rejects.toThrow();
    });

    it("allows admin to delete news", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.news.delete({ id: 1 });
      expect(result).toEqual({ success: true });
    });
  });

  describe("news.autoSettings (admin only)", () => {
    it("rejects unauthenticated users", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      await expect(caller.news.autoSettings()).rejects.toThrow();
    });

    it("allows admin to view auto settings", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.news.autoSettings();
      expect(result).toEqual([]);
    });
  });

  describe("news.updateAutoSetting (admin only)", () => {
    it("allows admin to update auto setting", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.news.updateAutoSetting({
        categoryId: 1,
        isEnabled: 1,
        keywords: "탈모, 모발",
      });
      expect(result).toEqual({ success: true });
    });
  });
});
