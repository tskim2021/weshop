import { describe, it, expect } from "vitest";
import { webhooksRouter } from "./routers/webhooks";
import { mapStatusToSystem } from "./_core/17trackApi";

describe("17track Webhook Integration", () => {
  it("should have webhook router configured", () => {
    // 웹훅 라우터가 정상적으로 로드되는지 확인
    expect(webhooksRouter).toBeDefined();
  });

  it("should have seventeentrack procedure", () => {
    expect(webhooksRouter._def.procedures.seventeentrack).toBeDefined();
  });

  it("should have API key configured for webhook verification", () => {
    expect(process.env.SEVENTEENTRACK_API_KEY).toBeDefined();
    expect(process.env.SEVENTEENTRACK_API_KEY).not.toBe("");
  });
});

describe("17track API Client", () => {
  it("should have mapStatusToSystem function", () => {
    // API 모듈이 정상적으로 로드되는지 확인
    expect(mapStatusToSystem).toBeDefined();
  });

  it("should map 17track status to system status correctly", () => {
    
    expect(mapStatusToSystem(0)).toBe("pending"); // NotFound
    expect(mapStatusToSystem(1)).toBe("pending"); // InfoReceived
    expect(mapStatusToSystem(2)).toBe("in_transit"); // InTransit
    expect(mapStatusToSystem(3)).toBe("picked_up"); // PickUp
    expect(mapStatusToSystem(4)).toBe("out_for_delivery"); // OutForDelivery
    expect(mapStatusToSystem(5)).toBe("failed"); // DeliveryFailure
    expect(mapStatusToSystem(6)).toBe("delivered"); // Delivered
    expect(mapStatusToSystem(7)).toBe("alert"); // Alert/Exception
    expect(mapStatusToSystem(8)).toBe("returned"); // Expired
  });
});
