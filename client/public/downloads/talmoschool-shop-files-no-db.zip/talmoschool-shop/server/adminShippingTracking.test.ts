import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";

function createAdminContext() {
  return {
    ctx: { user: { id: 1, role: "admin", name: "Admin", openId: "admin-open-id" } },
  };
}

function createUserContext() {
  return {
    ctx: { user: { id: 2, role: "user", name: "User", openId: "user-open-id" } },
  };
}

describe("관리자 배송추적 API", () => {
  describe("shipping.adminTrackOrder", () => {
    it("관리자 프로시저로 정의되어 있어야 함", () => {
      const router = appRouter._def.procedures;
      expect(router).toHaveProperty("shipping.adminTrackOrder");
    });

    it("일반 사용자는 접근할 수 없어야 함", async () => {
      const { ctx } = createUserContext();
      const caller = appRouter.createCaller(ctx);
      await expect(
        caller.shipping.adminTrackOrder({ orderId: 1 })
      ).rejects.toThrow();
    });

    it("존재하지 않는 주문은 NOT_FOUND 에러를 반환해야 함", async () => {
      const { ctx } = createAdminContext();
      const caller = appRouter.createCaller(ctx);
      await expect(
        caller.shipping.adminTrackOrder({ orderId: 999999 })
      ).rejects.toThrow();
    });
  });

  describe("shipping.adminRefreshTracking", () => {
    it("관리자 프로시저로 정의되어 있어야 함", () => {
      const router = appRouter._def.procedures;
      expect(router).toHaveProperty("shipping.adminRefreshTracking");
    });

    it("일반 사용자는 접근할 수 없어야 함", async () => {
      const { ctx } = createUserContext();
      const caller = appRouter.createCaller(ctx);
      await expect(
        caller.shipping.adminRefreshTracking({ orderId: 1 })
      ).rejects.toThrow();
    });

    it("존재하지 않는 주문은 NOT_FOUND 에러를 반환해야 함", async () => {
      const { ctx } = createAdminContext();
      const caller = appRouter.createCaller(ctx);
      await expect(
        caller.shipping.adminRefreshTracking({ orderId: 999999 })
      ).rejects.toThrow();
    });
  });
});

describe("배송 상태 라벨 매핑", () => {
  const shipmentStatusLabels: Record<string, string> = {
    ready: "배송 준비",
    picked_up: "상품 수거",
    accepted: "접수",
    export_customs: "출발국 통관",
    in_transit: "배송 중",
    in_transit_intl: "국제운송",
    in_transit_domestic: "국내배송",
    arrived_destination: "도착국 도착",
    import_customs: "도착국 통관",
    customs_cleared: "통관 완료",
    customs_departure: "통관 출발",
    customs_arrival: "통관 도착",
    out_for_delivery: "배달 출발",
    delivered: "배달 완료",
    failed: "배송 실패",
    returned: "반송",
    alert: "주의",
  };

  it("모든 국제배송 상태에 대한 라벨이 정의되어 있어야 함", () => {
    const requiredStatuses = [
      "accepted", "export_customs", "in_transit", "in_transit_intl",
      "import_customs", "out_for_delivery", "delivered", "failed"
    ];
    for (const status of requiredStatuses) {
      expect(shipmentStatusLabels[status]).toBeDefined();
      expect(shipmentStatusLabels[status].length).toBeGreaterThan(0);
    }
  });

  it("통관 관련 상태 라벨이 올바르게 정의되어 있어야 함", () => {
    expect(shipmentStatusLabels["import_customs"]).toBe("도착국 통관");
    expect(shipmentStatusLabels["export_customs"]).toBe("출발국 통관");
    expect(shipmentStatusLabels["customs_cleared"]).toBe("통관 완료");
  });
});

describe("국제배송 단계 매핑", () => {
  function mapToIntlStep(status: string): number {
    const mapping: Record<string, number> = {
      pending: 0, ready: 0, accepted: 0, picked_up: 0,
      export_customs: 1, departed_origin: 2,
      in_transit: 2, in_transit_intl: 2,
      arrived_destination: 3, import_customs: 3, customs_cleared: 3,
      customs_departure: 1, customs_arrival: 3,
      in_transit_domestic: 4, out_for_delivery: 4,
      delivered: 5, failed: -1, returned: -1, alert: -1,
    };
    return mapping[status] ?? 0;
  }

  it("접수 상태는 0단계여야 함", () => {
    expect(mapToIntlStep("accepted")).toBe(0);
    expect(mapToIntlStep("picked_up")).toBe(0);
  });

  it("출발국 통관은 1단계여야 함", () => {
    expect(mapToIntlStep("export_customs")).toBe(1);
  });

  it("국제운송은 2단계여야 함", () => {
    expect(mapToIntlStep("in_transit")).toBe(2);
    expect(mapToIntlStep("in_transit_intl")).toBe(2);
  });

  it("도착국 통관은 3단계여야 함", () => {
    expect(mapToIntlStep("import_customs")).toBe(3);
    expect(mapToIntlStep("customs_cleared")).toBe(3);
  });

  it("현지배송은 4단계여야 함", () => {
    expect(mapToIntlStep("out_for_delivery")).toBe(4);
    expect(mapToIntlStep("in_transit_domestic")).toBe(4);
  });

  it("배달완료는 5단계여야 함", () => {
    expect(mapToIntlStep("delivered")).toBe(5);
  });

  it("실패/반송/주의는 -1이어야 함", () => {
    expect(mapToIntlStep("failed")).toBe(-1);
    expect(mapToIntlStep("returned")).toBe(-1);
    expect(mapToIntlStep("alert")).toBe(-1);
  });

  it("알 수 없는 상태는 0으로 기본값 처리해야 함", () => {
    expect(mapToIntlStep("unknown_status")).toBe(0);
  });
});
