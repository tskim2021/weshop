import { describe, it, expect, vi } from "vitest";

/**
 * adminBulkRefreshTracking 프로시저 단위 테스트
 * - 선택한 shipmentIds로 일괄 17track API 조회
 * - 성공/실패 건수 집계
 * - 배송 완료 시 주문 상태 자동 변경
 * - 통관검사 감지 시 customs_hold 자동 전환
 */

// Mock DB functions
vi.mock("./db", () => ({
  getShipmentById: vi.fn(),
  updateShipmentStatusOnly: vi.fn(),
  getShippingHistoryByShipmentId: vi.fn().mockResolvedValue([]),
  createShippingHistory: vi.fn(),
  getOrderById: vi.fn(),
  updateOrderStatus: vi.fn(),
  createNotification: vi.fn(),
}));

// Mock 17track API
vi.mock("./_core/17trackApi", () => ({
  getTrackingInfo: vi.fn(),
  mapStatusToSystem: vi.fn(),
  registerTracking: vi.fn(),
}));

import * as db from "./db";
import { getTrackingInfo } from "./_core/17trackApi";

describe("adminBulkRefreshTracking", () => {
  it("should validate shipmentIds input - min 1, max 50", () => {
    // Input validation test
    const validInput = { shipmentIds: [1, 2, 3] };
    expect(validInput.shipmentIds.length).toBeGreaterThanOrEqual(1);
    expect(validInput.shipmentIds.length).toBeLessThanOrEqual(50);

    const emptyInput = { shipmentIds: [] as number[] };
    expect(emptyInput.shipmentIds.length).toBe(0);
  });

  it("should handle successful tracking info retrieval", async () => {
    const mockShipment = {
      id: 1,
      orderId: 100,
      trackingNumber: "EE123456789KR",
      status: "in_transit",
    };

    const mockTrackingInfo = {
      status: "InTransit",
      events: [
        {
          time: "2026-02-15T10:00:00Z",
          description: "국제운송 중",
          location: "인천공항",
          details: "항공편 출발",
        },
      ],
    };

    (db.getShipmentById as any).mockResolvedValue(mockShipment);
    (getTrackingInfo as any).mockResolvedValue(mockTrackingInfo);
    (db.getShippingHistoryByShipmentId as any).mockResolvedValue([]);

    // Verify mock setup
    const shipment = await db.getShipmentById(1);
    expect(shipment).toEqual(mockShipment);

    const trackingInfo = await getTrackingInfo("EE123456789KR");
    expect(trackingInfo).toEqual(mockTrackingInfo);
  });

  it("should handle shipment not found", async () => {
    (db.getShipmentById as any).mockResolvedValue(null);

    const shipment = await db.getShipmentById(999);
    expect(shipment).toBeNull();
  });

  it("should handle 17track API failure gracefully", async () => {
    const mockShipment = {
      id: 2,
      orderId: 200,
      trackingNumber: "EE987654321KR",
      status: "in_transit",
    };

    (db.getShipmentById as any).mockResolvedValue(mockShipment);
    (getTrackingInfo as any).mockResolvedValue(null);

    const shipment = await db.getShipmentById(2);
    expect(shipment).not.toBeNull();

    const trackingInfo = await getTrackingInfo("EE987654321KR");
    expect(trackingInfo).toBeNull();
  });

  it("should detect delivered status and update order", async () => {
    const mockOrder = {
      id: 100,
      userId: 1,
      orderNumber: "ORD-20260215-001",
      status: "shipping",
    };

    (db.getOrderById as any).mockResolvedValue(mockOrder);
    (db.updateOrderStatus as any).mockResolvedValue(undefined);
    (db.createNotification as any).mockResolvedValue(undefined);

    // Simulate delivered detection
    const order = await db.getOrderById(100);
    expect(order).not.toBeNull();
    expect(order!.status).not.toBe("delivered");

    await db.updateOrderStatus(100, "delivered");
    expect(db.updateOrderStatus).toHaveBeenCalledWith(100, "delivered");

    await db.createNotification(
      order!.userId,
      "order",
      "배송이 완료되었습니다",
      `주문번호: ${order!.orderNumber}. 상품은 어떠셨나요? 리뷰를 작성해주세요!`,
      `/mypage/orders/${order!.id}`
    );
    expect(db.createNotification).toHaveBeenCalledWith(
      1,
      "order",
      "배송이 완료되었습니다",
      expect.stringContaining("ORD-20260215-001"),
      "/mypage/orders/100"
    );
  });

  it("should detect import_customs and set customs_hold", async () => {
    const mockOrder = {
      id: 200,
      userId: 2,
      orderNumber: "ORD-20260215-002",
      status: "shipping",
    };

    (db.getOrderById as any).mockResolvedValue(mockOrder);
    (db.updateOrderStatus as any).mockResolvedValue(undefined);
    (db.createNotification as any).mockResolvedValue(undefined);

    // Simulate import_customs detection
    const order = await db.getOrderById(200);
    expect(order).not.toBeNull();
    expect(order!.status).not.toBe("customs_hold");

    await db.updateOrderStatus(200, "customs_hold");
    expect(db.updateOrderStatus).toHaveBeenCalledWith(200, "customs_hold");

    await db.createNotification(
      order!.userId,
      "order",
      "통관검사 안내",
      `주문번호 ${order!.orderNumber}: 고객님의 주문 상품이 통관검사 대상으로 선정되었습니다.`,
      `/mypage/orders/${order!.id}`
    );
    expect(db.createNotification).toHaveBeenCalledWith(
      2,
      "order",
      "통관검사 안내",
      expect.stringContaining("ORD-20260215-002"),
      "/mypage/orders/200"
    );
  });

  it("should aggregate results correctly", () => {
    const results = [
      { shipmentId: 1, orderId: 100, success: true, newStatus: "in_transit", eventsCount: 2 },
      { shipmentId: 2, orderId: 200, success: false, eventsCount: 0, error: "배송 정보를 조회할 수 없습니다." },
      { shipmentId: 3, orderId: 300, success: true, newStatus: "delivered", eventsCount: 1 },
    ];

    const successCount = results.filter(r => r.success).length;
    const failCount = results.filter(r => !r.success).length;

    expect(successCount).toBe(2);
    expect(failCount).toBe(1);
    expect(results.length).toBe(3);
  });

  it("should create shipping history for new events", async () => {
    const existingHistory = [
      { status: "접수", description: "우체국 접수", timestamp: new Date("2026-02-10T10:00:00Z") },
    ];

    const newEvents = [
      {
        time: "2026-02-12T14:00:00Z",
        description: "국제운송 중",
        location: "인천공항",
        details: "항공편 출발",
      },
      {
        time: "2026-02-14T08:00:00Z",
        description: "도착국 통관",
        location: "도쿄세관",
        details: "통관 진행 중",
      },
    ];

    (db.createShippingHistory as any).mockResolvedValue(undefined);

    for (const event of newEvents) {
      await db.createShippingHistory({
        shipmentId: 1,
        status: event.description,
        location: event.location,
        description: event.details,
        timestamp: new Date(event.time),
      });
    }

    expect(db.createShippingHistory).toHaveBeenCalledTimes(2);
  });

  it("should not update order status if already in target status", async () => {
    const mockOrderAlreadyDelivered = {
      id: 300,
      userId: 3,
      orderNumber: "ORD-20260215-003",
      status: "delivered",
    };

    (db.getOrderById as any).mockResolvedValue(mockOrderAlreadyDelivered);

    const order = await db.getOrderById(300);
    // Should NOT call updateOrderStatus since already delivered
    expect(order!.status).toBe("delivered");
  });

  it("should not update order status if already customs_hold", async () => {
    const mockOrderAlreadyCustomsHold = {
      id: 400,
      userId: 4,
      orderNumber: "ORD-20260215-004",
      status: "customs_hold",
    };

    (db.getOrderById as any).mockResolvedValue(mockOrderAlreadyCustomsHold);

    const order = await db.getOrderById(400);
    // Should NOT call updateOrderStatus since already customs_hold
    expect(order!.status).toBe("customs_hold");
  });

  it("should handle max 50 shipments", () => {
    const maxIds = Array.from({ length: 50 }, (_, i) => i + 1);
    expect(maxIds.length).toBe(50);

    const overMaxIds = Array.from({ length: 51 }, (_, i) => i + 1);
    expect(overMaxIds.length).toBe(51);
    // Server-side zod validation would reject > 50
  });

  it("should return proper response structure", () => {
    const response = {
      success: true,
      total: 5,
      successCount: 4,
      failCount: 1,
      results: [
        { shipmentId: 1, orderId: 100, success: true, newStatus: "in_transit", eventsCount: 2 },
        { shipmentId: 2, orderId: 200, success: true, newStatus: "delivered", eventsCount: 1 },
        { shipmentId: 3, orderId: 300, success: false, eventsCount: 0, error: "API 실패" },
        { shipmentId: 4, orderId: 400, success: true, newStatus: "import_customs", eventsCount: 3 },
        { shipmentId: 5, orderId: 500, success: true, newStatus: "out_for_delivery", eventsCount: 1 },
      ],
    };

    expect(response.success).toBe(true);
    expect(response.total).toBe(5);
    expect(response.successCount).toBe(4);
    expect(response.failCount).toBe(1);
    expect(response.results).toHaveLength(5);
    expect(response.results[2].error).toBe("API 실패");
  });
});
