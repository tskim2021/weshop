import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock DB helpers
vi.mock("./db", () => ({
  getDb: vi.fn(),
  getPostsByBoard: vi.fn(),
  getPostById: vi.fn(),
  createPost: vi.fn(),
  updatePost: vi.fn(),
  deletePost: vi.fn(),
  getCommentsByPost: vi.fn(),
  createComment: vi.fn(),
  deleteComment: vi.fn(),
  getBoardBySlug: vi.fn(),
}));

import {
  getPostsByBoard,
  getPostById,
  createPost,
  updatePost,
  deletePost,
  getCommentsByPost,
  createComment,
  deleteComment,
  getBoardBySlug,
  getDb,
} from "./db";

describe("InfoBoard Router", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("posts (list)", () => {
    it("should fetch posts with pagination", async () => {
      const mockPosts = [
        { id: 1, title: "테스트 글", content: "내용", userName: "테스터", viewCount: 10, commentCount: 2, createdAt: new Date(), isPinned: 0, isHidden: 0 },
      ];
      (getBoardBySlug as any).mockResolvedValue({ id: 1, name: "정보나눔", slug: "info-sharing", boardType: "info" });
      (getPostsByBoard as any).mockResolvedValue({ posts: mockPosts, total: 1 });

      const result = await (getPostsByBoard as any)(1, { page: 1, limit: 20 });
      expect(result.posts).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it("should support search filter", async () => {
      (getBoardBySlug as any).mockResolvedValue({ id: 1 });
      (getPostsByBoard as any).mockResolvedValue({ posts: [], total: 0 });

      const result = await (getPostsByBoard as any)(1, { page: 1, limit: 20, search: "비달리스타" });
      expect(result.posts).toHaveLength(0);
    });
  });

  describe("postById (detail)", () => {
    it("should return post detail with view count increment", async () => {
      const mockPost = {
        id: 1,
        title: "비달리스타 40 복용법",
        content: "상세 내용...",
        userName: "탈모학교",
        viewCount: 100,
        commentCount: 5,
        createdAt: new Date(),
        isPinned: 0,
        isHidden: 0,
        images: [],
        userId: "user1",
      };
      (getPostById as any).mockResolvedValue(mockPost);

      const result = await (getPostById as any)(1);
      expect(result.id).toBe(1);
      expect(result.title).toBe("비달리스타 40 복용법");
      expect(result.viewCount).toBe(100);
    });

    it("should return null for non-existent post", async () => {
      (getPostById as any).mockResolvedValue(null);

      const result = await (getPostById as any)(999);
      expect(result).toBeNull();
    });
  });

  describe("createPost", () => {
    it("should create a new info board post", async () => {
      (getBoardBySlug as any).mockResolvedValue({ id: 1 });
      (createPost as any).mockResolvedValue({ id: 10 });

      const result = await (createPost as any)({
        boardId: 1,
        title: "새 정보 공유",
        content: "유용한 정보입니다.",
        userId: "user1",
        userName: "테스터",
      });
      expect(result.id).toBe(10);
    });

    it("should require title and content", () => {
      expect(() => {
        const title = "";
        const content = "내용";
        if (!title.trim()) throw new Error("제목은 필수입니다");
      }).toThrow("제목은 필수입니다");
    });

    it("should require content", () => {
      expect(() => {
        const title = "제목";
        const content = "";
        if (!content.trim()) throw new Error("내용은 필수입니다");
      }).toThrow("내용은 필수입니다");
    });
  });

  describe("updatePost", () => {
    it("should update an existing post", async () => {
      (getPostById as any).mockResolvedValue({ id: 1, userId: "user1" });
      (updatePost as any).mockResolvedValue({ id: 1 });

      const result = await (updatePost as any)(1, {
        title: "수정된 제목",
        content: "수정된 내용",
      });
      expect(result.id).toBe(1);
    });
  });

  describe("deletePost", () => {
    it("should delete a post", async () => {
      (getPostById as any).mockResolvedValue({ id: 1, userId: "user1" });
      (deletePost as any).mockResolvedValue(true);

      const result = await (deletePost as any)(1);
      expect(result).toBe(true);
    });
  });

  describe("comments", () => {
    it("should fetch comments for a post", async () => {
      const mockComments = [
        { id: 1, content: "좋은 정보 감사합니다", userName: "유저1", createdAt: new Date(), parentId: null, isAdmin: false },
        { id: 2, content: "답글입니다", userName: "유저2", createdAt: new Date(), parentId: 1, isAdmin: false },
      ];
      (getCommentsByPost as any).mockResolvedValue(mockComments);

      const result = await (getCommentsByPost as any)(1);
      expect(result).toHaveLength(2);
      expect(result[0].parentId).toBeNull();
      expect(result[1].parentId).toBe(1);
    });

    it("should create a top-level comment", async () => {
      (createComment as any).mockResolvedValue({ id: 3 });

      const result = await (createComment as any)({
        postId: 1,
        content: "새 댓글",
        userId: "user1",
        userName: "테스터",
      });
      expect(result.id).toBe(3);
    });

    it("should create a reply comment", async () => {
      (createComment as any).mockResolvedValue({ id: 4 });

      const result = await (createComment as any)({
        postId: 1,
        content: "답글",
        userId: "user2",
        userName: "유저2",
        parentId: 1,
      });
      expect(result.id).toBe(4);
    });

    it("should delete a comment", async () => {
      (deleteComment as any).mockResolvedValue(true);

      const result = await (deleteComment as any)(1);
      expect(result).toBe(true);
    });
  });

  describe("admin features", () => {
    it("should toggle pin status", async () => {
      const mockDb = {
        update: vi.fn().mockReturnThis(),
        set: vi.fn().mockReturnThis(),
        where: vi.fn().mockResolvedValue({}),
      };
      (getDb as any).mockReturnValue(mockDb);

      // Simulate admin toggle pin
      const isPinned = 1;
      expect(isPinned).toBe(1);
    });

    it("should toggle hide status", async () => {
      const mockDb = {
        update: vi.fn().mockReturnThis(),
        set: vi.fn().mockReturnThis(),
        where: vi.fn().mockResolvedValue({}),
      };
      (getDb as any).mockReturnValue(mockDb);

      // Simulate admin toggle hide
      const isHidden = 1;
      expect(isHidden).toBe(1);
    });
  });

  describe("board type validation", () => {
    it("should only work with info type board", async () => {
      (getBoardBySlug as any).mockResolvedValue({ id: 1, boardType: "info", slug: "info-sharing" });

      const board = await (getBoardBySlug as any)("info-sharing");
      expect(board.boardType).toBe("info");
    });

    it("should have correct board slug", async () => {
      (getBoardBySlug as any).mockResolvedValue({ id: 1, boardType: "info", slug: "info-sharing" });

      const board = await (getBoardBySlug as any)("info-sharing");
      expect(board.slug).toBe("info-sharing");
    });
  });
});
