import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── 이메일 템플릿 테스트 ───
describe("통관검사 알림 - 이메일 템플릿", () => {
  it("generateCustomsHoldEmail이 올바른 HTML을 생성해야 함", async () => {
    const { generateCustomsHoldEmail } = await import("./_core/customsHoldEmail");
    
    const html = generateCustomsHoldEmail({
      customerName: "홍길동",
      orderNumber: "ORD-20260219-001",
      orderId: 123,
    });

    expect(html).toContain("통관검사 안내");
    expect(html).toContain("홍길동");
    expect(html).toContain("ORD-20260219-001");
    expect(html).toContain("/mypage/orders/123");
    expect(html).toContain("통관검사 대상으로 선정");
    expect(html).toContain("1~5 영업일");
    expect(html).toContain("배송이 자동으로 재개");
  });

  it("이메일 템플릿에 필수 섹션이 포함되어야 함", async () => {
    const { generateCustomsHoldEmail } = await import("./_core/customsHoldEmail");
    
    const html = generateCustomsHoldEmail({
      customerName: "테스트",
      orderNumber: "ORD-TEST",
      orderId: 1,
    });

    // 주문 정보 섹션
    expect(html).toContain("주문 정보");
    // 안내사항 섹션
    expect(html).toContain("안내사항");
    // 안심 메시지
    expect(html).toContain("안심하세요");
    // CTA 버튼
    expect(html).toContain("주문 상세 확인하기");
    // 푸터
    expect(html).toContain("탈모학교");
  });

  it("이메일 템플릿이 유효한 HTML 구조여야 함", async () => {
    const { generateCustomsHoldEmail } = await import("./_core/customsHoldEmail");
    
    const html = generateCustomsHoldEmail({
      customerName: "테스트",
      orderNumber: "ORD-TEST",
      orderId: 1,
    });

    expect(html).toContain("<!DOCTYPE html>");
    expect(html).toContain("<html");
    expect(html).toContain("</html>");
    expect(html).toContain("<head>");
    expect(html).toContain("<body>");
  });

  it("이메일 템플릿에 rose/red 계열 스타일이 적용되어야 함", async () => {
    const { generateCustomsHoldEmail } = await import("./_core/customsHoldEmail");
    
    const html = generateCustomsHoldEmail({
      customerName: "테스트",
      orderNumber: "ORD-TEST",
      orderId: 1,
    });

    // 통관검사 강조 색상 (rose/red 계열)
    expect(html).toContain("#e11d48");
  });
});

// ─── 알림 발송 로직 테스트 ───
describe("통관검사 알림 - 상태 변경 시 알림 분기", () => {
  it("customs_hold 상태에서는 '통관검사 안내' 제목의 알림이 생성되어야 함", () => {
    const status = "customs_hold";
    const orderNumber = "ORD-TEST-001";
    
    let notificationTitle: string;
    let notificationMessage: string;
    
    if (status === "customs_hold") {
      notificationTitle = "통관검사 안내";
      notificationMessage = `주문번호 ${orderNumber}: 고객님의 주문 상품이 통관검사 대상으로 선정되었습니다. 통관 절차가 완료되면 배송이 재개됩니다.`;
    } else {
      notificationTitle = "주문 상태가 변경되었습니다";
      notificationMessage = `주문번호 ${orderNumber}: ${status}`;
    }

    expect(notificationTitle).toBe("통관검사 안내");
    expect(notificationMessage).toContain("통관검사 대상");
    expect(notificationMessage).toContain("배송이 재개");
    expect(notificationMessage).toContain(orderNumber);
  });

  it("일반 상태에서는 기존 '주문 상태가 변경되었습니다' 알림이 생성되어야 함", () => {
    const status = "shipping";
    const orderNumber = "ORD-TEST-002";
    
    const statusLabels: Record<string, string> = {
      pending: "주문접수", paid: "결제완료", preparing: "상품준비중",
      shipping: "배송중", delivered: "배송완료", cancelled: "주문취소", refunded: "환불완료",
    };

    let notificationTitle: string;
    let notificationMessage: string;
    
    if (status === "customs_hold") {
      notificationTitle = "통관검사 안내";
      notificationMessage = `주문번호 ${orderNumber}: 통관검사 대상`;
    } else {
      const statusText = statusLabels[status] || status;
      notificationTitle = "주문 상태가 변경되었습니다";
      notificationMessage = `주문번호 ${orderNumber}: ${statusText}`;
    }

    expect(notificationTitle).toBe("주문 상태가 변경되었습니다");
    expect(notificationMessage).toContain("배송중");
    expect(notificationMessage).not.toContain("통관검사 대상");
  });

  it("customs_hold 상태에서 이메일 제목이 올바르게 생성되어야 함", () => {
    const orderNumber = "ORD-20260219-001";
    const emailSubject = `[탈모학교] 통관검사 안내 - 주문번호 ${orderNumber}`;
    
    expect(emailSubject).toContain("[탈모학교]");
    expect(emailSubject).toContain("통관검사 안내");
    expect(emailSubject).toContain(orderNumber);
  });
});

// ─── 알림 링크 테스트 ───
describe("통관검사 알림 - 알림 링크", () => {
  it("customs_hold 알림 링크가 주문 상세 페이지로 연결되어야 함", () => {
    const orderId = 42;
    const link = `/mypage/orders/${orderId}`;
    
    expect(link).toBe("/mypage/orders/42");
    expect(link).toMatch(/^\/mypage\/orders\/\d+$/);
  });

  it("일반 상태 알림 링크가 주문 목록 페이지로 연결되어야 함", () => {
    const link = "/mypage/orders";
    expect(link).toBe("/mypage/orders");
  });
});

// ─── shippingSyncJob 통관검사 감지 테스트 ───
describe("통관검사 알림 - 배송 동기화 연동", () => {
  it("import_customs 배송 상태가 감지되면 주문을 customs_hold로 변경해야 함", () => {
    const shipmentStatus = "import_customs";
    const shouldUpdateToCustomsHold = shipmentStatus === "import_customs";
    
    expect(shouldUpdateToCustomsHold).toBe(true);
  });

  it("일반 배송 상태에서는 customs_hold로 변경하지 않아야 함", () => {
    const normalStatuses = ["in_transit", "out_for_delivery", "picked_up", "pending"];
    
    for (const status of normalStatuses) {
      const shouldUpdateToCustomsHold = status === "import_customs";
      expect(shouldUpdateToCustomsHold).toBe(false);
    }
  });
});

// ─── CustomsHoldEmailData 인터페이스 테스트 ───
describe("통관검사 알림 - 데이터 구조", () => {
  it("CustomsHoldEmailData 인터페이스가 올바른 필드를 가져야 함", async () => {
    const { generateCustomsHoldEmail } = await import("./_core/customsHoldEmail");
    
    const data = {
      customerName: "테스트 고객",
      orderNumber: "ORD-12345",
      orderId: 99,
    };

    // 함수가 에러 없이 실행되어야 함
    expect(() => generateCustomsHoldEmail(data)).not.toThrow();
    
    // 결과가 문자열이어야 함
    const result = generateCustomsHoldEmail(data);
    expect(typeof result).toBe("string");
    expect(result.length).toBeGreaterThan(0);
  });
});

// ─── 배송 동기화 시 통관검사 자동 알림 로직 테스트 ───
describe("통관검사 알림 - 자동 상태 전환 로직", () => {
  it("배송 상태가 import_customs이고 주문 상태가 shipping이면 customs_hold로 전환해야 함", () => {
    const shipmentStatus = "import_customs";
    const currentOrderStatus = "shipping";
    
    const shouldTransition = shipmentStatus === "import_customs" && currentOrderStatus !== "customs_hold";
    expect(shouldTransition).toBe(true);
  });

  it("이미 customs_hold 상태인 주문은 다시 전환하지 않아야 함", () => {
    const shipmentStatus = "import_customs";
    const currentOrderStatus = "customs_hold";
    
    const shouldTransition = shipmentStatus === "import_customs" && currentOrderStatus !== "customs_hold";
    expect(shouldTransition).toBe(false);
  });

  it("통관 완료 후 배송 재개 시 customs_hold에서 shipping으로 전환해야 함", () => {
    const shipmentStatus = "in_transit";
    const currentOrderStatus = "customs_hold";
    
    const shouldResumeShipping = currentOrderStatus === "customs_hold" && 
      ["in_transit", "out_for_delivery"].includes(shipmentStatus);
    expect(shouldResumeShipping).toBe(true);
  });
});
