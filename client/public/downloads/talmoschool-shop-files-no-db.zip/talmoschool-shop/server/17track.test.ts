import { describe, it, expect } from "vitest";
import { registerTracking, getTrackingInfo } from "./_core/17trackApi";

describe("17track API Integration", () => {
  const testTrackingNumber = "LP081795723IN";

  it("should have API key configured", () => {
    expect(process.env.SEVENTEENTRACK_API_KEY).toBeDefined();
    expect(process.env.SEVENTEENTRACK_API_KEY).not.toBe("");
  });

  it("should register tracking number successfully", async () => {
    const result = await registerTracking(testTrackingNumber);
    // 이미 등록된 경우에도 성공으로 간주
    expect(typeof result).toBe("boolean");
  }, 30000);

  it("should get tracking info for LP081795723IN", async () => {
    // 먼저 등록
    await registerTracking(testTrackingNumber);
    
    // 추적 정보 조회
    const trackingInfo = await getTrackingInfo(testTrackingNumber);
    
    expect(trackingInfo).not.toBeNull();
    if (trackingInfo) {
      expect(trackingInfo.number).toBe(testTrackingNumber);
      expect(trackingInfo.status).toBeGreaterThanOrEqual(0);
      expect(trackingInfo.status).toBeLessThanOrEqual(8);
      expect(trackingInfo.statusText).toBeTruthy();
      
      console.log("Tracking Info:", {
        number: trackingInfo.number,
        status: trackingInfo.statusText,
        subStatus: trackingInfo.subStatusText,
        eventsCount: trackingInfo.events.length,
        lastEvent: trackingInfo.lastEvent?.description,
      });
    }
  }, 30000);

  it("should return events in chronological order (newest first)", async () => {
    await registerTracking(testTrackingNumber);
    const trackingInfo = await getTrackingInfo(testTrackingNumber);
    
    expect(trackingInfo).not.toBeNull();
    if (trackingInfo && trackingInfo.events.length > 1) {
      // 첫 번째 이벤트가 가장 최신이어야 함
      expect(trackingInfo.events[0].time).toBeGreaterThanOrEqual(trackingInfo.events[1].time);
    }
  }, 30000);

  it("should handle invalid tracking number gracefully", async () => {
    const invalidNumber = "INVALID123456789";
    const result = await registerTracking(invalidNumber);
    // 실패하거나 성공할 수 있음 (17track이 자동으로 처리)
    expect(typeof result).toBe("boolean");
  }, 30000);
});
