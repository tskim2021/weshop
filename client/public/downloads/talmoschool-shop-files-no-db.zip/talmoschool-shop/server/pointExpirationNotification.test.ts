import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import * as db from "./db";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTestContext(user: { id: number; role: "user" | "admin" } | null): TrpcContext {
  if (!user) {
    return {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
    };
  }
  const authenticatedUser: AuthenticatedUser = {
    id: user.id,
    openId: `test-user-${user.id}`,
    email: `test${user.id}@example.com`,
    name: `테스트 유저 ${user.id}`,
    loginMethod: "oauth",
    role: user.role,
    phone: null,
    grade: "bronze",
    points: 0,
    totalSpent: 0,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user: authenticatedUser,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };
}

describe("Point Expiration Notification System", () => {
  const testAdminId = 1;

  describe("getUsersWithExpiringPoints (만료 예정 포인트 사용자 조회)", () => {
    it("만료 예정 포인트가 있는 사용자 목록을 조회할 수 있다", async () => {
      const users = await db.getUsersWithExpiringPoints(7);

      expect(Array.isArray(users)).toBe(true);
      
      // 결과가 있다면 구조 검증
      if (users.length > 0) {
        const user = users[0];
        expect(user).toHaveProperty("userId");
        expect(user).toHaveProperty("email");
        expect(user).toHaveProperty("name");
        expect(user).toHaveProperty("totalExpiring");
        expect(user).toHaveProperty("earliestExpiration");
        expect(typeof user.userId).toBe("number");
        expect(typeof user.totalExpiring).toBe("number");
        expect(user.earliestExpiration).toBeInstanceOf(Date);
      }
    });

    it("만료 예정 기간을 조정할 수 있다", async () => {
      const users7Days = await db.getUsersWithExpiringPoints(7);
      const users30Days = await db.getUsersWithExpiringPoints(30);

      // 30일 범위가 7일 범위보다 크거나 같아야 함
      expect(users30Days.length).toBeGreaterThanOrEqual(users7Days.length);
    });
  });

  describe("adminTestExpirationNotification (관리자 알림 테스트)", () => {
    it("관리자는 만료 예정 알림을 테스트할 수 있다", async () => {
      const ctx = createTestContext({ id: testAdminId, role: "admin" });
      const caller = appRouter.createCaller(ctx);

      const result = await caller.user.adminTestExpirationNotification();

      expect(result).toBeDefined();
      expect(result).toHaveProperty("totalUsers");
      expect(result).toHaveProperty("emailSent");
      expect(result).toHaveProperty("pushSent");
      expect(result).toHaveProperty("failed");
      expect(typeof result.totalUsers).toBe("number");
      expect(typeof result.emailSent).toBe("number");
      expect(typeof result.pushSent).toBe("number");
      expect(typeof result.failed).toBe("number");
      expect(result.totalUsers).toBeGreaterThanOrEqual(0);
      expect(result.emailSent).toBeGreaterThanOrEqual(0);
      expect(result.pushSent).toBeGreaterThanOrEqual(0);
      expect(result.failed).toBeGreaterThanOrEqual(0);
    });

    it("일반 사용자는 알림 테스트를 실행할 수 없다", async () => {
      const ctx = createTestContext({ id: 2, role: "user" });
      const caller = appRouter.createCaller(ctx);

      await expect(caller.user.adminTestExpirationNotification()).rejects.toThrow();
    });
  });

  describe("Notification Integration (알림 통합 테스트)", () => {
    it("포인트 적립 후 만료 예정 사용자 목록에 포함된다", async () => {
      const testUserId = 1;
      
      // 현재 만료 정책을 1개월로 설정
      await db.setPointExpirationMonths(1);
      
      // 포인트 적립
      await db.addPoints(testUserId, 1000, "earn", "알림 테스트용 적립");
      
      // 30일 이내 만료 예정 사용자 조회
      const users = await db.getUsersWithExpiringPoints(30);
      
      // 테스트 사용자가 목록에 포함되어야 함
      const testUser = users.find(u => u.userId === testUserId);
      expect(testUser).toBeDefined();
      
      if (testUser) {
        expect(testUser.totalExpiring).toBeGreaterThan(0);
        expect(testUser.earliestExpiration).toBeInstanceOf(Date);
        expect(testUser.earliestExpiration.getTime()).toBeGreaterThan(Date.now());
      }
    });
  });

  describe("Notification Content (알림 내용 검증)", () => {
    it("이메일 알림 함수가 정상적으로 호출된다", async () => {
      const { sendPointExpirationEmail } = await import("./pointExpirationNotification");
      
      const result = await sendPointExpirationEmail(
        "test@example.com",
        "테스트 사용자",
        5000,
        new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
      );
      
      // 이메일 발송 함수가 boolean을 반환해야 함
      expect(typeof result).toBe("boolean");
    });

    it("푸시 알림 함수가 정상적으로 호출된다", async () => {
      const { sendPointExpirationPush } = await import("./pointExpirationNotification");
      
      const result = await sendPointExpirationPush(
        1,
        5000,
        new Date(Date.now() + 7 * 24 * 60 * 60 * 1000)
      );
      
      // 푸시 알림 함수가 boolean을 반환해야 함
      expect(typeof result).toBe("boolean");
    });
  });
});
