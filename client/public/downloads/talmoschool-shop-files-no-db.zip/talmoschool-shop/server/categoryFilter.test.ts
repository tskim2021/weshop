import { describe, it, expect, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createContext(user?: Partial<AuthenticatedUser>): TrpcContext {
  const defaultUser: AuthenticatedUser = {
    id: 1,
    openId: "test-user-1",
    email: "test@example.com",
    name: "테스트 유저",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user: user === undefined ? null : { ...defaultUser, ...user },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

const publicCtx = createContext(undefined);
const userCtx = createContext({ id: 1, name: "테스트 유저" });

// Mock DB functions
vi.mock("./db", async () => {
  const actual = await vi.importActual("./db");
  
  const mockDiscussions = [
    {
      id: 1, userId: 1, categoryId: null, title: "일반 토론", content: "내용",
      tags: null, viewCount: 10, likeCount: 3, commentCount: 2,
      isPinned: 0, isClosed: 0, isHidden: 0,
      createdAt: new Date(), updatedAt: new Date(), userName: "유저1",
    },
    {
      id: 2, userId: 2, categoryId: 1, title: "카테고리1 토론", content: "내용2",
      tags: null, viewCount: 5, likeCount: 1, commentCount: 0,
      isPinned: 0, isClosed: 0, isHidden: 0,
      createdAt: new Date(), updatedAt: new Date(), userName: "유저2",
    },
    {
      id: 3, userId: 1, categoryId: 2, title: "카테고리2 토론", content: "내용3",
      tags: null, viewCount: 8, likeCount: 2, commentCount: 1,
      isPinned: 0, isClosed: 0, isHidden: 0,
      createdAt: new Date(), updatedAt: new Date(), userName: "유저1",
    },
  ];

  const mockPosts = [
    {
      id: 1, boardId: 1, userId: 1, title: "정보글1", content: "내용1",
      viewCount: 10, commentCount: 2, isPinned: 0, isHidden: 0,
      categoryId: null, createdAt: new Date(), updatedAt: new Date(), userName: "유저1",
    },
    {
      id: 2, boardId: 1, userId: 2, title: "정보글2", content: "내용2",
      viewCount: 5, commentCount: 0, isPinned: 0, isHidden: 0,
      categoryId: 1, createdAt: new Date(), updatedAt: new Date(), userName: "유저2",
    },
    {
      id: 3, boardId: 1, userId: 1, title: "정보글3", content: "내용3",
      viewCount: 8, commentCount: 1, isPinned: 0, isHidden: 0,
      categoryId: 2, createdAt: new Date(), updatedAt: new Date(), userName: "유저1",
    },
  ];

  return {
    ...actual,
    // Discussion mocks
    getDiscussions: vi.fn().mockImplementation(async (opts: any) => {
      let filtered = [...mockDiscussions];
      if (opts.categoryId) {
        filtered = filtered.filter(d => d.categoryId === opts.categoryId);
      }
      if (opts.search) {
        filtered = filtered.filter(d => d.title.includes(opts.search) || d.content.includes(opts.search));
      }
      return { discussions: filtered, total: filtered.length };
    }),
    getPopularDiscussions: vi.fn().mockResolvedValue([mockDiscussions[0]]),
    getDiscussionById: vi.fn().mockImplementation(async (id: number) => {
      return mockDiscussions.find(d => d.id === id) || null;
    }),
    createDiscussion: vi.fn().mockResolvedValue({ id: 4 }),
    updateDiscussion: vi.fn().mockResolvedValue(undefined),
    deleteDiscussion: vi.fn().mockResolvedValue(undefined),
    incrementDiscussionViewCount: vi.fn().mockResolvedValue(undefined),
    getDiscussionComments: vi.fn().mockResolvedValue([]),
    createDiscussionComment: vi.fn().mockResolvedValue({ id: 1 }),
    updateDiscussionComment: vi.fn().mockResolvedValue(undefined),
    deleteDiscussionComment: vi.fn().mockResolvedValue(undefined),
    toggleDiscussionLike: vi.fn().mockResolvedValue({ liked: true }),
    getUserDiscussionLikes: vi.fn().mockResolvedValue([]),
    getDiscussionCommentById: vi.fn().mockResolvedValue(null),
    createNotification: vi.fn().mockResolvedValue(undefined),
    adminToggleDiscussionPin: vi.fn().mockResolvedValue(undefined),
    adminToggleDiscussionClose: vi.fn().mockResolvedValue(undefined),
    adminToggleDiscussionHide: vi.fn().mockResolvedValue(undefined),

    // InfoBoard mocks
    getBoardBySlug: vi.fn().mockResolvedValue({ id: 1, name: "정보나눔", slug: "info", boardType: "info" }),
    getPosts: vi.fn().mockImplementation(async (boardId: number, page: number, limit: number, search?: string, categoryId?: number) => {
      let filtered = [...mockPosts];
      if (categoryId) {
        filtered = filtered.filter(p => p.categoryId === categoryId);
      }
      if (search) {
        filtered = filtered.filter(p => p.title.includes(search));
      }
      return { posts: filtered, total: filtered.length };
    }),
    getPostById: vi.fn().mockImplementation(async (id: number) => {
      return mockPosts.find(p => p.id === id) || null;
    }),
    createPost: vi.fn().mockResolvedValue(4),
    updatePost: vi.fn().mockResolvedValue(undefined),
    deletePost: vi.fn().mockResolvedValue(undefined),
    getComments: vi.fn().mockResolvedValue([]),
    createComment: vi.fn().mockResolvedValue({ id: 1 }),
    deleteComment: vi.fn().mockResolvedValue(undefined),
    getDb: vi.fn().mockResolvedValue(null),
  };
});

describe("카테고리 필터 기능 테스트", () => {
  const caller = appRouter.createCaller;

  describe("토론광장 카테고리 필터", () => {
    it("카테고리 없이 전체 토론 목록을 조회할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.list({});
      expect(result.discussions.length).toBe(3);
      expect(result.total).toBe(3);
    });

    it("카테고리 ID로 필터링된 토론 목록을 조회할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.list({ categoryId: 1 });
      expect(result.discussions.length).toBe(1);
      expect(result.discussions[0].categoryId).toBe(1);
    });

    it("존재하지 않는 카테고리로 필터링하면 빈 목록을 반환한다", async () => {
      const result = await caller(publicCtx).discussion.list({ categoryId: 999 });
      expect(result.discussions.length).toBe(0);
      expect(result.total).toBe(0);
    });

    it("카테고리 필터와 검색을 동시에 사용할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.list({ categoryId: 1, search: "카테고리1" });
      expect(result.discussions.length).toBe(1);
    });

    it("카테고리 필터와 정렬을 동시에 사용할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.list({ categoryId: 2, sort: "popular" });
      expect(result.discussions.length).toBe(1);
    });

    it("토론 생성 시 카테고리를 지정할 수 있다", async () => {
      const result = await caller(userCtx).discussion.create({
        title: "카테고리 지정 토론",
        content: "내용",
        categoryId: 1,
      });
      expect(result).toBeDefined();
      expect(result.id).toBeDefined();
    });

    it("토론 생성 시 카테고리 없이도 가능하다", async () => {
      const result = await caller(userCtx).discussion.create({
        title: "카테고리 없는 토론",
        content: "내용",
      });
      expect(result).toBeDefined();
    });
  });

  describe("정보나눔 카테고리 필터", () => {
    it("카테고리 없이 전체 게시글 목록을 조회할 수 있다", async () => {
      const result = await caller(publicCtx).infoBoard.posts({ page: 1, limit: 20 });
      expect(result.posts.length).toBe(3);
      expect(result.total).toBe(3);
    });

    it("카테고리 ID로 필터링된 게시글 목록을 조회할 수 있다", async () => {
      const result = await caller(publicCtx).infoBoard.posts({ page: 1, limit: 20, categoryId: 1 });
      expect(result.posts.length).toBe(1);
      expect(result.posts[0].categoryId).toBe(1);
    });

    it("존재하지 않는 카테고리로 필터링하면 빈 목록을 반환한다", async () => {
      const result = await caller(publicCtx).infoBoard.posts({ page: 1, limit: 20, categoryId: 999 });
      expect(result.posts.length).toBe(0);
      expect(result.total).toBe(0);
    });

    it("카테고리 필터와 검색을 동시에 사용할 수 있다", async () => {
      const result = await caller(publicCtx).infoBoard.posts({ page: 1, limit: 20, categoryId: 1, search: "정보글" });
      expect(result.posts.length).toBe(1);
    });

    it("게시글 생성 시 카테고리를 지정할 수 있다", async () => {
      const result = await caller(userCtx).infoBoard.createPost({
        title: "카테고리 지정 정보글",
        content: "내용",
        categoryId: 1,
      });
      expect(result).toBeDefined();
    });

    it("게시글 생성 시 카테고리 없이도 가능하다", async () => {
      const result = await caller(userCtx).infoBoard.createPost({
        title: "카테고리 없는 정보글",
        content: "내용",
      });
      expect(result).toBeDefined();
    });

    it("페이지네이션과 카테고리 필터를 동시에 사용할 수 있다", async () => {
      const result = await caller(publicCtx).infoBoard.posts({ page: 1, limit: 10, categoryId: 2 });
      expect(result.posts.length).toBe(1);
      expect(result.total).toBe(1);
    });
  });
});
