import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAdminContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "admin-user",
    email: "admin@example.com",
    name: "Admin User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };

  return { ctx };
}

function createUserContext(userId = 2): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: userId,
    openId: "test-user",
    email: "user@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };

  return { ctx };
}

describe("shipping.policies", () => {
  it("returns free shipping with EMS carrier info", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.shipping.policies();

    expect(result).toEqual({
      freeShipping: true,
      carrier: "EMS",
      estimatedDays: 10,
    });
  });
});

describe("shipping.carriers", () => {
  it("returns active carriers list", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.shipping.carriers();

    expect(Array.isArray(result)).toBe(true);
    // Should have at least EMS carrier
    if (result.length > 0) {
      const emsCarrier = result.find(
        (c: any) => c.code === "ems" || c.code === "epost_ems"
      );
      if (emsCarrier) {
        expect(emsCarrier.name).toBeTruthy();
        expect(emsCarrier.isActive).toBe(1);
      }
    }
  });
});

describe("shipping.trackOrder", () => {
  it("throws NOT_FOUND for non-existent order", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.shipping.trackOrder({ orderId: 999999 })
    ).rejects.toThrow();
  });
});

describe("shipping.adminCreateShipment", () => {
  it("throws NOT_FOUND for non-existent order", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.shipping.adminCreateShipment({
        orderId: 999999,
        trackingNumber: "EE123456789KR",
      })
    ).rejects.toThrow();
  });

  it("requires admin role", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.shipping.adminCreateShipment({
        orderId: 1,
        trackingNumber: "EE123456789KR",
      })
    ).rejects.toThrow();
  });
});

describe("shipping.adminBulkCreateShipment", () => {
  it("requires admin role", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.shipping.adminBulkCreateShipment({
        shipments: [{ orderId: 1, trackingNumber: "EE111111111KR" }],
      })
    ).rejects.toThrow();
  });
});

describe("shipping.requestReturn", () => {
  it("throws NOT_FOUND for non-existent order", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.shipping.requestReturn({
        orderId: 999999,
        type: "return",
        reason: "단순 변심",
      })
    ).rejects.toThrow();
  });
});

describe("shipping.refreshTracking", () => {
  it("throws NOT_FOUND for non-existent order", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.shipping.refreshTracking({ orderId: 999999 })
    ).rejects.toThrow();
  });
});

describe("shipping.adminShippingStats", () => {
  it("requires admin role", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.shipping.adminShippingStats()).rejects.toThrow();
  });

  it("returns stats for admin", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.shipping.adminShippingStats();
    expect(result).toBeDefined();
  });
});

describe("shipping.adminShipments", () => {
  it("requires admin role", async () => {
    const { ctx } = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(caller.shipping.adminShipments()).rejects.toThrow();
  });

  it("returns shipments list for admin", async () => {
    const { ctx } = createAdminContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.shipping.adminShipments();
    expect(result).toHaveProperty("shipments");
    expect(result).toHaveProperty("total");
    expect(Array.isArray(result.shipments)).toBe(true);
  });
});
