import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock 17track API
vi.mock("./_core/17trackApi", () => ({
  getTrackingInfo: vi.fn(),
  mapStatusToSystem: vi.fn((s: number) => {
    const map: Record<number, string> = { 0: "pending", 1: "accepted", 2: "in_transit", 3: "export_customs", 4: "out_for_delivery", 5: "out_for_delivery", 6: "delivered", 7: "failed" };
    return map[s] || "in_transit";
  }),
}));

// Mock db
vi.mock("./db", () => ({
  getActiveShipments: vi.fn(),
  updateShipmentStatusOnly: vi.fn(),
  getShippingHistoryByShipmentId: vi.fn(),
  createShippingHistory: vi.fn(),
  getOrderById: vi.fn(),
  updateOrderStatus: vi.fn(),
  createNotification: vi.fn(),
  getUserById: vi.fn(),
  getOrderItems: vi.fn(),
}));

// Mock email
vi.mock("./_core/email", () => ({
  sendEmail: vi.fn().mockResolvedValue(true),
  generateReviewRequestEmail: vi.fn().mockReturnValue("<html>review</html>"),
}));

import { runShippingSyncJob } from "./jobs/shippingSyncJob";
import { getTrackingInfo } from "./_core/17trackApi";
import * as db from "./db";

describe("배송 동기화 Job", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("활성 배송이 없으면 즉시 반환", async () => {
    vi.mocked(db.getActiveShipments).mockResolvedValue([]);
    
    const result = await runShippingSyncJob();
    
    expect(result.syncedCount).toBe(0);
    expect(result.total).toBe(0);
    expect(getTrackingInfo).not.toHaveBeenCalled();
  });

  it("활성 배송의 추적 정보를 동기화", async () => {
    vi.mocked(db.getActiveShipments).mockResolvedValue([
      { id: 1, orderId: 100, trackingNumber: "LP123456789IN", carrierId: 1, status: "accepted", estimatedDeliveryDate: null, actualDeliveryDate: null, createdAt: new Date(), updatedAt: new Date() },
    ] as any);
    
    vi.mocked(getTrackingInfo).mockResolvedValue({
      status: 2,
      events: [
        { description: "국제운송 중", location: "인천", details: "국제운송 중입니다", time: Date.now() - 3600000 },
      ],
      estimatedDelivery: null,
      carrier: "India Post",
    });
    
    vi.mocked(db.getShippingHistoryByShipmentId).mockResolvedValue([]);
    vi.mocked(db.createShippingHistory).mockResolvedValue(1);
    
    const result = await runShippingSyncJob();
    
    expect(result.syncedCount).toBe(1);
    expect(db.updateShipmentStatusOnly).toHaveBeenCalledWith(1, expect.any(String));
    expect(db.createShippingHistory).toHaveBeenCalledTimes(1);
  });

  it("중복 이벤트는 저장하지 않음", async () => {
    const eventTime = Date.now() - 3600000;
    
    vi.mocked(db.getActiveShipments).mockResolvedValue([
      { id: 1, orderId: 100, trackingNumber: "LP123456789IN", carrierId: 1, status: "in_transit", estimatedDeliveryDate: null, actualDeliveryDate: null, createdAt: new Date(), updatedAt: new Date() },
    ] as any);
    
    vi.mocked(getTrackingInfo).mockResolvedValue({
      status: 2,
      events: [
        { description: "국제운송 중", location: "인천", details: "국제운송 중입니다", time: eventTime },
      ],
      estimatedDelivery: null,
      carrier: "India Post",
    });
    
    // 이미 동일한 이벤트가 DB에 존재
    vi.mocked(db.getShippingHistoryByShipmentId).mockResolvedValue([
      { id: 1, shipmentId: 1, status: "in_transit", location: "인천", description: "국제운송 중입니다", rawStatus: null, occurredAt: new Date(eventTime), createdAt: new Date() },
    ] as any);
    
    const result = await runShippingSyncJob();
    
    expect(result.syncedCount).toBe(1);
    expect(db.createShippingHistory).not.toHaveBeenCalled();
  });

  it("배송 완료 시 주문 상태 변경 및 알림 발송", async () => {
    vi.mocked(db.getActiveShipments).mockResolvedValue([
      { id: 1, orderId: 100, trackingNumber: "LP123456789IN", carrierId: 1, status: "out_for_delivery", estimatedDeliveryDate: null, actualDeliveryDate: null, createdAt: new Date(), updatedAt: new Date() },
    ] as any);
    
    vi.mocked(getTrackingInfo).mockResolvedValue({
      status: 6,
      events: [
        { description: "배달완료", location: "서울", details: "배달완료되었습니다", time: Date.now() },
      ],
      estimatedDelivery: null,
      carrier: "India Post",
    });
    
    vi.mocked(db.getShippingHistoryByShipmentId).mockResolvedValue([]);
    vi.mocked(db.createShippingHistory).mockResolvedValue(1);
    vi.mocked(db.getOrderById).mockResolvedValue({
      id: 100, userId: 1, orderNumber: "ORD-100", status: "shipping",
    } as any);
    vi.mocked(db.getUserById).mockResolvedValue({
      id: 1, name: "테스트", email: "test@test.com",
    } as any);
    vi.mocked(db.getOrderItems).mockResolvedValue([
      { id: 1, productName: "테스트 상품" },
    ] as any);
    
    const result = await runShippingSyncJob();
    
    expect(result.syncedCount).toBe(1);
    expect(db.updateOrderStatus).toHaveBeenCalledWith(100, "delivered");
    expect(db.createNotification).toHaveBeenCalledWith(
      1, "order", "배송이 완료되었습니다",
      expect.stringContaining("ORD-100"),
      expect.stringContaining("/mypage/orders/100")
    );
  });

  it("API 호출 실패 시 failedCount 증가", async () => {
    vi.mocked(db.getActiveShipments).mockResolvedValue([
      { id: 1, orderId: 100, trackingNumber: "INVALID", carrierId: 1, status: "accepted", estimatedDeliveryDate: null, actualDeliveryDate: null, createdAt: new Date(), updatedAt: new Date() },
    ] as any);
    
    vi.mocked(getTrackingInfo).mockResolvedValue(null);
    
    const result = await runShippingSyncJob();
    
    expect(result.failedCount).toBe(1);
    expect(result.syncedCount).toBe(0);
  });

  it("여러 배송을 순차적으로 동기화", async () => {
    vi.mocked(db.getActiveShipments).mockResolvedValue([
      { id: 1, orderId: 100, trackingNumber: "LP111111111IN", carrierId: 1, status: "accepted", estimatedDeliveryDate: null, actualDeliveryDate: null, createdAt: new Date(), updatedAt: new Date() },
      { id: 2, orderId: 200, trackingNumber: "LP222222222IN", carrierId: 1, status: "in_transit", estimatedDeliveryDate: null, actualDeliveryDate: null, createdAt: new Date(), updatedAt: new Date() },
    ] as any);
    
    vi.mocked(getTrackingInfo).mockResolvedValue({
      status: 2,
      events: [
        { description: "운송 중", location: "", details: "운송 중입니다", time: Date.now() },
      ],
      estimatedDelivery: null,
      carrier: "India Post",
    });
    
    vi.mocked(db.getShippingHistoryByShipmentId).mockResolvedValue([]);
    vi.mocked(db.createShippingHistory).mockResolvedValue(1);
    
    const result = await runShippingSyncJob();
    
    expect(result.syncedCount).toBe(2);
    expect(result.total).toBe(2);
    expect(getTrackingInfo).toHaveBeenCalledTimes(2);
  });
});

describe("국제배송 상태 매핑", () => {
  it("통관 이벤트가 있으면 export_customs로 매핑 (17track status=3)", async () => {
    vi.mocked(db.getActiveShipments).mockResolvedValue([
      { id: 1, orderId: 100, trackingNumber: "LP123456789IN", carrierId: 1, status: "in_transit", estimatedDeliveryDate: null, actualDeliveryDate: null, createdAt: new Date(), updatedAt: new Date() },
    ] as any);
    
    vi.mocked(getTrackingInfo).mockResolvedValue({
      status: 3,
      events: [
        { description: "출발국 통관", location: "출발국 세관", details: "출발국 통관 처리 중", time: Date.now() },
      ],
      estimatedDelivery: null,
      carrier: "India Post",
    });
    
    vi.mocked(db.getShippingHistoryByShipmentId).mockResolvedValue([]);
    vi.mocked(db.createShippingHistory).mockResolvedValue(1);
    
    await runShippingSyncJob();
    
    expect(db.updateShipmentStatusOnly).toHaveBeenCalledWith(1, "export_customs");
  });

  it("국제우편물류센터 이벤트가 있으면 import_customs로 매핑", async () => {
    vi.mocked(db.getActiveShipments).mockResolvedValue([
      { id: 1, orderId: 100, trackingNumber: "LP123456789IN", carrierId: 1, status: "in_transit", estimatedDeliveryDate: null, actualDeliveryDate: null, createdAt: new Date(), updatedAt: new Date() },
    ] as any);
    
    vi.mocked(getTrackingInfo).mockResolvedValue({
      status: 3,
      events: [
        { description: "통관검사대기", location: "국제우편물류센터", details: "통관검사대기 - 국제우편물류센터", time: Date.now() },
        { description: "교환국 도착", location: "국제우편물류센터", details: "교환국 도착 - 국제우편물류센터", time: Date.now() - 3600000 },
      ],
      estimatedDelivery: null,
      carrier: "India Post",
    });
    
    vi.mocked(db.getShippingHistoryByShipmentId).mockResolvedValue([]);
    vi.mocked(db.createShippingHistory).mockResolvedValue(1);
    
    await runShippingSyncJob();
    
    expect(db.updateShipmentStatusOnly).toHaveBeenCalledWith(1, "import_customs");
  });
});
