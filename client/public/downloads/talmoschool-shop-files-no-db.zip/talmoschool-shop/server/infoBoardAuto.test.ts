import { describe, expect, it, vi, beforeEach } from "vitest";

// Mock db module
vi.mock("./db", () => {
  const mockSettings = [
    {
      id: 1,
      isEnabled: 1,
      categoryId: 2,
      generateTime: "09:00",
      topic: "건강식품 정보",
      keywords: "비타민,오메가3",
      keywordsEn: "vitamin,omega-3",
      promptTemplate: null,
      postStyle: "informative",
      autoPublish: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 2,
      isEnabled: 0,
      categoryId: null,
      generateTime: "14:00",
      topic: "운동과 건강",
      keywords: "운동,헬스",
      keywordsEn: null,
      promptTemplate: "커스텀 프롬프트",
      postStyle: "tips",
      autoPublish: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  const mockLogs = [
    {
      id: 1,
      settingId: 1,
      status: "success",
      postId: 100,
      generatedTitle: "비타민 D의 효능과 올바른 섭취법",
      errorMessage: null,
      executionTimeMs: 5200,
      triggeredBy: "scheduler",
      createdAt: new Date(),
    },
    {
      id: 2,
      settingId: 1,
      status: "failed",
      postId: null,
      generatedTitle: null,
      errorMessage: "LLM 응답 없음",
      executionTimeMs: 3000,
      triggeredBy: "manual",
      createdAt: new Date(),
    },
  ];

  return {
    getInfoBoardAutoSettings: vi.fn().mockResolvedValue(mockSettings),
    getInfoBoardAutoSettingById: vi.fn().mockImplementation(async (id: number) => {
      return mockSettings.find(s => s.id === id);
    }),
    getEnabledInfoBoardAutoSettings: vi.fn().mockResolvedValue(
      mockSettings.filter(s => s.isEnabled === 1)
    ),
    createInfoBoardAutoSetting: vi.fn().mockResolvedValue({ id: 3 }),
    updateInfoBoardAutoSetting: vi.fn().mockResolvedValue(undefined),
    deleteInfoBoardAutoSetting: vi.fn().mockResolvedValue(undefined),
    getInfoBoardAutoLogs: vi.fn().mockResolvedValue({ logs: mockLogs, total: 2 }),
    createInfoBoardAutoLog: vi.fn().mockResolvedValue({ id: 3 }),
    getBoardBySlug: vi.fn().mockResolvedValue({ id: 5, name: "정보나눔", slug: "info" }),
    createPost: vi.fn().mockResolvedValue(101),
    getDb: vi.fn().mockResolvedValue({}),
  };
});

// Mock LLM
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{
      message: {
        content: JSON.stringify({
          title: "비타민 C의 놀라운 효능 5가지",
          content: "## 비타민 C란?\n\n비타민 C는 수용성 비타민으로...\n\n## 주요 효능\n\n1. 면역력 강화\n2. 항산화 작용\n3. 콜라겐 합성\n4. 철분 흡수 촉진\n5. 피부 건강\n\n※ 이 글은 정보 제공 목적으로 작성되었으며, 전문적인 의료 조언을 대체하지 않습니다."
        })
      }
    }]
  }),
}));

// Mock scheduler
vi.mock("./jobs/infoBoardScheduler", () => ({
  restartInfoBoardScheduler: vi.fn().mockResolvedValue(undefined),
  getInfoBoardSchedulerStatus: vi.fn().mockReturnValue({ isActive: true, scheduleTime: "09:00" }),
}));

import * as db from "./db";

describe("InfoBoard Auto Post - DB Functions", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("getInfoBoardAutoSettings returns all settings", async () => {
    const settings = await db.getInfoBoardAutoSettings();
    expect(settings).toHaveLength(2);
    expect(settings[0].topic).toBe("건강식품 정보");
    expect(settings[1].topic).toBe("운동과 건강");
  });

  it("getInfoBoardAutoSettingById returns correct setting", async () => {
    const setting = await db.getInfoBoardAutoSettingById(1);
    expect(setting).toBeDefined();
    expect(setting?.topic).toBe("건강식품 정보");
    expect(setting?.postStyle).toBe("informative");
  });

  it("getInfoBoardAutoSettingById returns undefined for non-existent id", async () => {
    const setting = await db.getInfoBoardAutoSettingById(999);
    expect(setting).toBeUndefined();
  });

  it("getEnabledInfoBoardAutoSettings returns only enabled settings", async () => {
    const settings = await db.getEnabledInfoBoardAutoSettings();
    expect(settings).toHaveLength(1);
    expect(settings[0].isEnabled).toBe(1);
  });

  it("createInfoBoardAutoSetting returns new id", async () => {
    const result = await db.createInfoBoardAutoSetting({
      topic: "새 주제",
      generateTime: "10:00",
      postStyle: "guide",
      autoPublish: 1,
      isEnabled: 1,
    });
    expect(result.id).toBe(3);
    expect(db.createInfoBoardAutoSetting).toHaveBeenCalledWith(expect.objectContaining({
      topic: "새 주제",
      generateTime: "10:00",
    }));
  });

  it("updateInfoBoardAutoSetting calls with correct params", async () => {
    await db.updateInfoBoardAutoSetting(1, { topic: "수정된 주제" });
    expect(db.updateInfoBoardAutoSetting).toHaveBeenCalledWith(1, { topic: "수정된 주제" });
  });

  it("deleteInfoBoardAutoSetting calls with correct id", async () => {
    await db.deleteInfoBoardAutoSetting(1);
    expect(db.deleteInfoBoardAutoSetting).toHaveBeenCalledWith(1);
  });

  it("getInfoBoardAutoLogs returns logs with total count", async () => {
    const result = await db.getInfoBoardAutoLogs(1, 1, 20);
    expect(result.logs).toHaveLength(2);
    expect(result.total).toBe(2);
    expect(result.logs[0].status).toBe("success");
    expect(result.logs[1].status).toBe("failed");
  });
});

describe("InfoBoard Auto Post - Generator Service", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("generateInfoBoardPost creates a post successfully", async () => {
    const { generateInfoBoardPost } = await import("./services/infoBoardGenerator");
    
    const setting = {
      id: 1,
      isEnabled: 1,
      categoryId: 2,
      generateTime: "09:00",
      topic: "건강식품 정보",
      keywords: "비타민,오메가3",
      keywordsEn: "vitamin,omega-3",
      promptTemplate: null,
      postStyle: "informative" as const,
      autoPublish: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const result = await generateInfoBoardPost(setting, 1, "manual");
    
    expect(result.success).toBe(true);
    expect(result.title).toBe("비타민 C의 놀라운 효능 5가지");
    expect(result.postId).toBeDefined();
    expect(db.createPost).toHaveBeenCalled();
    expect(db.createInfoBoardAutoLog).toHaveBeenCalledWith(
      expect.objectContaining({
        settingId: 1,
        status: "success",
        triggeredBy: "manual",
      })
    );
  });

  it("generateAllEnabledInfoBoardPosts processes all enabled settings", async () => {
    const { generateAllEnabledInfoBoardPosts } = await import("./services/infoBoardGenerator");
    
    const result = await generateAllEnabledInfoBoardPosts(1, "scheduler");
    
    expect(result.totalGenerated).toBeGreaterThanOrEqual(0);
    expect(result.results).toBeDefined();
    expect(Array.isArray(result.results)).toBe(true);
  });
});

describe("InfoBoard Auto Post - Scheduler", () => {
  it("getInfoBoardSchedulerStatus returns status", async () => {
    const { getInfoBoardSchedulerStatus } = await import("./jobs/infoBoardScheduler");
    
    const status = getInfoBoardSchedulerStatus();
    expect(status).toHaveProperty("isActive");
    expect(status).toHaveProperty("scheduleTime");
    expect(status.isActive).toBe(true);
    expect(status.scheduleTime).toBe("09:00");
  });
});

describe("InfoBoard Auto Post - Setting Validation", () => {
  it("setting has required fields", async () => {
    const settings = await db.getInfoBoardAutoSettings();
    const setting = settings[0];
    
    expect(setting).toHaveProperty("id");
    expect(setting).toHaveProperty("isEnabled");
    expect(setting).toHaveProperty("generateTime");
    expect(setting).toHaveProperty("topic");
    expect(setting).toHaveProperty("postStyle");
    expect(setting).toHaveProperty("autoPublish");
  });

  it("generateTime is in HH:mm format", async () => {
    const settings = await db.getInfoBoardAutoSettings();
    for (const s of settings) {
      expect(s.generateTime).toMatch(/^\d{2}:\d{2}$/);
    }
  });

  it("postStyle is a valid enum value", async () => {
    const validStyles = ["informative", "guide", "tips", "comparison", "news"];
    const settings = await db.getInfoBoardAutoSettings();
    for (const s of settings) {
      expect(validStyles).toContain(s.postStyle);
    }
  });

  it("log status is a valid enum value", async () => {
    const validStatuses = ["success", "failed", "skipped"];
    const result = await db.getInfoBoardAutoLogs();
    for (const log of result.logs) {
      expect(validStatuses).toContain(log.status);
    }
  });

  it("log triggeredBy is a valid enum value", async () => {
    const validTriggers = ["scheduler", "manual"];
    const result = await db.getInfoBoardAutoLogs();
    for (const log of result.logs) {
      expect(validTriggers).toContain(log.triggeredBy);
    }
  });
});
