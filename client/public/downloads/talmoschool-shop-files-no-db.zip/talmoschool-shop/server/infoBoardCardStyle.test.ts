import { describe, expect, it, vi } from "vitest";

// Mock db module
vi.mock("./db", () => {
  const mockPosts = [
    {
      id: 1,
      boardId: 5,
      userId: 1,
      title: "비타민D의 효능과 올바른 섭취법",
      content: "![비타민D](https://example.com/vitamin-d.jpg)\n\n## 비타민D란?\n\n비타민D는 지용성 비타민으로 뼈 건강에 필수적입니다.",
      images: ["https://example.com/vitamin-d.jpg"],
      categoryId: 2,
      isPinned: 0,
      isHidden: 0,
      viewCount: 42,
      commentCount: 3,
      createdAt: new Date("2026-02-20T10:00:00Z"),
      updatedAt: new Date("2026-02-20T10:00:00Z"),
      rating: null,
      productId: null,
      orderId: null,
      orderItemId: null,
      userName: "건강지킴이",
    },
    {
      id: 2,
      boardId: 5,
      userId: 2,
      title: "오메가3 지방산 섭취 가이드",
      content: "오메가3 지방산은 심혈관 건강에 도움을 주는 필수 지방산입니다. EPA와 DHA가 주요 성분이며...",
      images: null,
      categoryId: 3,
      isPinned: 1,
      isHidden: 0,
      viewCount: 128,
      commentCount: 7,
      createdAt: new Date("2026-02-19T14:00:00Z"),
      updatedAt: new Date("2026-02-19T14:00:00Z"),
      rating: null,
      productId: null,
      orderId: null,
      orderItemId: null,
      userName: "약사님",
    },
    {
      id: 3,
      boardId: 5,
      userId: 3,
      title: "프로바이오틱스 선택 가이드",
      content: "## 프로바이오틱스란?\n\n장 건강을 위한 유산균 제품 선택 시 고려해야 할 사항들을 정리했습니다.",
      images: null,
      categoryId: null,
      isPinned: 0,
      isHidden: 0,
      viewCount: 15,
      commentCount: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
      rating: null,
      productId: null,
      orderId: null,
      orderItemId: null,
      userName: null,
    },
  ];

  return {
    getBoardBySlug: vi.fn().mockResolvedValue({ id: 5, name: "정보나눔", slug: "info" }),
    getPosts: vi.fn().mockResolvedValue({
      posts: mockPosts,
      total: 3,
    }),
    getPostById: vi.fn().mockImplementation(async (id: number) => {
      return mockPosts.find((p) => p.id === id);
    }),
    createPost: vi.fn().mockResolvedValue(4),
    updatePost: vi.fn().mockResolvedValue(undefined),
    deletePost: vi.fn().mockResolvedValue(undefined),
    getComments: vi.fn().mockResolvedValue([]),
    createComment: vi.fn().mockResolvedValue(1),
    deleteComment: vi.fn().mockResolvedValue(undefined),
    createNotification: vi.fn().mockResolvedValue(undefined),
  };
});

import * as db from "./db";

describe("InfoBoard Card Style - Data Support", () => {
  it("getPosts returns content field for card excerpt", async () => {
    const result = await db.getPosts(5, 1, 12);
    expect(result.posts.length).toBeGreaterThan(0);
    result.posts.forEach((post: any) => {
      expect(post).toHaveProperty("content");
      expect(typeof post.content).toBe("string");
      expect(post.content.length).toBeGreaterThan(0);
    });
  });

  it("getPosts returns images field for card thumbnails", async () => {
    const result = await db.getPosts(5, 1, 12);
    // 첫 번째 게시글은 이미지가 있음
    expect(result.posts[0].images).toBeTruthy();
    expect(Array.isArray(result.posts[0].images)).toBe(true);
    // 두 번째 게시글은 이미지가 없음
    expect(result.posts[1].images).toBeNull();
  });

  it("getPosts returns userName for card author display", async () => {
    const result = await db.getPosts(5, 1, 12);
    expect(result.posts[0].userName).toBe("건강지킴이");
    expect(result.posts[1].userName).toBe("약사님");
    expect(result.posts[2].userName).toBeNull(); // 익명 표시 필요
  });

  it("getPosts returns viewCount and commentCount for card stats", async () => {
    const result = await db.getPosts(5, 1, 12);
    result.posts.forEach((post: any) => {
      expect(post).toHaveProperty("viewCount");
      expect(post).toHaveProperty("commentCount");
      expect(typeof post.viewCount).toBe("number");
      expect(typeof post.commentCount).toBe("number");
    });
  });

  it("getPosts returns categoryId for card badge", async () => {
    const result = await db.getPosts(5, 1, 12);
    expect(result.posts[0].categoryId).toBe(2);
    expect(result.posts[1].categoryId).toBe(3);
    expect(result.posts[2].categoryId).toBeNull();
  });

  it("getPosts returns isPinned for pinned badge", async () => {
    const result = await db.getPosts(5, 1, 12);
    expect(result.posts[0].isPinned).toBe(0);
    expect(result.posts[1].isPinned).toBe(1);
  });

  it("getPosts returns createdAt for relative date display", async () => {
    const result = await db.getPosts(5, 1, 12);
    result.posts.forEach((post: any) => {
      expect(post).toHaveProperty("createdAt");
      expect(post.createdAt instanceof Date).toBe(true);
    });
  });

  it("getPosts supports pagination with limit 12 for card grid", async () => {
    await db.getPosts(5, 1, 12);
    expect(db.getPosts).toHaveBeenCalledWith(5, 1, 12);
  });

  it("getPosts supports categoryId filter for card view", async () => {
    await db.getPosts(5, 1, 12, undefined, 2);
    expect(db.getPosts).toHaveBeenCalledWith(5, 1, 12, undefined, 2);
  });

  it("getPosts supports search for card view", async () => {
    await db.getPosts(5, 1, 12, "비타민");
    expect(db.getPosts).toHaveBeenCalledWith(5, 1, 12, "비타민");
  });
});

describe("InfoBoard Card Style - Image Extraction Logic", () => {
  /** 본문에서 첫 번째 이미지 URL 추출 (프론트엔드 로직 재현) */
  function extractFirstImage(content: string, images?: string[] | null): string | null {
    if (images && images.length > 0) return images[0];
    const mdMatch = content.match(/!\[[^\]]*\]\(([^)]+)\)/);
    if (mdMatch) return mdMatch[1];
    const htmlMatch = content.match(/<img[^>]+src=["']([^"']+)["']/);
    if (htmlMatch) return htmlMatch[1];
    return null;
  }

  /** 마크다운 제거 (프론트엔드 로직 재현) */
  function stripMarkdown(text: string): string {
    return text
      .replace(/!\[[^\]]*\]\([^)]+\)/g, "")
      .replace(/#{1,6}\s/g, "")
      .replace(/\*\*([^*]+)\*\*/g, "$1")
      .replace(/\*([^*]+)\*/g, "$1")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .replace(/`[^`]+`/g, "")
      .replace(/\n/g, " ")
      .trim();
  }

  it("extracts image from images array first", () => {
    const url = extractFirstImage("some content", ["https://example.com/img.jpg"]);
    expect(url).toBe("https://example.com/img.jpg");
  });

  it("extracts image from markdown when no images array", () => {
    const url = extractFirstImage("![alt](https://example.com/md-img.jpg)\n\nSome text", null);
    expect(url).toBe("https://example.com/md-img.jpg");
  });

  it("extracts image from HTML img tag", () => {
    const url = extractFirstImage('<img src="https://example.com/html-img.jpg" />', null);
    expect(url).toBe("https://example.com/html-img.jpg");
  });

  it("returns null when no image found", () => {
    const url = extractFirstImage("Just plain text content without any images", null);
    expect(url).toBeNull();
  });

  it("strips markdown for clean excerpt", () => {
    const content = "![img](https://example.com/img.jpg)\n\n## 제목\n\n**굵은 글씨**와 *기울임* 텍스트";
    const excerpt = stripMarkdown(content);
    expect(excerpt).not.toContain("##");
    expect(excerpt).not.toContain("**");
    expect(excerpt).not.toContain("*");
    expect(excerpt).not.toContain("![");
    expect(excerpt).toContain("제목");
    expect(excerpt).toContain("굵은 글씨");
  });

  it("strips markdown links for clean excerpt", () => {
    const content = "자세한 내용은 [여기](https://example.com)를 참고하세요.";
    const excerpt = stripMarkdown(content);
    expect(excerpt).toContain("여기");
    expect(excerpt).not.toContain("https://example.com");
  });
});
