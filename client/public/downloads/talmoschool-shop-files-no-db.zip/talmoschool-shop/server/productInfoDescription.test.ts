import { describe, it, expect, vi } from "vitest";

// Mock LLM
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn(),
}));

import { invokeLLM } from "./_core/llm";
const mockedInvokeLLM = vi.mocked(invokeLLM);

describe("productInfo.generateDescription", () => {
  it("should be defined in the router", async () => {
    const { productInfoRouter } = await import("./routers/productInfo");
    // Check that generateDescription procedure exists
    expect(productInfoRouter).toBeDefined();
    expect((productInfoRouter as any)._def.procedures.generateDescription).toBeDefined();
  });

  it("should have generateDraft procedure defined", async () => {
    const { productInfoRouter } = await import("./routers/productInfo");
    expect((productInfoRouter as any)._def.procedures.generateDraft).toBeDefined();
  });

  it("should have getByProduct procedure defined", async () => {
    const { productInfoRouter } = await import("./routers/productInfo");
    expect((productInfoRouter as any)._def.procedures.getByProduct).toBeDefined();
  });

  it("should have highlights procedure defined", async () => {
    const { productInfoRouter } = await import("./routers/productInfo");
    expect((productInfoRouter as any)._def.procedures.highlights).toBeDefined();
  });
});

describe("LLM prompt for description generation", () => {
  it("should invoke LLM with fact-based system prompt", async () => {
    // Read the router source to verify prompt content
    const fs = await import("fs");
    const routerSource = fs.readFileSync("./server/routers/productInfo.ts", "utf-8");
    
    // Verify key prompt requirements
    expect(routerSource).toContain("사실 기반");
    expect(routerSource).toContain("창작하거나 과장하지 않습니다");
    expect(routerSource).toContain("해당 정보를 확인할 수 없습니다");
    expect(routerSource).toContain("간결함");
    expect(routerSource).toContain("자연스러움");
  });

  it("should output HTML format", async () => {
    const fs = await import("fs");
    const routerSource = fs.readFileSync("./server/routers/productInfo.ts", "utf-8");
    
    expect(routerSource).toContain("HTML 형식으로 작성하세요");
    expect(routerSource).toContain("<h3>");
    expect(routerSource).toContain("<p>");
  });

  it("should have 3 sections: overview, ingredients, usage", async () => {
    const fs = await import("fs");
    const routerSource = fs.readFileSync("./server/routers/productInfo.ts", "utf-8");
    
    expect(routerSource).toContain("상품 개요");
    expect(routerSource).toContain("주요 성분 및 특징");
    expect(routerSource).toContain("복용/사용 간단 안내");
  });

  it("should strip markdown code blocks from response", async () => {
    const fs = await import("fs");
    const routerSource = fs.readFileSync("./server/routers/productInfo.ts", "utf-8");
    
    // Verify code block stripping logic exists
    expect(routerSource).toContain("```html");
    expect(routerSource).toContain("```$");
  });
});
