import { describe, it, expect, vi, beforeEach } from "vitest";

// ─── getOrderStatusLabel / getOrderStatusColor 테스트 ───
// 이 함수들은 클라이언트 코드이므로 직접 로직을 테스트합니다

function getOrderStatusLabel(status: string): string {
  const map: Record<string, string> = { 
    pending: "주문접수", paid: "결제완료", preparing: "상품준비중", 
    shipping: "배송중", delivered: "배송완료", cancelled: "주문취소", 
    refunded: "환불완료", customs_hold: "통관검사" 
  };
  return map[status] ?? status;
}

function getOrderStatusColor(status: string): string {
  const map: Record<string, string> = { 
    pending: "bg-yellow-100 text-yellow-800", paid: "bg-blue-100 text-blue-800", 
    preparing: "bg-indigo-100 text-indigo-800", shipping: "bg-purple-100 text-purple-800", 
    delivered: "bg-green-100 text-green-800", cancelled: "bg-red-100 text-red-800", 
    refunded: "bg-gray-100 text-gray-800", customs_hold: "bg-rose-100 text-rose-700" 
  };
  return map[status] ?? "bg-gray-100 text-gray-800";
}

describe("통관검사 상태 관리 - 라벨 및 색상", () => {
  it("customs_hold 상태 라벨이 '통관검사'로 반환되어야 함", () => {
    expect(getOrderStatusLabel("customs_hold")).toBe("통관검사");
  });

  it("customs_hold 상태 색상이 rose 계열이어야 함", () => {
    const color = getOrderStatusColor("customs_hold");
    expect(color).toContain("rose");
    expect(color).toBe("bg-rose-100 text-rose-700");
  });

  it("기존 상태 라벨이 정상적으로 반환되어야 함", () => {
    expect(getOrderStatusLabel("pending")).toBe("주문접수");
    expect(getOrderStatusLabel("paid")).toBe("결제완료");
    expect(getOrderStatusLabel("preparing")).toBe("상품준비중");
    expect(getOrderStatusLabel("shipping")).toBe("배송중");
    expect(getOrderStatusLabel("delivered")).toBe("배송완료");
    expect(getOrderStatusLabel("cancelled")).toBe("주문취소");
    expect(getOrderStatusLabel("refunded")).toBe("환불완료");
  });

  it("알 수 없는 상태는 원래 값을 반환해야 함", () => {
    expect(getOrderStatusLabel("unknown_status")).toBe("unknown_status");
  });

  it("알 수 없는 상태는 기본 회색 색상을 반환해야 함", () => {
    expect(getOrderStatusColor("unknown_status")).toBe("bg-gray-100 text-gray-800");
  });
});

// ─── 배송 상태 매핑 테스트 (shipment status → order customs_hold 매핑) ───
describe("통관검사 상태 관리 - 배송 상태 매핑", () => {
  const shipmentStatusToOrderStatus: Record<string, string> = {
    "import_customs": "customs_hold",
    "in_transit": "shipping",
    "delivered": "delivered",
    "pending": "preparing",
  };

  it("import_customs 배송 상태가 customs_hold 주문 상태로 매핑되어야 함", () => {
    expect(shipmentStatusToOrderStatus["import_customs"]).toBe("customs_hold");
  });

  it("일반 배송 상태는 기존 주문 상태로 매핑되어야 함", () => {
    expect(shipmentStatusToOrderStatus["in_transit"]).toBe("shipping");
    expect(shipmentStatusToOrderStatus["delivered"]).toBe("delivered");
  });
});

// ─── statuses 배열 테스트 ───
describe("통관검사 상태 관리 - statuses 배열", () => {
  const statuses = ["pending", "paid", "preparing", "shipping", "delivered", "customs_hold", "cancelled"];

  it("statuses 배열에 customs_hold가 포함되어야 함", () => {
    expect(statuses).toContain("customs_hold");
  });

  it("customs_hold는 delivered와 cancelled 사이에 위치해야 함", () => {
    const customsIdx = statuses.indexOf("customs_hold");
    const deliveredIdx = statuses.indexOf("delivered");
    const cancelledIdx = statuses.indexOf("cancelled");
    expect(customsIdx).toBeGreaterThan(deliveredIdx);
    expect(customsIdx).toBeLessThan(cancelledIdx);
  });

  it("statuses 배열은 7개 항목을 가져야 함", () => {
    expect(statuses).toHaveLength(7);
  });
});

// ─── DB 스키마 일관성 테스트 ───
describe("통관검사 상태 관리 - 스키마 일관성", () => {
  // orders 테이블 status enum 값
  const orderStatusEnum = ["pending", "paid", "preparing", "shipping", "delivered", "cancelled", "refunded", "customs_hold"];
  
  // shipments 테이블 status enum 값
  const shipmentStatusEnum = [
    "pending", "picked_up", "in_transit", "customs_departure", "customs_arrival", 
    "import_customs", "out_for_delivery", "delivered", "failed", "returned", "alert"
  ];

  it("orders 스키마에 customs_hold 상태가 포함되어야 함", () => {
    expect(orderStatusEnum).toContain("customs_hold");
  });

  it("shipments 스키마에 import_customs 상태가 포함되어야 함", () => {
    expect(shipmentStatusEnum).toContain("import_customs");
  });

  it("shipments 스키마에 customs_departure 상태가 포함되어야 함", () => {
    expect(shipmentStatusEnum).toContain("customs_departure");
  });

  it("shipments 스키마에 customs_arrival 상태가 포함되어야 함", () => {
    expect(shipmentStatusEnum).toContain("customs_arrival");
  });

  it("shipments 스키마에 alert 상태가 포함되어야 함", () => {
    expect(shipmentStatusEnum).toContain("alert");
  });
});

// ─── bulkActions status enum 테스트 ───
describe("통관검사 상태 관리 - 일괄 작업 상태 enum", () => {
  const bulkActionStatuses = ["pending", "paid", "preparing", "shipping", "delivered", "cancelled", "refunded", "customs_hold"];

  it("일괄 작업 상태에 customs_hold가 포함되어야 함", () => {
    expect(bulkActionStatuses).toContain("customs_hold");
  });

  it("일괄 작업 상태에 기존 모든 상태가 포함되어야 함", () => {
    expect(bulkActionStatuses).toContain("pending");
    expect(bulkActionStatuses).toContain("paid");
    expect(bulkActionStatuses).toContain("preparing");
    expect(bulkActionStatuses).toContain("shipping");
    expect(bulkActionStatuses).toContain("delivered");
    expect(bulkActionStatuses).toContain("cancelled");
    expect(bulkActionStatuses).toContain("refunded");
  });
});

// ─── 우체국 HTML 파싱 테스트 (통관검사 감지 핵심 로직) ───
describe("우체국 HTML 파싱 - 통관검사 감지", () => {
  it("통관검사대기 + 인천공항본부세관 + 통관번호가 있는 HTML을 정확히 감지해야 함", async () => {
    const mockHtml = `
      <table class="table_col detail_off">
        <thead><tr><th>처리일시</th><th>처리현황</th><th>우체국(PostOffice)</th><th>상세설명</th></tr></thead>
        <tbody>
          <tr>
            <td>2026.01.22 18:21</td>
            <td>접수</td>
            <td>IN400099</td>
            <td>접수우체국우편번호 : IN400099</td>
          </tr>
          <tr>
            <td>2026.02.02 09:26</td>
            <td>교환국 도착</td>
            <td>국제우편물류센터</td>
            <td></td>
          </tr>
          <tr>
            <td>2026.02.03 09:42</td>
            <td>통관검사대기</td>
            <td>국제우편물류센터</td>
            <td><font color="red">인천공항본부세관</font><br/><font color="red">통관번호:242471</font></td>
          </tr>
        </tbody>
      </table>
    `;

    const { parseKoreaPostHtml } = await import("./_core/koreaPostApi");
    const result = parseKoreaPostHtml(mockHtml);

    expect(result).not.toBeNull();
    expect(result!.events.length).toBe(3);
    expect(result!.hasCustomsIssue).toBe(true);
    expect(result!.customsInfo).not.toBeNull();
    expect(result!.customsInfo!.customsNumber).toBe("242471");
    expect(result!.customsInfo!.customsOffice).toBe("인천공항본부세관");
    expect(result!.mappedStatus).toBe("customs_hold");
  });

  it("통관검사가 없는 정상 배송 HTML은 customs_hold로 감지하지 않아야 함", async () => {
    const normalHtml = `
      <table class="table_col detail_off">
        <thead><tr><th>처리일시</th><th>처리현황</th><th>우체국(PostOffice)</th><th>상세설명</th></tr></thead>
        <tbody>
          <tr><td>2026.01.22 18:21</td><td>접수</td><td>IN400099</td><td></td></tr>
          <tr><td>2026.02.04 14:30</td><td>배달완료</td><td>서울중앙우체국</td><td></td></tr>
        </tbody>
      </table>
    `;

    const { parseKoreaPostHtml } = await import("./_core/koreaPostApi");
    const result = parseKoreaPostHtml(normalHtml);

    expect(result).not.toBeNull();
    expect(result!.hasCustomsIssue).toBe(false);
    expect(result!.customsInfo).toBeNull();
    expect(result!.mappedStatus).toBe("delivered");
  });

  it("빈 HTML이나 테이블이 없는 경우 null을 반환해야 함", async () => {
    const { parseKoreaPostHtml } = await import("./_core/koreaPostApi");
    
    const result1 = parseKoreaPostHtml("");
    expect(result1).toBeNull();

    const result2 = parseKoreaPostHtml("<html><body>No tracking info</body></html>");
    expect(result2).toBeNull();
  });

  it("다른 세관의 통관번호도 정확히 추출해야 함", async () => {
    const htmlWithCustoms = `
      <table class="table_col detail_off">
        <thead><tr><th>처리일시</th><th>처리현황</th><th>우체국(PostOffice)</th><th>상세설명</th></tr></thead>
        <tbody>
          <tr>
            <td>2026.02.03 09:42</td>
            <td>통관검사대기</td>
            <td>국제우편물류센터</td>
            <td><font color="red">부산세관</font><br/><font color="red">통관번호:987654</font></td>
          </tr>
        </tbody>
      </table>
    `;

    const { parseKoreaPostHtml } = await import("./_core/koreaPostApi");
    const result = parseKoreaPostHtml(htmlWithCustoms);

    expect(result!.hasCustomsIssue).toBe(true);
    expect(result!.customsInfo!.customsNumber).toBe("987654");
    expect(result!.customsInfo!.customsOffice).toBe("부산세관");
  });

  it("다양한 배송 상태를 올바르게 매핑해야 함", async () => {
    const { parseKoreaPostHtml } = await import("./_core/koreaPostApi");

    // 접수 상태
    const acceptedHtml = `
      <table class="table_col detail_off">
        <thead><tr><th>처리일시</th><th>처리현황</th><th>우체국(PostOffice)</th><th>상세설명</th></tr></thead>
        <tbody>
          <tr><td>2026.01.22 18:21</td><td>접수</td><td>IN400099</td><td></td></tr>
        </tbody>
      </table>
    `;
    const r1 = parseKoreaPostHtml(acceptedHtml);
    expect(r1!.mappedStatus).toBe("accepted");

    // 교환국 도착 상태
    const arrivalHtml = `
      <table class="table_col detail_off">
        <thead><tr><th>처리일시</th><th>처리현황</th><th>우체국(PostOffice)</th><th>상세설명</th></tr></thead>
        <tbody>
          <tr><td>2026.01.22 18:21</td><td>접수</td><td>IN400099</td><td></td></tr>
          <tr><td>2026.02.02 09:26</td><td>교환국 도착</td><td>국제우편물류센터</td><td></td></tr>
        </tbody>
      </table>
    `;
    const r2 = parseKoreaPostHtml(arrivalHtml);
    expect(r2!.mappedStatus).toBe("arrived_destination");
  });
});

// ─── DB 함수 존재 여부 테스트 ───
describe("통관검사 DB 함수 존재 여부", () => {
  it("updateShipmentCustomsInfo 함수가 존재해야 함", async () => {
    const db = await import("./db");
    expect(typeof db.updateShipmentCustomsInfo).toBe("function");
  });

  it("getCustomsHoldShipments 함수가 존재해야 함", async () => {
    const db = await import("./db");
    expect(typeof db.getCustomsHoldShipments).toBe("function");
  });
});
