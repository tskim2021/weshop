import { describe, it, expect } from "vitest";

describe("Product Hashtags", () => {
  it("should parse hashtags from comma-separated string", () => {
    const input = "탈모, 두피케어, 샴푸";
    const hashtags = input.split(",").map(t => t.trim()).filter(t => t.length > 0);
    expect(hashtags).toEqual(["탈모", "두피케어", "샴푸"]);
  });

  it("should handle empty hashtags", () => {
    const input = "";
    const hashtags = input.split(",").map(t => t.trim()).filter(t => t.length > 0);
    expect(hashtags).toEqual([]);
  });

  it("should handle single hashtag", () => {
    const input = "탈모";
    const hashtags = input.split(",").map(t => t.trim()).filter(t => t.length > 0);
    expect(hashtags).toEqual(["탈모"]);
  });

  it("should trim whitespace from hashtags", () => {
    const input = "  탈모  ,  두피케어  ,  샴푸  ";
    const hashtags = input.split(",").map(t => t.trim()).filter(t => t.length > 0);
    expect(hashtags).toEqual(["탈모", "두피케어", "샴푸"]);
  });

  it("should filter out empty strings", () => {
    const input = "탈모,,두피케어,,샴푸";
    const hashtags = input.split(",").map(t => t.trim()).filter(t => t.length > 0);
    expect(hashtags).toEqual(["탈모", "두피케어", "샴푸"]);
  });

  it("should handle hashtags with special characters", () => {
    const input = "#탈모, @두피케어, 샴푸&린스";
    const hashtags = input.split(",").map(t => t.trim()).filter(t => t.length > 0);
    expect(hashtags).toEqual(["#탈모", "@두피케어", "샴푸&린스"]);
  });

  it("should handle many hashtags", () => {
    const tags = Array.from({ length: 20 }, (_, i) => `해시태그${i + 1}`);
    const input = tags.join(", ");
    const hashtags = input.split(",").map(t => t.trim()).filter(t => t.length > 0);
    expect(hashtags).toHaveLength(20);
    expect(hashtags).toEqual(tags);
  });

  it("should format hashtags for display", () => {
    const hashtags = ["탈모", "두피케어", "샴푸"];
    const formatted = hashtags.map(tag => `#${tag}`);
    expect(formatted).toEqual(["#탈모", "#두피케어", "#샴푸"]);
  });

  it("should limit hashtags display to 3 with count", () => {
    const hashtags = ["탈모", "두피케어", "샴푸", "헤어팩", "영양"];
    const displayed = hashtags.slice(0, 3);
    const remaining = hashtags.length - 3;
    expect(displayed).toHaveLength(3);
    expect(remaining).toBe(2);
  });
});
