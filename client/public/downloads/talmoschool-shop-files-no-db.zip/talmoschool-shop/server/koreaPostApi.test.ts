import { describe, it, expect } from "vitest";
import { mapKoreaPostStatus, parseKoreaPostHtml, type KoreaPostEvent } from "./_core/koreaPostApi";

describe("우체국 API 통관검사 감지", () => {
  it("통관검사대기 - hasCustomsIssue=true일 때 customs_hold로 매핑해야 함", () => {
    const events: KoreaPostEvent[] = [
      {
        processDate: "2026.02.03 09:42",
        processStatus: "통관검사대기",
        postOffice: "국제우편물류센터",
        details: "통관번호:242471",
        isAlert: true,
      },
      {
        processDate: "2026.02.02 09:26",
        processStatus: "교환국 도착",
        postOffice: "국제우편물류센터",
        details: "",
        isAlert: false,
      },
    ];

    // hasCustomsIssue=true로 전달하면 customs_hold
    const status = mapKoreaPostStatus(events, true);
    expect(status).toBe("customs_hold");
  });

  it("통관검사대기가 최신 이벤트일 때 customs_hold로 매핑해야 함", () => {
    const events: KoreaPostEvent[] = [
      {
        processDate: "2026.02.02 09:26",
        processStatus: "교환국 도착",
        postOffice: "국제우편물류센터",
        details: "",
        isAlert: false,
      },
      {
        processDate: "2026.02.03 09:42",
        processStatus: "통관검사대기",
        postOffice: "국제우편물류센터",
        details: "통관번호:242471",
        isAlert: true,
      },
    ];

    // 최신 이벤트가 통관검사대기이면 customs_hold
    const status = mapKoreaPostStatus(events);
    expect(status).toBe("customs_hold");
  });

  it("인천공항본부세관 + 통관번호 조합을 customs_hold로 매핑해야 함", () => {
    const events: KoreaPostEvent[] = [
      {
        processDate: "2026.02.03 09:42",
        processStatus: "통관검사대기",
        postOffice: "국제우편물류센터",
        details: "인천공항본부세관\n통관번호:242471",
        isAlert: true,
      },
    ];

    const status = mapKoreaPostStatus(events);
    expect(status).toBe("customs_hold");
  });

  it("배달완료 상태를 delivered로 매핑해야 함", () => {
    const events: KoreaPostEvent[] = [
      {
        processDate: "2026.02.10 14:30",
        processStatus: "배달완료",
        postOffice: "서울강남우체국",
        details: "",
        isAlert: false,
      },
    ];

    const status = mapKoreaPostStatus(events);
    expect(status).toBe("delivered");
  });

  it("교환국 도착 상태를 arrived_destination으로 매핑해야 함", () => {
    const events: KoreaPostEvent[] = [
      {
        processDate: "2026.02.02 09:26",
        processStatus: "교환국 도착",
        postOffice: "국제우편물류센터",
        details: "",
        isAlert: false,
      },
    ];

    const status = mapKoreaPostStatus(events);
    expect(status).toBe("arrived_destination");
  });

  it("발송준비 상태를 in_transit_intl로 매핑해야 함", () => {
    const events: KoreaPostEvent[] = [
      {
        processDate: "2026.01.22 20:41",
        processStatus: "발송준비",
        postOffice: "INBOMA",
        details: "",
        isAlert: false,
      },
    ];

    const status = mapKoreaPostStatus(events);
    expect(status).toBe("in_transit_intl");
  });

  it("접수 상태를 accepted로 매핑해야 함", () => {
    const events: KoreaPostEvent[] = [
      {
        processDate: "2026.01.22 18:21",
        processStatus: "접수",
        postOffice: "IN400099",
        details: "",
        isAlert: false,
      },
    ];

    const status = mapKoreaPostStatus(events);
    expect(status).toBe("accepted");
  });

  it("배달준비 상태를 out_for_delivery로 매핑해야 함", () => {
    const events: KoreaPostEvent[] = [
      {
        processDate: "2026.02.12 13:07",
        processStatus: "배달준비",
        postOffice: "부산사상우체국",
        details: "",
        isAlert: false,
      },
    ];

    const status = mapKoreaPostStatus(events);
    expect(status).toBe("out_for_delivery");
  });

  it("deliveryResult 필드 기반으로 배달완료를 감지해야 함", () => {
    const events: KoreaPostEvent[] = [];
    const status = mapKoreaPostStatus(events, false, "배달완료");
    expect(status).toBe("delivered");
  });

  it("이벤트가 없으면 accepted를 반환해야 함", () => {
    const status = mapKoreaPostStatus([]);
    expect(status).toBe("accepted");
  });
});

describe("우체국 HTML 파싱 (parseKoreaPostHtml)", () => {
  it("배송 이력 테이블이 있는 HTML을 올바르게 파싱해야 함", () => {
    const html = `
      <html>
      <body>
      <table>
        <tr><th>EMS번호</th><th>보내는분</th><th>받는분</th><th>수령인</th><th>배달결과</th><th>서비스종류</th></tr>
        <tr><td>LP081791457IN</td><td>SENDER</td><td>RECEIVER</td><td>수령인</td><td>배달완료</td><td>국제등기</td></tr>
      </table>
      <table>
        <tr><th>처리일시</th><th>처리현황</th><th>우체국</th><th>상세내용</th></tr>
        <tr><td>2026.02.06 22:52</td><td>접수</td><td>IN400099</td><td>접수우체국우편번호 : IN400099</td></tr>
        <tr><td>2026.02.07 14:46</td><td>발송교환국에도착</td><td>INBOMA</td><td></td></tr>
        <tr><td>2026.02.12 16:12</td><td>배달완료</td><td>부산사상우체국</td><td>배달우체국전화번호 : 051-320-3331</td></tr>
      </table>
      </body>
      </html>
    `;

    const result = parseKoreaPostHtml(html, "LP081791457IN");
    expect(result).not.toBeNull();
    expect(result!.trackingNumber).toBe("LP081791457IN");
    expect(result!.deliveryResult).toBe("배달완료");
    expect(result!.serviceType).toBe("국제등기");
    expect(result!.events).toHaveLength(3);
    expect(result!.mappedStatus).toBe("delivered");
    expect(result!.hasCustomsIssue).toBe(false);
  });

  it("통관검사대기 이벤트가 있으면 customs_hold로 매핑해야 함", () => {
    const html = `
      <html>
      <body>
      <table>
        <tr><th>EMS번호</th><th>보내는분</th><th>받는분</th><th>수령인</th><th>배달결과</th><th>서비스종류</th></tr>
        <tr><td>LP081797327IN</td><td>SENDER</td><td>RECEIVER</td><td></td><td></td><td>국제등기</td></tr>
      </table>
      <table>
        <tr><th>처리일시</th><th>처리현황</th><th>우체국</th><th>상세내용</th></tr>
        <tr><td>2026.02.01 10:00</td><td>접수</td><td>IN400099</td><td></td></tr>
        <tr><td>2026.02.03 09:42</td><td>통관검사대기</td><td>국제우편물류센터</td><td>인천공항본부세관통관번호:242471</td></tr>
      </table>
      </body>
      </html>
    `;

    const result = parseKoreaPostHtml(html, "LP081797327IN");
    expect(result).not.toBeNull();
    expect(result!.hasCustomsIssue).toBe(true);
    expect(result!.mappedStatus).toBe("customs_hold");
    expect(result!.customsInfo).not.toBeNull();
    expect(result!.customsInfo!.customsOffice).toBe("인천공항본부세관");
    expect(result!.customsInfo!.customsNumber).toBe("242471");
  });

  it("이벤트 테이블이 없는 HTML은 null을 반환해야 함", () => {
    const html = `<html><body><p>No tracking data</p></body></html>`;
    const result = parseKoreaPostHtml(html, "INVALID");
    expect(result).toBeNull();
  });

  it("빈 HTML은 null을 반환해야 함", () => {
    const result = parseKoreaPostHtml("", "EMPTY");
    expect(result).toBeNull();
  });

  it("처리현황 헤더가 있는 테이블을 이벤트 테이블로 인식해야 함", () => {
    const html = `
      <html>
      <body>
      <table>
        <tr><th>처리일시</th><th>처리현황</th><th>우체국</th><th>상세내용</th></tr>
        <tr><td>2026.02.06 22:52</td><td>접수</td><td>IN400099</td><td></td></tr>
        <tr><td>2026.02.07 15:53</td><td>발송준비</td><td>INBOMA</td><td></td></tr>
      </table>
      </body>
      </html>
    `;

    const result = parseKoreaPostHtml(html, "TEST123");
    expect(result).not.toBeNull();
    expect(result!.events).toHaveLength(2);
    expect(result!.events[0].processStatus).toBe("접수");
    expect(result!.events[1].processStatus).toBe("발송준비");
  });
});
