import { describe, it, expect, vi, beforeEach } from "vitest";

// Mock DB
vi.mock("./db", () => ({
  getPopularDiscussions: vi.fn(),
  getProductInfoHighlights: vi.fn(),
  getDiscussionById: vi.fn(),
  getDiscussionCommentById: vi.fn(),
  createDiscussionComment: vi.fn(),
  createNotification: vi.fn(),
}));

import * as db from "./db";

describe("Phase 4: 메인 페이지 통합 및 커뮤니티 강화", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe("인기 토론 Top 5 API", () => {
    it("인기 토론 목록을 반환해야 한다", async () => {
      const mockDiscussions = [
        { id: 1, title: "탈모약 효과 토론", likeCount: 15, commentCount: 8 },
        { id: 2, title: "피부 관리 팁", likeCount: 12, commentCount: 6 },
        { id: 3, title: "다이어트 보조제 추천", likeCount: 10, commentCount: 5 },
        { id: 4, title: "성기능 개선 방법", likeCount: 8, commentCount: 4 },
        { id: 5, title: "비타민 복용법", likeCount: 7, commentCount: 3 },
      ];
      vi.mocked(db.getPopularDiscussions).mockResolvedValue(mockDiscussions as any);

      const result = await db.getPopularDiscussions(5);
      expect(result).toHaveLength(5);
      expect(db.getPopularDiscussions).toHaveBeenCalledWith(5);
    });

    it("기본 limit은 5개여야 한다", async () => {
      vi.mocked(db.getPopularDiscussions).mockResolvedValue([]);
      await db.getPopularDiscussions(5);
      expect(db.getPopularDiscussions).toHaveBeenCalledWith(5);
    });
  });

  describe("상품 정보 하이라이트 API", () => {
    it("최근 업데이트된 상품 정보를 반환해야 한다", async () => {
      const mockHighlights = [
        { productId: 1, productName: "미녹시딜", sectionType: "faq", sectionCount: 8 },
        { productId: 2, productName: "비타민C", sectionType: "usage", sectionCount: 6 },
        { productId: 3, productName: "프로페시아", sectionType: "sideEffects", sectionCount: 5 },
      ];
      vi.mocked(db.getProductInfoHighlights).mockResolvedValue(mockHighlights as any);

      const result = await db.getProductInfoHighlights(6);
      expect(result).toHaveLength(3);
      expect(db.getProductInfoHighlights).toHaveBeenCalledWith(6);
    });

    it("빈 결과를 처리해야 한다", async () => {
      vi.mocked(db.getProductInfoHighlights).mockResolvedValue([]);
      const result = await db.getProductInfoHighlights(6);
      expect(result).toHaveLength(0);
    });
  });

  describe("토론 알림 시스템", () => {
    it("댓글 작성 시 토론 작성자에게 알림을 생성해야 한다", async () => {
      const mockDiscussion = { id: 1, title: "탈모약 효과 토론", userId: 10 };
      vi.mocked(db.getDiscussionById).mockResolvedValue(mockDiscussion as any);
      vi.mocked(db.createDiscussionComment).mockResolvedValue({ id: 1 } as any);
      vi.mocked(db.createNotification).mockResolvedValue(undefined);

      // 시뮬레이션: 댓글 작성자(userId: 20)가 토론(userId: 10)에 댓글 작성
      const commenterId = 20;
      const commenterName = "테스터";
      const discussion = await db.getDiscussionById(1);

      if (discussion && discussion.userId !== commenterId) {
        await db.createNotification(
          discussion.userId,
          "discussion",
          "토론에 새 댓글이 달렸습니다",
          `"${discussion.title}"에 ${commenterName}님이 댓글을 달았습니다.`,
          `/discussions/${discussion.id}`
        );
      }

      expect(db.createNotification).toHaveBeenCalledWith(
        10,
        "discussion",
        "토론에 새 댓글이 달렸습니다",
        `"탈모약 효과 토론"에 테스터님이 댓글을 달았습니다.`,
        "/discussions/1"
      );
    });

    it("본인 글에 댓글 달면 알림을 생성하지 않아야 한다", async () => {
      const mockDiscussion = { id: 1, title: "내 토론", userId: 10 };
      vi.mocked(db.getDiscussionById).mockResolvedValue(mockDiscussion as any);

      const commenterId = 10; // 본인
      const discussion = await db.getDiscussionById(1);

      if (discussion && discussion.userId !== commenterId) {
        await db.createNotification(
          discussion.userId,
          "discussion",
          "토론에 새 댓글이 달렸습니다",
          "test",
          "/discussions/1"
        );
      }

      expect(db.createNotification).not.toHaveBeenCalled();
    });

    it("대댓글 시 원댓글 작성자에게도 알림을 생성해야 한다", async () => {
      const mockDiscussion = { id: 1, title: "토론 제목", userId: 10 };
      const mockParentComment = { id: 5, userId: 15, content: "원댓글" };
      vi.mocked(db.getDiscussionById).mockResolvedValue(mockDiscussion as any);
      vi.mocked(db.getDiscussionCommentById).mockResolvedValue(mockParentComment as any);
      vi.mocked(db.createNotification).mockResolvedValue(undefined);

      const commenterId = 20;
      const commenterName = "답글러";
      const parentId = 5;

      const discussion = await db.getDiscussionById(1);

      // 토론 작성자에게 알림
      if (discussion && discussion.userId !== commenterId) {
        await db.createNotification(
          discussion.userId,
          "discussion",
          "토론에 새 댓글이 달렸습니다",
          `"${discussion.title}"에 ${commenterName}님이 댓글을 달았습니다.`,
          `/discussions/${discussion.id}`
        );
      }

      // 대댓글인 경우, 원댓글 작성자에게도 알림
      if (parentId) {
        const parentComment = await db.getDiscussionCommentById(parentId);
        if (parentComment && parentComment.userId !== commenterId && parentComment.userId !== discussion?.userId) {
          await db.createNotification(
            parentComment.userId,
            "discussion",
            "답글이 달렸습니다",
            `${commenterName}님이 내 댓글에 답글을 달았습니다.`,
            `/discussions/${discussion!.id}`
          );
        }
      }

      // 토론 작성자(10)와 원댓글 작성자(15) 모두에게 알림
      expect(db.createNotification).toHaveBeenCalledTimes(2);
      expect(db.createNotification).toHaveBeenNthCalledWith(1,
        10, "discussion", "토론에 새 댓글이 달렸습니다",
        expect.stringContaining("답글러"), "/discussions/1"
      );
      expect(db.createNotification).toHaveBeenNthCalledWith(2,
        15, "discussion", "답글이 달렸습니다",
        expect.stringContaining("답글러"), "/discussions/1"
      );
    });

    it("대댓글 원작성자가 토론 작성자와 같으면 중복 알림을 보내지 않아야 한다", async () => {
      const mockDiscussion = { id: 1, title: "토론 제목", userId: 10 };
      const mockParentComment = { id: 5, userId: 10, content: "원댓글" }; // 토론 작성자 == 원댓글 작성자
      vi.mocked(db.getDiscussionById).mockResolvedValue(mockDiscussion as any);
      vi.mocked(db.getDiscussionCommentById).mockResolvedValue(mockParentComment as any);
      vi.mocked(db.createNotification).mockResolvedValue(undefined);

      const commenterId = 20;
      const commenterName = "답글러";
      const parentId = 5;

      const discussion = await db.getDiscussionById(1);

      if (discussion && discussion.userId !== commenterId) {
        await db.createNotification(
          discussion.userId,
          "discussion",
          "토론에 새 댓글이 달렸습니다",
          `"${discussion.title}"에 ${commenterName}님이 댓글을 달았습니다.`,
          `/discussions/${discussion.id}`
        );
      }

      if (parentId) {
        const parentComment = await db.getDiscussionCommentById(parentId);
        if (parentComment && parentComment.userId !== commenterId && parentComment.userId !== discussion?.userId) {
          await db.createNotification(
            parentComment.userId,
            "discussion",
            "답글이 달렸습니다",
            `${commenterName}님이 내 댓글에 답글을 달았습니다.`,
            `/discussions/${discussion!.id}`
          );
        }
      }

      // 토론 작성자에게만 1번 알림 (원댓글 작성자 == 토론 작성자이므로 중복 방지)
      expect(db.createNotification).toHaveBeenCalledTimes(1);
    });

    it("알림 타입이 'discussion'이어야 한다", async () => {
      const mockDiscussion = { id: 1, title: "테스트", userId: 10 };
      vi.mocked(db.getDiscussionById).mockResolvedValue(mockDiscussion as any);
      vi.mocked(db.createNotification).mockResolvedValue(undefined);

      const commenterId = 20;
      const discussion = await db.getDiscussionById(1);

      if (discussion && discussion.userId !== commenterId) {
        await db.createNotification(
          discussion.userId,
          "discussion",
          "토론에 새 댓글이 달렸습니다",
          "test message",
          `/discussions/${discussion.id}`
        );
      }

      expect(db.createNotification).toHaveBeenCalledWith(
        10, "discussion", expect.any(String), expect.any(String), "/discussions/1"
      );
    });
  });

  describe("알림 아이콘 매핑", () => {
    it("discussion 타입이 iconMap에 포함되어야 한다", () => {
      const iconMap: Record<string, string> = {
        order: "Package",
        comment: "MessageCircle",
        point: "Star",
        system: "Info",
        review: "Star",
        inquiry: "HelpCircle",
        discussion: "MessageCircle",
      };
      expect(iconMap["discussion"]).toBe("MessageCircle");
    });
  });
});
