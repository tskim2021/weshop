import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createContext(user?: Partial<AuthenticatedUser>): TrpcContext {
  const defaultUser: AuthenticatedUser = {
    id: 1,
    openId: "test-user-1",
    email: "test@example.com",
    name: "테스트 유저",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user: user === undefined ? null : { ...defaultUser, ...user },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

const publicCtx = createContext(undefined);
const userCtx = createContext({ id: 1, name: "테스트 유저" });
const user2Ctx = createContext({ id: 2, name: "다른 유저", openId: "test-user-2" });
const adminCtx = createContext({ id: 99, name: "관리자", role: "admin", openId: "admin-1" });

// Mock DB functions
vi.mock("./db", async () => {
  const actual = await vi.importActual("./db");
  const mockDiscussions = [
    {
      id: 1, userId: 1, categoryId: null, title: "테스트 토론", content: "토론 내용입니다",
      tags: ["건강", "다이어트"], viewCount: 10, likeCount: 3, commentCount: 2,
      isPinned: 0, isClosed: 0, isHidden: 0,
      createdAt: new Date("2025-01-01"), updatedAt: new Date("2025-01-01"),
      userName: "테스트 유저",
    },
    {
      id: 2, userId: 2, categoryId: 1, title: "두번째 토론", content: "두번째 내용",
      tags: null, viewCount: 5, likeCount: 1, commentCount: 0,
      isPinned: 1, isClosed: 0, isHidden: 0,
      createdAt: new Date("2025-01-02"), updatedAt: new Date("2025-01-02"),
      userName: "다른 유저",
    },
  ];

  const mockComments = [
    {
      id: 1, discussionId: 1, userId: 1, parentId: null, content: "루트 댓글",
      likeCount: 2, isHidden: 0, createdAt: new Date(), updatedAt: new Date(), userName: "테스트 유저",
    },
    {
      id: 2, discussionId: 1, userId: 2, parentId: 1, content: "답글입니다",
      likeCount: 0, isHidden: 0, createdAt: new Date(), updatedAt: new Date(), userName: "다른 유저",
    },
  ];

  return {
    ...actual,
    getDiscussions: vi.fn().mockResolvedValue({ discussions: mockDiscussions, total: 2 }),
    getPopularDiscussions: vi.fn().mockResolvedValue([mockDiscussions[0]]),
    getDiscussionById: vi.fn().mockImplementation(async (id: number) => {
      const d = mockDiscussions.find(d => d.id === id);
      return d || null;
    }),
    createDiscussion: vi.fn().mockResolvedValue({ id: 3 }),
    updateDiscussion: vi.fn().mockResolvedValue(undefined),
    deleteDiscussion: vi.fn().mockResolvedValue(undefined),
    incrementDiscussionViewCount: vi.fn().mockResolvedValue(undefined),
    getDiscussionComments: vi.fn().mockResolvedValue(mockComments),
    createDiscussionComment: vi.fn().mockResolvedValue({ id: 3 }),
    updateDiscussionComment: vi.fn().mockResolvedValue(undefined),
    deleteDiscussionComment: vi.fn().mockResolvedValue(undefined),
    toggleDiscussionLike: vi.fn().mockResolvedValue({ liked: true }),
    getUserDiscussionLikes: vi.fn().mockResolvedValue([1]),
    pinDiscussion: vi.fn().mockResolvedValue(undefined),
    closeDiscussion: vi.fn().mockResolvedValue(undefined),
    hideDiscussion: vi.fn().mockResolvedValue(undefined),
  };
});

describe("Discussion Router", () => {
  const caller = appRouter.createCaller;

  describe("list", () => {
    it("비로그인 사용자도 토론 목록을 조회할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.list({});
      expect(result).toBeDefined();
      expect(result.discussions).toBeInstanceOf(Array);
      expect(result.total).toBeGreaterThanOrEqual(0);
    });

    it("카테고리 필터로 토론 목록을 조회할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.list({ categoryId: 1 });
      expect(result).toBeDefined();
    });

    it("검색어로 토론 목록을 조회할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.list({ search: "테스트" });
      expect(result).toBeDefined();
    });

    it("정렬 옵션으로 토론 목록을 조회할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.list({ sort: "popular" });
      expect(result).toBeDefined();
    });

    it("페이지네이션이 동작한다", async () => {
      const result = await caller(publicCtx).discussion.list({ page: 1, limit: 10 });
      expect(result).toBeDefined();
    });
  });

  describe("popular", () => {
    it("인기 토론 목록을 조회할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.popular({ limit: 5 });
      expect(result).toBeInstanceOf(Array);
    });
  });

  describe("getById", () => {
    it("토론 상세를 조회할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.getById({ id: 1 });
      expect(result).toBeDefined();
      expect(result?.title).toBe("테스트 토론");
    });

    it("존재하지 않는 토론은 null을 반환한다", async () => {
      const result = await caller(publicCtx).discussion.getById({ id: 999 });
      expect(result).toBeNull();
    });
  });

  describe("create", () => {
    it("로그인 사용자가 토론을 생성할 수 있다", async () => {
      const result = await caller(userCtx).discussion.create({
        title: "새 토론",
        content: "토론 내용",
        tags: ["태그1"],
      });
      expect(result).toBeDefined();
      expect(result.id).toBeDefined();
    });

    it("비로그인 사용자는 토론을 생성할 수 없다", async () => {
      await expect(
        caller(publicCtx).discussion.create({
          title: "새 토론",
          content: "토론 내용",
        })
      ).rejects.toThrow();
    });

    it("빈 제목으로 토론을 생성할 수 없다", async () => {
      await expect(
        caller(userCtx).discussion.create({
          title: "",
          content: "내용",
        })
      ).rejects.toThrow();
    });

    it("빈 내용으로 토론을 생성할 수 없다", async () => {
      await expect(
        caller(userCtx).discussion.create({
          title: "제목",
          content: "",
        })
      ).rejects.toThrow();
    });
  });

  describe("update", () => {
    it("작성자가 토론을 수정할 수 있다", async () => {
      await expect(
        caller(userCtx).discussion.update({
          id: 1,
          title: "수정된 제목",
          content: "수정된 내용",
        })
      ).resolves.not.toThrow();
    });

    it("비로그인 사용자는 토론을 수정할 수 없다", async () => {
      await expect(
        caller(publicCtx).discussion.update({
          id: 1,
          title: "수정",
        })
      ).rejects.toThrow();
    });
  });

  describe("delete", () => {
    it("작성자가 토론을 삭제할 수 있다", async () => {
      await expect(
        caller(userCtx).discussion.delete({ id: 1 })
      ).resolves.not.toThrow();
    });

    it("비로그인 사용자는 토론을 삭제할 수 없다", async () => {
      await expect(
        caller(publicCtx).discussion.delete({ id: 1 })
      ).rejects.toThrow();
    });
  });

  describe("comments", () => {
    it("댓글 목록을 조회할 수 있다", async () => {
      const result = await caller(publicCtx).discussion.getComments({ discussionId: 1 });
      expect(result).toBeInstanceOf(Array);
      expect(result.length).toBe(2);
    });

    it("로그인 사용자가 댓글을 작성할 수 있다", async () => {
      const result = await caller(userCtx).discussion.createComment({
        discussionId: 1,
        content: "새 댓글",
      });
      expect(result).toBeDefined();
      expect(result.id).toBeDefined();
    });

    it("답글을 작성할 수 있다 (parentId 지정)", async () => {
      const result = await caller(userCtx).discussion.createComment({
        discussionId: 1,
        content: "답글입니다",
        parentId: 1,
      });
      expect(result).toBeDefined();
    });

    it("비로그인 사용자는 댓글을 작성할 수 없다", async () => {
      await expect(
        caller(publicCtx).discussion.createComment({
          discussionId: 1,
          content: "댓글",
        })
      ).rejects.toThrow();
    });

    it("댓글을 수정할 수 있다", async () => {
      await expect(
        caller(userCtx).discussion.updateComment({
          id: 1,
          content: "수정된 댓글",
        })
      ).resolves.not.toThrow();
    });

    it("댓글을 삭제할 수 있다", async () => {
      await expect(
        caller(userCtx).discussion.deleteComment({ id: 1 })
      ).resolves.not.toThrow();
    });
  });

  describe("likes", () => {
    it("로그인 사용자가 토론에 좋아요를 토글할 수 있다", async () => {
      const result = await caller(userCtx).discussion.toggleLike({
        targetType: "discussion",
        targetId: 1,
      });
      expect(result).toBeDefined();
      expect(result.liked).toBe(true);
    });

    it("로그인 사용자가 댓글에 좋아요를 토글할 수 있다", async () => {
      const result = await caller(userCtx).discussion.toggleLike({
        targetType: "comment",
        targetId: 1,
      });
      expect(result).toBeDefined();
    });

    it("비로그인 사용자는 좋아요를 할 수 없다", async () => {
      await expect(
        caller(publicCtx).discussion.toggleLike({
          targetType: "discussion",
          targetId: 1,
        })
      ).rejects.toThrow();
    });

    it("사용자의 좋아요 목록을 조회할 수 있다", async () => {
      const result = await caller(userCtx).discussion.getUserLikes({
        targetType: "discussion",
        targetIds: [1, 2],
      });
      expect(result).toBeInstanceOf(Array);
    });
  });

  describe("admin operations", () => {
    it("관리자가 토론을 고정할 수 있다", async () => {
      await expect(
        caller(adminCtx).discussion.adminTogglePin({ id: 1, isPinned: true })
      ).resolves.not.toThrow();
    });

    it("관리자가 토론을 마감할 수 있다", async () => {
      await expect(
        caller(adminCtx).discussion.adminToggleClose({ id: 1, isClosed: true })
      ).resolves.not.toThrow();
    });

    it("관리자가 토론을 숨길 수 있다", async () => {
      await expect(
        caller(adminCtx).discussion.adminToggleHide({ id: 1, isHidden: true })
      ).resolves.not.toThrow();
    });
  });
});
