import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import * as db from "./db";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTestContext(user: { id: number; role: "user" | "admin" } | null): TrpcContext {
  if (!user) {
    return {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
    };
  }
  const authenticatedUser: AuthenticatedUser = {
    id: user.id,
    openId: `test-user-${user.id}`,
    email: `test${user.id}@example.com`,
    name: `테스트 유저 ${user.id}`,
    loginMethod: "oauth",
    role: user.role,
    phone: null,
    grade: "bronze",
    points: 0,
    totalSpent: 0,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user: authenticatedUser,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };
}

describe("Point History API", () => {
  // 테스트용 사용자 ID (실제 DB에 존재하는 사용자 사용)
  const testUserId = 1;
  const testAdminId = 1;

  describe("user.points (사용자 포인트 내역 조회)", () => {
    it("사용자는 자신의 포인트 내역을 조회할 수 있다", async () => {
      const ctx = createTestContext({ id: testUserId, role: "user" });
      const caller = appRouter.createCaller(ctx);

      const result = await caller.user.points({ page: 1, limit: 10 });

      expect(result).toBeDefined();
      expect(result.history).toBeInstanceOf(Array);
      expect(result.total).toBeGreaterThanOrEqual(0);

      // 내역이 있으면 첫 번째 내역 검증
      if (result.history.length > 0) {
        const firstHistory = result.history[0];
        expect(firstHistory).toHaveProperty("id");
        expect(firstHistory).toHaveProperty("userId", testUserId);
        expect(firstHistory).toHaveProperty("amount");
        expect(firstHistory).toHaveProperty("type");
        expect(firstHistory).toHaveProperty("description");
        expect(firstHistory).toHaveProperty("createdAt");
      }
    });

    it("페이지네이션이 정상 작동한다", async () => {
      const ctx = createTestContext({ id: testUserId, role: "user" });
      const caller = appRouter.createCaller(ctx);

      const page1 = await caller.user.points({ page: 1, limit: 2 });
      const page2 = await caller.user.points({ page: 2, limit: 2 });

      expect(page1.history.length).toBeLessThanOrEqual(2);
      expect(page2.history.length).toBeGreaterThanOrEqual(0);
      expect(page1.total).toBe(page2.total);
    });

    it("비로그인 사용자는 포인트 내역을 조회할 수 없다", async () => {
      const ctx = createTestContext(null);
      const caller = appRouter.createCaller(ctx);

      await expect(caller.user.points()).rejects.toThrow();
    });
  });

  describe("user.adminPointHistory (관리자 전체 포인트 내역 조회)", () => {
    it("관리자는 전체 포인트 내역을 조회할 수 있다", async () => {
      const ctx = createTestContext({ id: testAdminId, role: "admin" });
      const caller = appRouter.createCaller(ctx);

      const result = await caller.user.adminPointHistory({ page: 1, limit: 20 });

      expect(result).toBeDefined();
      expect(result.history).toBeInstanceOf(Array);
      expect(result.total).toBeGreaterThanOrEqual(0);

      // 내역이 있으면 첫 번째 내역 검증 (사용자 정보 포함)
      if (result.history.length > 0) {
        const firstHistory = result.history[0];
        expect(firstHistory).toHaveProperty("id");
        expect(firstHistory).toHaveProperty("userId");
        expect(firstHistory).toHaveProperty("userName");
        expect(firstHistory).toHaveProperty("amount");
        expect(firstHistory).toHaveProperty("type");
        expect(firstHistory).toHaveProperty("description");
        expect(firstHistory).toHaveProperty("createdAt");
      }
    });

    it("관리자는 특정 사용자의 포인트 내역만 필터링할 수 있다", async () => {
      const ctx = createTestContext({ id: testAdminId, role: "admin" });
      const caller = appRouter.createCaller(ctx);

      const result = await caller.user.adminPointHistory({ userId: testUserId, page: 1, limit: 20 });

      expect(result).toBeDefined();
      expect(result.history).toBeInstanceOf(Array);
      expect(result.total).toBeGreaterThanOrEqual(0);
      
      // 모든 내역이 해당 사용자의 것인지 확인
      result.history.forEach(h => {
        expect(h.userId).toBe(testUserId);
      });
    });

    it("관리자는 포인트 유형별로 필터링할 수 있다", async () => {
      const ctx = createTestContext({ id: testAdminId, role: "admin" });
      const caller = appRouter.createCaller(ctx);

      const earnResult = await caller.user.adminPointHistory({ type: "earn", page: 1, limit: 20 });
      const useResult = await caller.user.adminPointHistory({ type: "use", page: 1, limit: 20 });

      expect(earnResult.history).toBeInstanceOf(Array);
      expect(useResult.history).toBeInstanceOf(Array);

      // 적립 내역은 모두 "earn" 타입
      earnResult.history.forEach(h => {
        expect(h.type).toBe("earn");
      });

      // 사용 내역은 모두 "use" 타입
      useResult.history.forEach(h => {
        expect(h.type).toBe("use");
      });
    });

    it("관리자는 사용자 ID와 유형을 동시에 필터링할 수 있다", async () => {
      const ctx = createTestContext({ id: testAdminId, role: "admin" });
      const caller = appRouter.createCaller(ctx);

      const result = await caller.user.adminPointHistory({ 
        userId: testUserId, 
        type: "earn", 
        page: 1, 
        limit: 20 
      });

      expect(result).toBeDefined();
      expect(result.history).toBeInstanceOf(Array);
      
      // 모든 내역이 해당 사용자의 "earn" 타입인지 확인
      result.history.forEach(h => {
        expect(h.userId).toBe(testUserId);
        expect(h.type).toBe("earn");
      });
    });

    it("일반 사용자는 전체 포인트 내역을 조회할 수 없다", async () => {
      const ctx = createTestContext({ id: testUserId, role: "user" });
      const caller = appRouter.createCaller(ctx);

      await expect(caller.user.adminPointHistory()).rejects.toThrow();
    });

    it("비로그인 사용자는 전체 포인트 내역을 조회할 수 없다", async () => {
      const ctx = createTestContext(null);
      const caller = appRouter.createCaller(ctx);

      await expect(caller.user.adminPointHistory()).rejects.toThrow();
    });
  });

  describe("user.adminAddPoints (관리자 포인트 지급)", () => {
    it("관리자는 사용자에게 포인트를 지급할 수 있다", async () => {
      const ctx = createTestContext({ id: testAdminId, role: "admin" });
      const caller = appRouter.createCaller(ctx);

      const beforeUser = await db.getUserById(testUserId);
      const beforePoints = beforeUser?.points ?? 0;

      await caller.user.adminAddPoints({
        userId: testUserId,
        amount: 100,
        description: "테스트 포인트 지급",
      });

      const afterUser = await db.getUserById(testUserId);
      const afterPoints = afterUser?.points ?? 0;

      expect(afterPoints).toBe(beforePoints + 100);

      // 포인트 내역 확인
      const history = await db.getPointHistory(testUserId, 1, 1);
      expect(history.history[0].type).toBe("admin");
      expect(history.history[0].amount).toBe(100);
      expect(history.history[0].description).toBe("테스트 포인트 지급");
    });

    it("일반 사용자는 포인트를 지급할 수 없다", async () => {
      const ctx = createTestContext({ id: testUserId, role: "user" });
      const caller = appRouter.createCaller(ctx);

      await expect(caller.user.adminAddPoints({
        userId: testAdminId,
        amount: 1000,
        description: "테스트",
      })).rejects.toThrow();
    });
  });
});
