import { describe, it, expect, vi } from "vitest";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createContext(user?: Partial<AuthenticatedUser>): TrpcContext {
  const defaultUser: AuthenticatedUser = {
    id: 1,
    openId: "test-user-1",
    email: "test@example.com",
    name: "테스트 유저",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user: user === undefined ? null : { ...defaultUser, ...user },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: vi.fn() } as unknown as TrpcContext["res"],
  };
}

const adminCtx = createContext({ id: 99, name: "관리자", role: "admin", openId: "admin-1" });
const userCtx = createContext({ id: 1, name: "일반유저" });
const publicCtx = createContext(undefined);

vi.mock("./db", async () => {
  const actual = await vi.importActual("./db");

  const mockUser = {
    id: 1, openId: "user-1", name: "테스트유저", email: "test@test.com",
    phone: "010-1234-5678", loginMethod: "manus", role: "user", grade: "bronze",
    points: 1000, totalSpent: 50000, createdAt: new Date(), updatedAt: new Date(),
    lastSignedIn: new Date(), emailNotifications: 1, emailNotifyOrder: 1,
    emailNotifyPoint: 1, emailNotifyReview: 1, emailNotifyComment: 1, emailNotifySystem: 1,
  };

  const mockAddresses = [{
    id: 1, userId: 1, name: "집", recipient: "홍길동", phone: "010-1111-2222",
    zipCode: "12345", address1: "서울시 강남구", address2: "101호",
    addressEn1: "Gangnam-gu, Seoul", addressEn2: "101", isDefault: 1, createdAt: new Date(),
  }];

  const mockOrders = {
    orders: [{
      id: 1, userId: 1, orderNumber: "ORD-001", status: "paid", totalAmount: 30000,
      discountAmount: 0, shippingFee: 3000, pointsUsed: 0, pointsEarned: 300,
      couponId: null, couponDiscount: 0, recipientName: "홍길동",
      recipientPhone: "010-1111-2222", zipCode: "12345", address1: "서울시 강남구",
      address2: "101호", addressEn1: null, addressEn2: null, memo: null,
      paidAt: new Date(), shippedAt: null, deliveredAt: null,
      createdAt: new Date(), updatedAt: new Date(), shipmentStatus: null,
    }],
    total: 1,
  };

  const mockPointHistory = {
    history: [{ id: 1, userId: 1, amount: 100, type: "admin", description: "관리자 지급", createdAt: new Date(), expiresAt: null }],
    total: 1,
  };

  return {
    ...actual,
    getUserById: vi.fn().mockImplementation(async (id: number) => id === 1 ? mockUser : undefined),
    getUserAddresses: vi.fn().mockResolvedValue(mockAddresses),
    getUserOrders: vi.fn().mockResolvedValue(mockOrders),
    getPointHistory: vi.fn().mockResolvedValue(mockPointHistory),
    updateUserGradeAndPoints: vi.fn().mockResolvedValue(undefined),
    adminUpdateAddress: vi.fn().mockResolvedValue(undefined),
    adminDeleteAddress: vi.fn().mockResolvedValue(undefined),
    addPoints: vi.fn().mockResolvedValue(undefined),
    getAllUsers: vi.fn().mockResolvedValue({ users: [mockUser], total: 1 }),
    getAdminStats: vi.fn().mockResolvedValue({ totalUsers: 1, totalProducts: 0, totalOrders: 0, totalRevenue: 0, pendingOrders: 0, todayOrders: 0, todayRevenue: 0, newUsersToday: 0 }),
  };
});

// Import after mock
const { appRouter } = await import("./routers");

describe("Admin User Detail Management", () => {
  const caller = appRouter.createCaller;

  describe("userDetailFull", () => {
    it("관리자가 회원 상세 정보를 조회할 수 있다", async () => {
      const result = await caller(adminCtx).admin.userDetailFull({ id: 1 });
      expect(result).not.toBeNull();
      expect(result!.user.id).toBe(1);
      expect(result!.user.name).toBe("테스트유저");
      expect(result!.user.email).toBe("test@test.com");
      expect(result!.addresses).toHaveLength(1);
      expect(result!.orders).toHaveLength(1);
      expect(result!.pointHistory).toHaveLength(1);
    });

    it("존재하지 않는 회원은 null을 반환한다", async () => {
      const result = await caller(adminCtx).admin.userDetailFull({ id: 999 });
      expect(result).toBeNull();
    });

    it("일반 사용자는 회원 상세를 조회할 수 없다", async () => {
      await expect(caller(userCtx).admin.userDetailFull({ id: 1 })).rejects.toThrow();
    });

    it("비로그인 사용자는 회원 상세를 조회할 수 없다", async () => {
      await expect(caller(publicCtx).admin.userDetailFull({ id: 1 })).rejects.toThrow();
    });
  });

  describe("updateUserInfo", () => {
    it("관리자가 회원 정보를 수정할 수 있다", async () => {
      const result = await caller(adminCtx).admin.updateUserInfo({
        id: 1, name: "수정된이름", email: "new@test.com", phone: "010-9999-8888",
      });
      expect(result.success).toBe(true);
    });

    it("관리자가 등급과 역할을 변경할 수 있다", async () => {
      const result = await caller(adminCtx).admin.updateUserInfo({
        id: 1, grade: "gold", role: "admin",
      });
      expect(result.success).toBe(true);
    });

    it("일반 사용자는 회원 정보를 수정할 수 없다", async () => {
      await expect(caller(userCtx).admin.updateUserInfo({ id: 1, name: "해킹" })).rejects.toThrow();
    });
  });

  describe("updateUserAddress", () => {
    it("관리자가 회원 주소를 수정할 수 있다", async () => {
      const result = await caller(adminCtx).admin.updateUserAddress({
        id: 1, recipient: "새수령인", phone: "010-5555-6666", address1: "부산시 해운대구",
      });
      expect(result.success).toBe(true);
    });

    it("일반 사용자는 주소를 수정할 수 없다", async () => {
      await expect(caller(userCtx).admin.updateUserAddress({ id: 1, recipient: "해킹" })).rejects.toThrow();
    });
  });

  describe("deleteUserAddress", () => {
    it("관리자가 회원 주소를 삭제할 수 있다", async () => {
      const result = await caller(adminCtx).admin.deleteUserAddress({ id: 1 });
      expect(result.success).toBe(true);
    });

    it("일반 사용자는 주소를 삭제할 수 없다", async () => {
      await expect(caller(userCtx).admin.deleteUserAddress({ id: 1 })).rejects.toThrow();
    });
  });

  describe("userOrders", () => {
    it("관리자가 회원 주문 내역을 조회할 수 있다", async () => {
      const result = await caller(adminCtx).admin.userOrders({ userId: 1 });
      expect(result.orders).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it("페이지네이션이 동작한다", async () => {
      const result = await caller(adminCtx).admin.userOrders({ userId: 1, page: 1, limit: 5 });
      expect(result).toBeDefined();
    });

    it("일반 사용자는 조회할 수 없다", async () => {
      await expect(caller(userCtx).admin.userOrders({ userId: 1 })).rejects.toThrow();
    });
  });

  describe("userPointHistory", () => {
    it("관리자가 회원 포인트 내역을 조회할 수 있다", async () => {
      const result = await caller(adminCtx).admin.userPointHistory({ userId: 1 });
      expect(result.history).toHaveLength(1);
      expect(result.total).toBe(1);
    });

    it("일반 사용자는 조회할 수 없다", async () => {
      await expect(caller(userCtx).admin.userPointHistory({ userId: 1 })).rejects.toThrow();
    });
  });
});
