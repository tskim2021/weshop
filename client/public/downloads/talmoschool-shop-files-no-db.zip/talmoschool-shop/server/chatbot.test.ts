import { describe, it, expect, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };
}

function createUserContext(overrides?: Partial<AuthenticatedUser>): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user-001",
    email: "test@example.com",
    name: "테스트 유저",
    loginMethod: "manus",
    role: "user",
    phone: null,
    grade: "bronze",
    points: 1000,
    totalSpent: 0,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };
}

function createAdminContext(): TrpcContext {
  return createUserContext({ id: 99, role: "admin", openId: "admin-001" });
}

describe("Chatbot Admin Features", () => {

  describe("Chatbot Settings", () => {
    it("should get chatbot settings", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const settings = await caller.chatbotAdmin.getSettings();
      expect(settings).toBeDefined();
      expect(settings).toHaveProperty("isEnabled");
      expect(settings).toHaveProperty("greetingMessage");
    });

    it("should update chatbot settings", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.chatbotAdmin.updateSettings({
        greetingMessage: "테스트 인사말",
        isEnabled: 1,
      });
      expect(result.success).toBe(true);

      const settings = await caller.chatbotAdmin.getSettings();
      expect(settings?.greetingMessage).toBe("테스트 인사말");
    });
  });

  describe("Chatbot Categories", () => {
    let categoryId: number;

    it("should create a category", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.chatbotAdmin.createCategory({
        name: "테스트 카테고리",
        icon: "📦",
        description: "테스트용 카테고리입니다",
        sortOrder: 0,
        isActive: 1,
      });
      expect(result.id).toBeGreaterThan(0);
      categoryId = result.id;
    });

    it("should get all categories", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const categories = await caller.chatbotAdmin.getAllCategories();
      expect(categories).toBeDefined();
      expect(Array.isArray(categories)).toBe(true);
      expect(categories.length).toBeGreaterThan(0);
    });

    it("should update a category", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.chatbotAdmin.updateCategory({
        id: categoryId,
        name: "수정된 카테고리",
      });
      expect(result.success).toBe(true);
    });

    it("should delete a category", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.chatbotAdmin.deleteCategory({ id: categoryId });
      expect(result.success).toBe(true);
    });
  });

  describe("Chatbot QnA", () => {
    let categoryId: number;
    let qnaId: number;

    beforeAll(async () => {
      // 테스트용 카테고리 생성
      const caller = appRouter.createCaller(createAdminContext());
      const catResult = await caller.chatbotAdmin.createCategory({
        name: "QnA 테스트 카테고리",
        sortOrder: 0,
        isActive: 1,
      });
      categoryId = catResult.id;
    });

    it("should create a QnA", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.chatbotAdmin.createQna({
        categoryId,
        question: "배송비는 얼마인가요?",
        answer: "3만원 이상 무료배송입니다.",
        sortOrder: 0,
        isActive: 1,
      });
      expect(result.id).toBeGreaterThan(0);
      qnaId = result.id;
    });

    it("should get all QnA", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const qnaList = await caller.chatbotAdmin.getAllQna();
      expect(qnaList).toBeDefined();
      expect(Array.isArray(qnaList)).toBe(true);
      expect(qnaList.length).toBeGreaterThan(0);
    });

    it("should get QnA by category", async () => {
      const caller = appRouter.createCaller(createPublicContext());
      const qnaList = await caller.chatbot.getQnaByCategory({ categoryId });
      expect(qnaList).toBeDefined();
      expect(Array.isArray(qnaList)).toBe(true);
    });

    it("should update a QnA", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.chatbotAdmin.updateQna({
        id: qnaId,
        answer: "수정된 답변입니다.",
      });
      expect(result.success).toBe(true);
    });

    it("should delete a QnA", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.chatbotAdmin.deleteQna({ id: qnaId });
      expect(result.success).toBe(true);
    });
  });

  describe("Chatbot Conversations", () => {
    it("should save a conversation", async () => {
      const caller = appRouter.createCaller(createUserContext());
      const result = await caller.chatbot.saveConversation({
        userMessage: "안녕하세요",
        botResponse: "안녕하세요! 무엇을 도와드릴까요?",
      });
      expect(result).toBeGreaterThan(0);
    });

    it("should get conversations (admin)", async () => {
      const caller = appRouter.createCaller(createAdminContext());
      const result = await caller.chatbotAdmin.getConversations({
        page: 1,
        limit: 10,
      });
      expect(result).toBeDefined();
      expect(result.conversations).toBeDefined();
      expect(Array.isArray(result.conversations)).toBe(true);
      expect(result.total).toBeGreaterThanOrEqual(0);
    });
  });
});
