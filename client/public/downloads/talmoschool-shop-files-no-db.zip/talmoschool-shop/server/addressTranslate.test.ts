import { describe, it, expect, vi } from "vitest";
import { z } from "zod";

describe("Address Translation", () => {
  it("should validate Korean text input", () => {
    const schema = z.object({
      koreanText: z.string().min(1).max(500),
    });

    const validInput = { koreanText: "서울시 강남구 테헤란로 123" };
    expect(() => schema.parse(validInput)).not.toThrow();

    const emptyInput = { koreanText: "" };
    expect(() => schema.parse(emptyInput)).toThrow();

    const tooLongInput = { koreanText: "a".repeat(501) };
    expect(() => schema.parse(tooLongInput)).toThrow();
  });

  it("should handle translation response structure", () => {
    const translationResponse = {
      success: true,
      englishText: "123 Teheran-ro, Gangnam-gu, Seoul",
    };

    expect(translationResponse).toHaveProperty("success");
    expect(translationResponse).toHaveProperty("englishText");
    expect(typeof translationResponse.englishText).toBe("string");
  });

  it("should handle fallback response when translation fails", () => {
    const fallbackResponse = {
      success: false,
      englishText: "Fallback text",
      error: "Translation service unavailable",
    };

    expect(fallbackResponse).toHaveProperty("success", false);
    expect(fallbackResponse).toHaveProperty("error");
  });

  it("should support various Korean address formats", () => {
    const addresses = [
      "서울시 강남구 테헤란로 123",
      "부산시 해운대구 센텀중앙로 1",
      "대구시 중구 동성로 123",
      "동/호수 입력",
      "아파트명 123동 456호",
    ];

    addresses.forEach((addr) => {
      const schema = z.object({ koreanText: z.string().min(1).max(500) });
      expect(() => schema.parse({ koreanText: addr })).not.toThrow();
    });
  });
});
