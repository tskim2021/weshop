import { describe, it, expect, beforeAll } from "vitest";
import * as db from "./db";
import { sendEmail, generateEmailTemplate } from "./_core/email";

describe("이메일 알림 시스템", () => {
  let testUserId: number;

  beforeAll(async () => {
    // 테스트용 사용자 생성
    await db.upsertUser({
      openId: "test-email-notification-user",
      name: "테스트 사용자",
      email: "test@example.com",
      loginMethod: "test",
    });
    const user = await db.getUserByOpenId("test-email-notification-user");
    if (!user) throw new Error("테스트 사용자 생성 실패");
    testUserId = user.id;
  });

  it("이메일 템플릿이 올바르게 생성되어야 함", async () => {
    const html = await generateEmailTemplate({
      title: "테스트 제목",
      content: "테스트 내용입니다.",
      actionUrl: "https://example.com/test",
      actionText: "확인하기",
    });

    expect(html).toContain("테스트 제목");
    expect(html).toContain("테스트 내용입니다.");
    expect(html).toContain("https://example.com/test");
    expect(html).toContain("확인하기");
    expect(html).toContain("탈모학교");
  });

  it("이메일 알림 수신 설정이 켜져 있으면 알림 생성 시 이메일이 발송되어야 함", async () => {
    // 이메일 알림 수신 설정 켜기
    await db.updateUserProfile(testUserId, { emailNotifications: 1 });

    // 알림 생성 (이메일 발송 포함)
    await db.createNotification(
      testUserId,
      "system",
      "테스트 알림",
      "이메일 알림 테스트입니다.",
      "/test"
    );

    // 알림이 생성되었는지 확인
    const notifications = await db.getUserNotifications(testUserId, 1, 10);
    expect(notifications.notifications.length).toBeGreaterThan(0);
    expect(notifications.notifications[0].title).toBe("테스트 알림");
  });

  it("이메일 알림 수신 설정이 꺼져 있으면 알림 생성 시 이메일이 발송되지 않아야 함", async () => {
    // 이메일 알림 수신 설정 끄기
    await db.updateUserProfile(testUserId, { emailNotifications: 0 });

    // 알림 생성 (이메일 발송 안 됨)
    await db.createNotification(
      testUserId,
      "system",
      "테스트 알림 2",
      "이메일 알림 테스트 2입니다.",
      "/test2"
    );

    // 알림이 생성되었는지 확인
    const notifications = await db.getUserNotifications(testUserId, 1, 10);
    expect(notifications.notifications.length).toBeGreaterThan(0);
  });

  it("사용자 프로필 수정 시 이메일 알림 설정이 업데이트되어야 함", async () => {
    // 이메일 알림 수신 설정 켜기
    await db.updateUserProfile(testUserId, { emailNotifications: 1 });
    let user = await db.getUserById(testUserId);
    expect(user?.emailNotifications).toBe(1);

    // 이메일 알림 수신 설정 끄기
    await db.updateUserProfile(testUserId, { emailNotifications: 0 });
    user = await db.getUserById(testUserId);
    expect(user?.emailNotifications).toBe(0);
  });
});
