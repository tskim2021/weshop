import { describe, it, expect, vi } from "vitest";
import * as db from "./db";
import * as trackApi from "./_core/17trackApi";

describe("refreshTracking - 배송 정보 수동 새로고침", () => {
  it("17track API로 배송 정보를 가져와서 DB에 저장해야 함", async () => {
    // Mock 17track API 응답
    const mockTrackingInfo = {
      status: "InTransit",
      events: [
        {
          time: "2026-02-10T13:53:26Z",
          description: "Receive item at office of exchange (Otb)",
          location: "MUMBAI AIRPORT SORTING OFFICE",
          details: "Receive item at office of exchange (Otb)",
        },
        {
          time: "2026-02-10T12:56:15Z",
          description: "Receive item from customer (Otb)",
          location: "Unknown",
          details: "Receive item from customer (Otb)",
        },
      ],
    };

    vi.spyOn(trackApi, "getTrackingInfo").mockResolvedValue(mockTrackingInfo);
    vi.spyOn(trackApi, "mapStatusToSystem").mockReturnValue("in_transit");
    vi.spyOn(db, "updateShipmentStatus").mockResolvedValue(undefined);
    vi.spyOn(db, "createShippingHistory").mockResolvedValue(1);

    // 17track API 호출
    const trackingInfo = await trackApi.getTrackingInfo("LP081795723IN");
    expect(trackingInfo).toEqual(mockTrackingInfo);

    // shipment 상태 업데이트
    const newStatus = trackApi.mapStatusToSystem(trackingInfo!.status);
    await db.updateShipmentStatus(1, newStatus);
    expect(db.updateShipmentStatus).toHaveBeenCalledWith(1, "in_transit");

    // 배송 이력 저장
    for (const event of trackingInfo!.events) {
      await db.createShippingHistory({
        shipmentId: 1,
        status: event.description,
        location: event.location || "Unknown",
        description: event.details || event.description,
        timestamp: new Date(event.time),
      });
    }
    expect(db.createShippingHistory).toHaveBeenCalledTimes(2);
  });

  it("createShippingHistory가 올바른 형식으로 데이터를 저장해야 함", async () => {
    const mockData = {
      shipmentId: 1,
      status: "Receive item at office of exchange (Otb)",
      location: "MUMBAI AIRPORT SORTING OFFICE",
      description: "Receive item at office of exchange (Otb)",
      timestamp: new Date("2026-02-10T13:53:26Z"),
    };

    vi.spyOn(db, "createShippingHistory").mockResolvedValue(1);

    const result = await db.createShippingHistory(mockData);
    expect(result).toBe(1);
    expect(db.createShippingHistory).toHaveBeenCalledWith(mockData);
  });

  it("mapStatusToSystem이 17track 상태를 시스템 상태로 변환해야 함", () => {
    // 17track은 숫자 상태 코드를 사용합니다
    expect(trackApi.mapStatusToSystem(2)).toBe("in_transit"); // InTransit
    expect(trackApi.mapStatusToSystem(5)).toBe("delivered"); // Delivered
    expect(trackApi.mapStatusToSystem(6)).toBe("delivered"); // Delivered (alternative)
    expect(trackApi.mapStatusToSystem(3)).toBe("picked_up"); // PickUp
    expect(trackApi.mapStatusToSystem(0)).toBe("pending"); // NotFound
    expect(trackApi.mapStatusToSystem(999)).toBe("pending"); // Unknown
  });
});
