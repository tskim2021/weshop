import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import * as db from "./db";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTestContext(user: { id: number; role: "user" | "admin" } | null): TrpcContext {
  if (!user) {
    return {
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
    };
  }
  const authenticatedUser: AuthenticatedUser = {
    id: user.id,
    openId: `test-user-${user.id}`,
    email: `test${user.id}@example.com`,
    name: `테스트 유저 ${user.id}`,
    loginMethod: "oauth",
    role: user.role,
    phone: null,
    grade: "bronze",
    points: 0,
    totalSpent: 0,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };
  return {
    user: authenticatedUser,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as unknown as TrpcContext["res"],
  };
}

describe("Point Expiration System", () => {
  const testUserId = 1;
  const testAdminId = 1;

  describe("getPointExpirationMonths (포인트 만료 기간 조회)", () => {
    it("사용자는 포인트 만료 기간을 조회할 수 있다", async () => {
      const ctx = createTestContext({ id: testUserId, role: "user" });
      const caller = appRouter.createCaller(ctx);

      const months = await caller.user.getPointExpirationMonths();

      expect(months).toBeDefined();
      expect(typeof months).toBe("number");
      expect(months).toBeGreaterThan(0);
    });
  });

  describe("adminSetPointExpirationMonths (관리자 포인트 만료 기간 설정)", () => {
    it("관리자는 포인트 만료 기간을 설정할 수 있다", async () => {
      const ctx = createTestContext({ id: testAdminId, role: "admin" });
      const caller = appRouter.createCaller(ctx);

      const result = await caller.user.adminSetPointExpirationMonths({ months: 24 });

      expect(result).toBeDefined();
      expect(result.success).toBe(true);

      // 설정이 저장되었는지 확인
      const months = await caller.user.getPointExpirationMonths();
      expect(months).toBe(24);
    });

    it("일반 사용자는 포인트 만료 기간을 설정할 수 없다", async () => {
      const ctx = createTestContext({ id: testUserId, role: "user" });
      const caller = appRouter.createCaller(ctx);

      await expect(caller.user.adminSetPointExpirationMonths({ months: 24 })).rejects.toThrow();
    });

    it("만료 기간은 1~120개월 범위 내에서만 설정 가능하다", async () => {
      const ctx = createTestContext({ id: testAdminId, role: "admin" });
      const caller = appRouter.createCaller(ctx);

      await expect(caller.user.adminSetPointExpirationMonths({ months: 0 })).rejects.toThrow();
      await expect(caller.user.adminSetPointExpirationMonths({ months: 121 })).rejects.toThrow();
    });
  });

  describe("expiringPoints (만료 예정 포인트 조회)", () => {
    it("사용자는 만료 예정 포인트를 조회할 수 있다", async () => {
      const ctx = createTestContext({ id: testUserId, role: "user" });
      const caller = appRouter.createCaller(ctx);

      const result = await caller.user.expiringPoints({ daysBeforeExpiration: 30 });

      expect(result).toBeDefined();
      expect(result).toHaveProperty("totalExpiring");
      expect(result).toHaveProperty("items");
      expect(typeof result.totalExpiring).toBe("number");
      expect(Array.isArray(result.items)).toBe(true);
    });

    it("만료 예정 포인트는 날짜 순으로 정렬된다", async () => {
      const ctx = createTestContext({ id: testUserId, role: "user" });
      const caller = appRouter.createCaller(ctx);

      const result = await caller.user.expiringPoints({ daysBeforeExpiration: 365 });

      if (result.items.length > 1) {
        for (let i = 0; i < result.items.length - 1; i++) {
          const current = result.items[i].expiresAt;
          const next = result.items[i + 1].expiresAt;
          if (current && next) {
            expect(new Date(current).getTime()).toBeLessThanOrEqual(new Date(next).getTime());
          }
        }
      }
    });

    it("비로그인 사용자는 만료 예정 포인트를 조회할 수 없다", async () => {
      const ctx = createTestContext(null);
      const caller = appRouter.createCaller(ctx);

      await expect(caller.user.expiringPoints()).rejects.toThrow();
    });
  });

  describe("adminExpirePoints (관리자 포인트 만료 처리)", () => {
    it("관리자는 만료된 포인트를 즉시 처리할 수 있다", async () => {
      const ctx = createTestContext({ id: testAdminId, role: "admin" });
      const caller = appRouter.createCaller(ctx);

      const result = await caller.user.adminExpirePoints();

      expect(result).toBeDefined();
      expect(result).toHaveProperty("expiredCount");
      expect(result).toHaveProperty("totalExpiredPoints");
      expect(typeof result.expiredCount).toBe("number");
      expect(typeof result.totalExpiredPoints).toBe("number");
      expect(result.expiredCount).toBeGreaterThanOrEqual(0);
      expect(result.totalExpiredPoints).toBeGreaterThanOrEqual(0);
    });

    it("일반 사용자는 포인트 만료 처리를 실행할 수 없다", async () => {
      const ctx = createTestContext({ id: testUserId, role: "user" });
      const caller = appRouter.createCaller(ctx);

      await expect(caller.user.adminExpirePoints()).rejects.toThrow();
    });
  });

  describe("addPoints with expiration (포인트 적립 시 만료일 자동 설정)", () => {
    it("포인트 적립 시 만료일이 자동으로 설정된다", async () => {
      const beforeUser = await db.getUserById(testUserId);
      const beforePoints = beforeUser?.points ?? 0;

      await db.addPoints(testUserId, 1000, "earn", "테스트 적립");

      const afterUser = await db.getUserById(testUserId);
      const afterPoints = afterUser?.points ?? 0;

      expect(afterPoints).toBe(beforePoints + 1000);

      // 포인트 내역 확인
      const history = await db.getPointHistory(testUserId, 1, 1);
      const latestHistory = history.history[0];

      expect(latestHistory.type).toBe("earn");
      expect(latestHistory.amount).toBe(1000);
      expect(latestHistory.expiresAt).not.toBeNull();

      // 만료일이 미래인지 확인
      if (latestHistory.expiresAt) {
        expect(new Date(latestHistory.expiresAt).getTime()).toBeGreaterThan(Date.now());
      }
    });

    it("관리자 지급 포인트도 만료일이 설정된다", async () => {
      const beforeUser = await db.getUserById(testUserId);
      const beforePoints = beforeUser?.points ?? 0;

      await db.addPoints(testUserId, 500, "admin", "관리자 지급");

      const afterUser = await db.getUserById(testUserId);
      const afterPoints = afterUser?.points ?? 0;

      expect(afterPoints).toBe(beforePoints + 500);

      // 포인트 내역 확인
      const history = await db.getPointHistory(testUserId, 1, 1);
      const latestHistory = history.history[0];

      expect(latestHistory.type).toBe("admin");
      expect(latestHistory.expiresAt).not.toBeNull();
    });

    it("사용 및 환불 포인트는 만료일이 설정되지 않는다", async () => {
      // 먼저 포인트 적립
      await db.addPoints(testUserId, 1000, "earn", "테스트 적립");

      // 포인트 사용
      await db.addPoints(testUserId, 100, "use", "테스트 사용");

      // 사용 내역 확인
      const history = await db.getPointHistory(testUserId, 1, 10);
      const useHistory = history.history.find(h => h.type === "use" && h.description === "테스트 사용");

      expect(useHistory).toBeDefined();
      expect(useHistory?.expiresAt).toBeNull();
    });
  });

  describe("Point expiration calculation (포인트 만료일 계산)", () => {
    it("만료일은 적립일로부터 설정된 개월 수만큼 후로 계산된다", async () => {
      // 만료 기간을 6개월로 설정
      await db.setPointExpirationMonths(6);

      const beforeDate = new Date();
      await db.addPoints(testUserId, 100, "earn", "만료일 테스트");

      const history = await db.getPointHistory(testUserId, 1, 1);
      const latestHistory = history.history[0];

      expect(latestHistory.expiresAt).not.toBeNull();

      if (latestHistory.expiresAt) {
        const expiresAt = new Date(latestHistory.expiresAt);
        const expectedDate = new Date(beforeDate);
        expectedDate.setMonth(expectedDate.getMonth() + 6);

        // 날짜 차이가 1일 이내인지 확인 (시간대 차이 고려)
        const diff = Math.abs(expiresAt.getTime() - expectedDate.getTime());
        expect(diff).toBeLessThan(24 * 60 * 60 * 1000);
      }
    });
  });
});
