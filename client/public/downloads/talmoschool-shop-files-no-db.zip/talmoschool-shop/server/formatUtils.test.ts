import { describe, it, expect } from "vitest";

// We test the same logic as client/src/lib/utils.ts formatDate/formatDateTime
// Reimplementing here since vitest runs in Node, not browser context

function formatDate(date: Date | string | null | undefined): string {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;
  if (isNaN(d.getTime())) return "-";
  return d.toLocaleDateString("ko-KR", { year: "numeric", month: "2-digit", day: "2-digit" });
}

function formatDateTime(date: Date | string | null | undefined): string {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;
  if (isNaN(d.getTime())) return "-";
  return d.toLocaleString("ko-KR", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" });
}

describe("formatDate 유틸리티 함수", () => {
  it("null 입력 시 '-' 반환", () => {
    expect(formatDate(null)).toBe("-");
  });

  it("undefined 입력 시 '-' 반환", () => {
    expect(formatDate(undefined)).toBe("-");
  });

  it("빈 문자열 입력 시 '-' 반환", () => {
    expect(formatDate("")).toBe("-");
  });

  it("유효하지 않은 날짜 문자열 입력 시 '-' 반환", () => {
    expect(formatDate("invalid-date")).toBe("-");
  });

  it("유효한 Date 객체 입력 시 포맷된 문자열 반환", () => {
    const result = formatDate(new Date("2026-01-15T10:30:00Z"));
    expect(result).toBeTruthy();
    expect(result).not.toBe("-");
  });

  it("유효한 날짜 문자열 입력 시 포맷된 문자열 반환", () => {
    const result = formatDate("2026-01-15T10:30:00Z");
    expect(result).toBeTruthy();
    expect(result).not.toBe("-");
  });
});

describe("formatDateTime 유틸리티 함수", () => {
  it("null 입력 시 '-' 반환", () => {
    expect(formatDateTime(null)).toBe("-");
  });

  it("undefined 입력 시 '-' 반환", () => {
    expect(formatDateTime(undefined)).toBe("-");
  });

  it("빈 문자열 입력 시 '-' 반환", () => {
    expect(formatDateTime("")).toBe("-");
  });

  it("유효하지 않은 날짜 문자열 입력 시 '-' 반환", () => {
    expect(formatDateTime("not-a-date")).toBe("-");
  });

  it("유효한 Date 객체 입력 시 포맷된 문자열 반환", () => {
    const result = formatDateTime(new Date("2026-01-15T10:30:00Z"));
    expect(result).toBeTruthy();
    expect(result).not.toBe("-");
  });

  it("유효한 날짜 문자열 입력 시 포맷된 문자열 반환", () => {
    const result = formatDateTime("2026-01-15T10:30:00Z");
    expect(result).toBeTruthy();
    expect(result).not.toBe("-");
  });

  it("payment.createdAt이 undefined인 시나리오 시뮬레이션", () => {
    const payment: any = { id: 1 }; // createdAt 필드 없음
    expect(formatDateTime(payment.createdAt)).toBe("-");
  });

  it("payment.expiresAt이 null인 시나리오 시뮬레이션", () => {
    const payment: any = { id: 1, expiresAt: null };
    expect(formatDateTime(payment.expiresAt)).toBe("-");
  });
});
