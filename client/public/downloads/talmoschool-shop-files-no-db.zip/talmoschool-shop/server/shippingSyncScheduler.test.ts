import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";

// ─── 스케줄러 설정 DB 헬퍼 테스트 ───
describe("Shipping Sync Scheduler Config", () => {
  it("getShippingSyncSchedulerConfig returns defaults when no settings exist", async () => {
    const { getShippingSyncSchedulerConfig } = await import("./db");
    const config = await getShippingSyncSchedulerConfig();
    
    expect(config).toBeDefined();
    expect(typeof config.enabled).toBe("boolean");
    expect(typeof config.intervalHours).toBe("number");
    expect(config.intervalHours).toBeGreaterThanOrEqual(1);
    expect(config.intervalHours).toBeLessThanOrEqual(48);
  });

  it("updateShippingSyncSchedulerConfig saves enabled setting", async () => {
    const { updateShippingSyncSchedulerConfig, getShippingSyncSchedulerConfig } = await import("./db");
    
    await updateShippingSyncSchedulerConfig({ enabled: false });
    const config = await getShippingSyncSchedulerConfig();
    expect(config.enabled).toBe(false);
    
    // Restore
    await updateShippingSyncSchedulerConfig({ enabled: true });
    const restored = await getShippingSyncSchedulerConfig();
    expect(restored.enabled).toBe(true);
  });

  it("updateShippingSyncSchedulerConfig saves intervalHours setting", async () => {
    const { updateShippingSyncSchedulerConfig, getShippingSyncSchedulerConfig } = await import("./db");
    
    await updateShippingSyncSchedulerConfig({ intervalHours: 6 });
    const config = await getShippingSyncSchedulerConfig();
    expect(config.intervalHours).toBe(6);
    
    // Restore default
    await updateShippingSyncSchedulerConfig({ intervalHours: 12 });
  });

  it("updateShippingSyncLastRun saves last run info", async () => {
    const { updateShippingSyncLastRun, getShippingSyncSchedulerConfig } = await import("./db");
    
    await updateShippingSyncLastRun({
      syncedCount: 5,
      failedCount: 1,
      deliveredCount: 2,
      total: 6,
    });
    
    const config = await getShippingSyncSchedulerConfig();
    expect(config.lastRunAt).toBeTruthy();
    expect(config.lastRunResult).toBeTruthy();
    
    const result = JSON.parse(config.lastRunResult!);
    expect(result.syncedCount).toBe(5);
    expect(result.failedCount).toBe(1);
    expect(result.total).toBe(6);
  });
});

// ─── intervalToCron 함수 테스트 ───
describe("intervalToCron logic", () => {
  it("converts common intervals correctly", async () => {
    // Import the scheduler module to test the cron conversion logic
    const { startShippingSyncScheduler, stopShippingSyncScheduler, getSchedulerStatus } = await import("./jobs/shippingSyncScheduler");
    
    // Test that scheduler starts and stops
    startShippingSyncScheduler({ enabled: true, intervalHours: 6, lastRunAt: null, lastRunResult: null });
    const status = getSchedulerStatus();
    expect(status.isActive).toBe(true);
    expect(status.intervalHours).toBe(6);
    expect(status.isRunning).toBe(false);
    
    stopShippingSyncScheduler();
    const stoppedStatus = getSchedulerStatus();
    expect(stoppedStatus.isActive).toBe(false);
  });

  it("disabling scheduler stops the task", async () => {
    const { startShippingSyncScheduler, getSchedulerStatus } = await import("./jobs/shippingSyncScheduler");
    
    startShippingSyncScheduler({ enabled: false, intervalHours: 12, lastRunAt: null, lastRunResult: null });
    const status = getSchedulerStatus();
    expect(status.isActive).toBe(false);
  });

  it("restartShippingSyncScheduler replaces the existing task", async () => {
    const { startShippingSyncScheduler, restartShippingSyncScheduler, getSchedulerStatus, stopShippingSyncScheduler } = await import("./jobs/shippingSyncScheduler");
    
    startShippingSyncScheduler({ enabled: true, intervalHours: 12, lastRunAt: null, lastRunResult: null });
    expect(getSchedulerStatus().isActive).toBe(true);
    expect(getSchedulerStatus().intervalHours).toBe(12);
    
    restartShippingSyncScheduler({ enabled: true, intervalHours: 3, lastRunAt: null, lastRunResult: null });
    expect(getSchedulerStatus().isActive).toBe(true);
    expect(getSchedulerStatus().intervalHours).toBe(3);
    
    stopShippingSyncScheduler();
  });
});

// ─── tRPC 프로시저 존재 확인 ───
describe("Shipping scheduler tRPC procedures", () => {
  it("getSchedulerConfig procedure exists", async () => {
    const { shippingRouter } = await import("./routers/shipping");
    const procedures = Object.keys(shippingRouter._def.procedures);
    expect(procedures).toContain("getSchedulerConfig");
  });

  it("updateSchedulerConfig procedure exists", async () => {
    const { shippingRouter } = await import("./routers/shipping");
    const procedures = Object.keys(shippingRouter._def.procedures);
    expect(procedures).toContain("updateSchedulerConfig");
  });

  it("runSyncNow procedure exists", async () => {
    const { shippingRouter } = await import("./routers/shipping");
    const procedures = Object.keys(shippingRouter._def.procedures);
    expect(procedures).toContain("runSyncNow");
  });
});
