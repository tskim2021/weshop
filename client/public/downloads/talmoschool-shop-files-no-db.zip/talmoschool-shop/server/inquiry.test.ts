import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock storage
vi.mock("./storage", () => ({
  storagePut: vi.fn().mockResolvedValue({ url: "https://cdn.example.com/test-image.jpg", key: "test-key" }),
}));

// Mock db functions
vi.mock("./db", async () => {
  const actual = await vi.importActual("./db");
  return {
    ...actual,
    createPost: vi.fn().mockResolvedValue(1),
    createInquiryReply: vi.fn().mockResolvedValue(1),
    updateInquiryReply: vi.fn().mockResolvedValue(undefined),
    getInquiryReplies: vi.fn().mockResolvedValue([]),
    getPostById: vi.fn().mockResolvedValue({
      id: 1,
      boardId: 3,
      userId: 1,
      title: "[배송] 테스트 문의",
      content: "테스트 문의 내용",
      images: null,
      rating: null,
      isNotice: 0,
      isPinned: 0,
      viewCount: 0,
      commentCount: 0,
      likeCount: 0,
      isHidden: 0,
      isBest: 0,
      isAnswered: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
      userName: "테스트 사용자",
    }),
  };
});

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createUserContext(role: "user" | "admin" = "user"): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "테스트 사용자",
    loginMethod: "manus",
    role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createAnonContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("문의 첨부파일 업로드", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("로그인한 사용자가 이미지를 업로드할 수 있다", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    // 1x1 투명 PNG (base64)
    const base64Data = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";

    const result = await caller.upload.uploadInquiryImage({
      filename: "test.png",
      contentType: "image/png",
      base64Data,
    });

    expect(result).toHaveProperty("url");
    expect(typeof result.url).toBe("string");
  });

  it("비로그인 사용자는 업로드할 수 없다", async () => {
    const ctx = createAnonContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.upload.uploadInquiryImage({
        filename: "test.png",
        contentType: "image/png",
        base64Data: "dGVzdA==",
      })
    ).rejects.toThrow();
  });

  it("허용되지 않은 파일 형식은 거부된다", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.upload.uploadInquiryImage({
        filename: "test.pdf",
        contentType: "application/pdf",
        base64Data: "dGVzdA==",
      })
    ).rejects.toThrow("이미지 파일만 업로드할 수 있습니다");
  });

  it("허용된 이미지 형식 (JPEG, PNG, GIF, WebP)은 업로드 가능하다", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);
    const base64Data = "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==";

    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
    
    for (const contentType of allowedTypes) {
      const result = await caller.upload.uploadInquiryImage({
        filename: `test.${contentType.split("/")[1]}`,
        contentType,
        base64Data,
      });
      expect(result).toHaveProperty("url");
    }
  });
});

describe("문의 답변 알림", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("관리자가 문의 답변을 작성할 수 있다", async () => {
    const ctx = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.createInquiryReply({
      postId: 1,
      content: "테스트 답변입니다.",
    });

    expect(result).toHaveProperty("id");
  });

  it("관리자가 이미지 첨부와 함께 답변을 작성할 수 있다", async () => {
    const ctx = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.createInquiryReply({
      postId: 1,
      content: "스크린샷을 참고해주세요.",
      attachments: [
        "https://cdn.example.com/reply-image1.jpg",
        "https://cdn.example.com/reply-image2.jpg",
      ],
    });

    expect(result).toHaveProperty("id");
  });

  it("관리자가 이미지 없이 답변을 작성할 수 있다 (attachments 미전달)", async () => {
    const ctx = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.createInquiryReply({
      postId: 1,
      content: "이미지 없는 답변입니다.",
    });

    expect(result).toHaveProperty("id");
  });

  it("관리자가 빈 배열로 attachments를 전달해도 정상 동작한다", async () => {
    const ctx = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.createInquiryReply({
      postId: 1,
      content: "빈 배열 테스트.",
      attachments: [],
    });

    expect(result).toHaveProperty("id");
  });

  it("일반 사용자는 문의 답변을 작성할 수 없다", async () => {
    const ctx = createUserContext("user");
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.createInquiryReply({
        postId: 1,
        content: "테스트 답변입니다.",
      })
    ).rejects.toThrow();
  });

  it("관리자가 문의 답변 목록을 조회할 수 있다", async () => {
    const ctx = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.getInquiryReplies({ postId: 1 });
    expect(Array.isArray(result)).toBe(true);
  });
});

describe("답변 수정 시 이미지 편집", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("관리자가 답변 내용과 이미지를 함께 수정할 수 있다", async () => {
    const ctx = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.updateInquiryReply({
      id: 1,
      content: "수정된 답변 내용입니다.",
      attachments: [
        "https://cdn.example.com/new-image1.jpg",
        "https://cdn.example.com/new-image2.jpg",
      ],
    });

    expect(result).toHaveProperty("success", true);
  });

  it("관리자가 답변 이미지를 모두 삭제할 수 있다 (null 전달)", async () => {
    const ctx = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.updateInquiryReply({
      id: 1,
      content: "이미지 삭제 후 답변.",
      attachments: null,
    });

    expect(result).toHaveProperty("success", true);
  });

  it("관리자가 답변 내용만 수정할 수 있다 (attachments 미전달)", async () => {
    const ctx = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.updateInquiryReply({
      id: 1,
      content: "내용만 수정.",
    });

    expect(result).toHaveProperty("success", true);
  });

  it("관리자가 빈 배열로 attachments를 전달하면 이미지가 삭제된다", async () => {
    const ctx = createUserContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.updateInquiryReply({
      id: 1,
      content: "빈 배열 테스트.",
      attachments: [],
    });

    expect(result).toHaveProperty("success", true);
  });

  it("일반 사용자는 답변을 수정할 수 없다", async () => {
    const ctx = createUserContext("user");
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.updateInquiryReply({
        id: 1,
        content: "수정 시도.",
      })
    ).rejects.toThrow();
  });
});

describe("문의 작성 (첨부파일 포함)", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("이미지 첨부와 함께 문의를 작성할 수 있다", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.community.createPost({
      boardId: 3,
      title: "[배송] 배송 파손 문의",
      content: "상품이 파손되어 도착했습니다.",
      images: [
        "https://cdn.example.com/image1.jpg",
        "https://cdn.example.com/image2.jpg",
      ],
    });

    expect(result).toHaveProperty("success", true);
    expect(result).toHaveProperty("postId");
  });

  it("이미지 없이도 문의를 작성할 수 있다", async () => {
    const ctx = createUserContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.community.createPost({
      boardId: 3,
      title: "[기타] 일반 문의",
      content: "일반 문의 내용입니다.",
    });

    expect(result).toHaveProperty("success", true);
  });

  it("비로그인 사용자는 문의를 작성할 수 없다", async () => {
    const ctx = createAnonContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.community.createPost({
        boardId: 3,
        title: "[기타] 테스트",
        content: "테스트",
      })
    ).rejects.toThrow();
  });
});
