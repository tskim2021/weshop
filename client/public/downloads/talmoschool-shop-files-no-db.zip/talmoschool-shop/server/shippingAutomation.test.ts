import { describe, it, expect } from "vitest";
import { shouldSendEmailForStatus } from "./_core/shippingEmail";

describe("배송 자동화 기능", () => {
  describe("17track 자동 등록", () => {
    it("should have createShipment function with 17track registration", async () => {
      const { createShipment } = await import("./db");
      expect(createShipment).toBeDefined();
    });
  });

  describe("배송 상태 변경 이메일 알림", () => {
    it("should send email for picked_up status", () => {
      expect(shouldSendEmailForStatus("picked_up")).toBe(true);
    });

    it("should send email for in_transit status", () => {
      expect(shouldSendEmailForStatus("in_transit")).toBe(true);
    });

    it("should send email for out_for_delivery status", () => {
      expect(shouldSendEmailForStatus("out_for_delivery")).toBe(true);
    });

    it("should send email for delivered status", () => {
      expect(shouldSendEmailForStatus("delivered")).toBe(true);
    });

    it("should not send email for pending status", () => {
      expect(shouldSendEmailForStatus("pending")).toBe(false);
    });

    it("should not send email for failed status", () => {
      expect(shouldSendEmailForStatus("failed")).toBe(false);
    });
  });

  describe("배송 지연 감지", () => {
    it("should have shippingMonitor router with checkDelayedShipments procedure", async () => {
      const { shippingMonitorRouter } = await import("./routers/shippingMonitor");
      expect(shippingMonitorRouter).toBeDefined();
      expect(shippingMonitorRouter._def.procedures.checkDelayedShipments).toBeDefined();
    });

    it("should have shippingMonitor router with getDelayedShipments procedure", async () => {
      const { shippingMonitorRouter } = await import("./routers/shippingMonitor");
      expect(shippingMonitorRouter._def.procedures.getDelayedShipments).toBeDefined();
    });
  });

  describe("웹훅 통합", () => {
    it("should have webhooks router with shipping email integration", async () => {
      const { webhooksRouter } = await import("./routers/webhooks");
      expect(webhooksRouter).toBeDefined();
      expect(webhooksRouter._def.procedures.seventeentrack).toBeDefined();
    });
  });
});
