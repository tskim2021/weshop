import { describe, expect, it, vi, beforeEach } from "vitest";

// Mock image generation
vi.mock("./_core/imageGeneration", () => ({
  generateImage: vi.fn().mockResolvedValue({
    url: "https://example.com/generated-image.png",
  }),
}));

// Mock db module
vi.mock("./db", () => {
  const mockInfoBoardSettings = [
    {
      id: 1,
      isEnabled: 1,
      categoryId: 2,
      generateTime: "09:00",
      topic: "건강식품 정보",
      keywords: "비타민,오메가3",
      keywordsEn: "vitamin,omega-3",
      promptTemplate: null,
      postStyle: "informative",
      autoPublish: 1,
      autoGenerateImage: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 2,
      isEnabled: 1,
      categoryId: null,
      generateTime: "14:00",
      topic: "운동과 건강",
      keywords: "운동,헬스",
      keywordsEn: null,
      promptTemplate: null,
      postStyle: "tips",
      autoPublish: 1,
      autoGenerateImage: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  const mockDiscussionSettings = [
    {
      id: 1,
      isEnabled: 1,
      categoryId: 3,
      generateTime: "10:00",
      topic: "건강 토론",
      keywords: "건강,식품",
      keywordsEn: "health,food",
      promptTemplate: null,
      discussionStyle: "debate",
      autoPublish: 1,
      autoGenerateImage: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 2,
      isEnabled: 1,
      categoryId: null,
      generateTime: "15:00",
      topic: "약품 토론",
      keywords: "약품",
      keywordsEn: null,
      promptTemplate: null,
      discussionStyle: "opinion",
      autoPublish: 1,
      autoGenerateImage: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  return {
    getInfoBoardAutoSettings: vi.fn().mockResolvedValue(mockInfoBoardSettings),
    getInfoBoardAutoSettingById: vi.fn().mockImplementation(async (id: number) => {
      return mockInfoBoardSettings.find(s => s.id === id);
    }),
    getEnabledInfoBoardAutoSettings: vi.fn().mockResolvedValue(
      mockInfoBoardSettings.filter(s => s.isEnabled === 1)
    ),
    createInfoBoardAutoSetting: vi.fn().mockResolvedValue({ id: 3 }),
    updateInfoBoardAutoSetting: vi.fn().mockResolvedValue(undefined),
    deleteInfoBoardAutoSetting: vi.fn().mockResolvedValue(undefined),
    getInfoBoardAutoLogs: vi.fn().mockResolvedValue({ logs: [], total: 0 }),
    createInfoBoardAutoLog: vi.fn().mockResolvedValue({ id: 1 }),
    getBoardBySlug: vi.fn().mockResolvedValue({ id: 5, name: "정보나눔", slug: "info" }),
    createPost: vi.fn().mockResolvedValue(101),
    getDiscussionAutoSettings: vi.fn().mockResolvedValue(mockDiscussionSettings),
    getDiscussionAutoSettingById: vi.fn().mockImplementation(async (id: number) => {
      return mockDiscussionSettings.find(s => s.id === id);
    }),
    getEnabledDiscussionAutoSettings: vi.fn().mockResolvedValue(
      mockDiscussionSettings.filter(s => s.isEnabled === 1)
    ),
    createDiscussionAutoSetting: vi.fn().mockResolvedValue({ id: 3 }),
    updateDiscussionAutoSetting: vi.fn().mockResolvedValue(undefined),
    deleteDiscussionAutoSetting: vi.fn().mockResolvedValue(undefined),
    getDiscussionAutoLogs: vi.fn().mockResolvedValue({ logs: [], total: 0 }),
    createDiscussionAutoLog: vi.fn().mockResolvedValue({ id: 1 }),
    createDiscussion: vi.fn().mockResolvedValue(201),
    getDb: vi.fn().mockResolvedValue({}),
  };
});

// Mock LLM
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [{
      message: {
        content: JSON.stringify({
          title: "AI 생성 테스트 제목",
          content: "## 테스트 본문\n\nAI가 생성한 테스트 본문입니다."
        })
      }
    }]
  }),
}));

// Mock schedulers
vi.mock("./jobs/infoBoardScheduler", () => ({
  restartInfoBoardScheduler: vi.fn().mockResolvedValue(undefined),
  getInfoBoardSchedulerStatus: vi.fn().mockReturnValue({ isActive: true, scheduleTime: "09:00" }),
}));

vi.mock("./jobs/discussionScheduler", () => ({
  restartDiscussionScheduler: vi.fn().mockResolvedValue(undefined),
  getDiscussionSchedulerStatus: vi.fn().mockReturnValue({ isActive: true, scheduleTime: "10:00" }),
}));

import * as db from "./db";
import { generateImage } from "./_core/imageGeneration";

describe("Auto Image Generation - InfoBoard Settings", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("settings include autoGenerateImage field", async () => {
    const settings = await db.getInfoBoardAutoSettings();
    expect(settings[0]).toHaveProperty("autoGenerateImage");
    expect(settings[0].autoGenerateImage).toBe(1);
    expect(settings[1].autoGenerateImage).toBe(0);
  });

  it("createInfoBoardAutoSetting accepts autoGenerateImage", async () => {
    await db.createInfoBoardAutoSetting({
      topic: "이미지 테스트",
      generateTime: "09:00",
      postStyle: "informative",
      autoPublish: 1,
      autoGenerateImage: 1,
      isEnabled: 1,
    });
    expect(db.createInfoBoardAutoSetting).toHaveBeenCalledWith(
      expect.objectContaining({ autoGenerateImage: 1 })
    );
  });

  it("updateInfoBoardAutoSetting can toggle autoGenerateImage", async () => {
    await db.updateInfoBoardAutoSetting(1, { autoGenerateImage: 0 });
    expect(db.updateInfoBoardAutoSetting).toHaveBeenCalledWith(1, { autoGenerateImage: 0 });
  });
});

describe("Auto Image Generation - Discussion Settings", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("settings include autoGenerateImage field", async () => {
    const settings = await db.getDiscussionAutoSettings();
    expect(settings[0]).toHaveProperty("autoGenerateImage");
    expect(settings[0].autoGenerateImage).toBe(1);
    expect(settings[1].autoGenerateImage).toBe(0);
  });

  it("createDiscussionAutoSetting accepts autoGenerateImage", async () => {
    await db.createDiscussionAutoSetting({
      topic: "이미지 토론 테스트",
      generateTime: "10:00",
      discussionStyle: "debate",
      autoPublish: 1,
      autoGenerateImage: 1,
      isEnabled: 1,
    });
    expect(db.createDiscussionAutoSetting).toHaveBeenCalledWith(
      expect.objectContaining({ autoGenerateImage: 1 })
    );
  });

  it("updateDiscussionAutoSetting can toggle autoGenerateImage", async () => {
    await db.updateDiscussionAutoSetting(1, { autoGenerateImage: 0 });
    expect(db.updateDiscussionAutoSetting).toHaveBeenCalledWith(1, { autoGenerateImage: 0 });
  });
});

describe("Auto Image Generation - InfoBoard Generator", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("generates image when autoGenerateImage is enabled", async () => {
    const { generateInfoBoardPost } = await import("./services/infoBoardGenerator");

    const setting = {
      id: 1,
      isEnabled: 1,
      categoryId: 2,
      generateTime: "09:00",
      topic: "건강식품 정보",
      keywords: "비타민,오메가3",
      keywordsEn: "vitamin,omega-3",
      promptTemplate: null,
      postStyle: "informative" as const,
      autoPublish: 1,
      autoGenerateImage: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const result = await generateInfoBoardPost(setting, 1, "manual");

    expect(result.success).toBe(true);
    expect(generateImage).toHaveBeenCalled();
    expect(db.createPost).toHaveBeenCalledWith(
      expect.objectContaining({
        images: expect.arrayContaining([expect.stringContaining("generated-image")]),
      })
    );
  });

  it("does not generate image when autoGenerateImage is disabled", async () => {
    vi.resetModules();
    vi.clearAllMocks();

    const { generateInfoBoardPost } = await import("./services/infoBoardGenerator");

    const setting = {
      id: 2,
      isEnabled: 1,
      categoryId: null,
      generateTime: "14:00",
      topic: "운동과 건강",
      keywords: "운동,헬스",
      keywordsEn: null,
      promptTemplate: null,
      postStyle: "tips" as const,
      autoPublish: 1,
      autoGenerateImage: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const result = await generateInfoBoardPost(setting, 1, "manual");

    expect(result.success).toBe(true);
    expect(generateImage).not.toHaveBeenCalled();
  });
});

describe("Auto Image Generation - Discussion Generator", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("generates image when autoGenerateImage is enabled", async () => {
    const { generateDiscussionPost } = await import("./services/discussionGenerator");

    const setting = {
      id: 1,
      isEnabled: 1,
      categoryId: 3,
      generateTime: "10:00",
      topic: "건강 토론",
      keywords: "건강,식품",
      keywordsEn: "health,food",
      promptTemplate: null,
      discussionStyle: "debate" as const,
      autoPublish: 1,
      autoGenerateImage: 1,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Ensure createDiscussion returns a valid number
    vi.mocked(db.createDiscussion).mockResolvedValueOnce(201);

    const result = await generateDiscussionPost(setting, 1, "manual");

    expect(result.success).toBe(true);
    expect(generateImage).toHaveBeenCalled();
  });

  it("does not generate image when autoGenerateImage is disabled", async () => {
    vi.clearAllMocks();

    const { generateDiscussionPost } = await import("./services/discussionGenerator");

    const setting = {
      id: 2,
      isEnabled: 1,
      categoryId: null,
      generateTime: "15:00",
      topic: "약품 토론",
      keywords: "약품",
      keywordsEn: null,
      promptTemplate: null,
      discussionStyle: "opinion" as const,
      autoPublish: 1,
      autoGenerateImage: 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Ensure createDiscussion returns a valid number
    vi.mocked(db.createDiscussion).mockResolvedValueOnce(202);

    const result = await generateDiscussionPost(setting, 1, "manual");

    expect(result.success).toBe(true);
    expect(generateImage).not.toHaveBeenCalled();
  });
});
