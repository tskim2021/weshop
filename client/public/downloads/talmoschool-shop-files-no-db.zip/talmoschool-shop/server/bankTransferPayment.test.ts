import { describe, it, expect, beforeAll } from "vitest";
import * as db from "./db";
import { users, orders } from "../drizzle/schema";

describe("무통장 입금 결제 모듈", () => {
  let testBankAccountId: number;
  let testUserId: number;
  let testOrderId: number;
  let testPaymentId: number;

  beforeAll(async () => {
    // 테스트 사용자 생성
    const database = await db.getDb();
    if (!database) throw new Error("Database not available");

    const [{ id: userId }] = await database
      .insert(users)
      .values({
        openId: "test-bank-transfer-user",
        name: "무통장입금 테스트 사용자",
        email: "banktest@example.com",
        role: "user",
        grade: "bronze",
        points: 0,
      })
      .$returningId();
    testUserId = userId;

    // 테스트 계좌 생성
    const account = await db.createBankAccount({
      bankName: "테스트은행",
      accountNumber: "123-456-789",
      accountHolder: "테스트쇼핑몰",
      isActive: true,
    });
    testBankAccountId = account.id;
  });

  describe("계좌 관리", () => {
    it("계좌 목록 조회", async () => {
      const accounts = await db.getBankAccounts();
      expect(accounts.length).toBeGreaterThan(0);
      expect(accounts[0].bankName).toBe("테스트은행");
    });

    it("활성 계좌만 조회", async () => {
      const activeAccounts = await db.getActiveBankAccounts();
      expect(activeAccounts.every((acc) => acc.isActive)).toBe(true);
    });

    it("계좌 수정", async () => {
      const updated = await db.updateBankAccount(testBankAccountId, {
        bankName: "수정된은행",
      });
      expect(updated?.bankName).toBe("수정된은행");
    });

    it("계좌 삭제", async () => {
      const newAccount = await db.createBankAccount({
        bankName: "삭제테스트은행",
        accountNumber: "999-999-999",
        accountHolder: "테스트",
        isActive: false,
      });
      const deleted = await db.deleteBankAccount(newAccount.id);
      expect(deleted).toBe(true);
    });
  });

  describe("결제 생성 및 관리", () => {
    it("무통장 입금 결제 생성", async () => {
      // 테스트 주문 생성 (간단히 직접 DB 삽입)
      const database = await db.getDb();
      if (!database) throw new Error("Database not available");

      const [{ id: orderId }] = await database
        .insert(orders)
        .values({
          userId: testUserId,
          totalAmount: 50000,
          status: "pending",
          shippingName: "테스트",
          shippingPhone: "010-1234-5678",
          shippingAddress: "테스트 주소",
          shippingPostcode: "12345",
        })
        .$returningId();
      testOrderId = orderId;

      // 결제 생성
      const payment = await db.createPayment({
        orderId: testOrderId,
        userId: testUserId,
        method: "bank_transfer",
        depositAmount: 50000,
        bankAccountId: testBankAccountId,
        depositorName: "홍길동",
        status: "pending",
        expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000),
      });

      testPaymentId = payment.id;
      expect(payment.method).toBe("bank_transfer");
      expect(payment.status).toBe("pending");
      expect(payment.depositorName).toBe("홍길동");
    });

    it("결제 조회", async () => {
      const payment = await db.getPaymentById(testPaymentId);
      expect(payment).toBeDefined();
      expect(payment?.orderId).toBe(testOrderId);
    });

    it("주문별 결제 조회", async () => {
      const payment = await db.getPaymentByOrderId(testOrderId);
      expect(payment).toBeDefined();
      expect(payment?.id).toBe(testPaymentId);
    });

    it("입금 확인 처리", async () => {
      const confirmed = await db.confirmPayment(testPaymentId);
      expect(confirmed?.status).toBe("completed");
      expect(confirmed?.confirmedAt).toBeDefined();
    });

    it("입금 대기 목록 조회", async () => {
      // 새 결제 생성
      const database = await db.getDb();
      if (!database) throw new Error("Database not available");

      const [{ id: order2Id }] = await database
        .insert(orders)
        .values({
          userId: testUserId,
          totalAmount: 30000,
          status: "pending",
          shippingName: "테스트2",
          shippingPhone: "010-1234-5678",
          shippingAddress: "테스트 주소2",
          shippingPostcode: "12345",
        })
        .$returningId();

      await db.createPayment({
        orderId: order2Id,
        userId: testUserId,
        method: "bank_transfer",
        depositAmount: 30000,
        bankAccountId: testBankAccountId,
        depositorName: "김철수",
        status: "pending",
        expiresAt: new Date(Date.now() + 48 * 60 * 60 * 1000),
      });

      const pending = await db.getPendingPayments();
      expect(pending.length).toBeGreaterThan(0);
      expect(pending.some((p) => p.depositorName === "김철수")).toBe(true);
    });
  });

  describe("자동 취소 설정", () => {
    it("자동 취소 시간 조회", async () => {
      const hours = await db.getSetting("bankTransferAutoCancelHours");
      expect(hours).toBeDefined();
      // 기본값 48시간
      expect(Number(hours || 48)).toBeGreaterThan(0);
    });

    it("자동 취소 시간 변경", async () => {
      await db.setSetting("bankTransferAutoCancelHours", "24");
      const updated = await db.getSetting("bankTransferAutoCancelHours");
      expect(updated).toBe("24");

      // 원복
      await db.setSetting("bankTransferAutoCancelHours", "48");
    });
  });

  describe("만료된 결제 조회", () => {
    it("만료된 결제 목록 조회", async () => {
      // 과거 시간으로 만료된 결제 생성
      const database = await db.getDb();
      if (!database) throw new Error("Database not available");

      const [{ id: expiredOrderId }] = await database
        .insert(orders)
        .values({
          userId: testUserId,
          totalAmount: 10000,
          status: "pending",
          shippingName: "만료테스트",
          shippingPhone: "010-1234-5678",
          shippingAddress: "테스트 주소",
          shippingPostcode: "12345",
        })
        .$returningId();

      await db.createPayment({
        orderId: expiredOrderId,
        userId: testUserId,
        method: "bank_transfer",
        depositAmount: 10000,
        bankAccountId: testBankAccountId,
        depositorName: "만료테스트",
        status: "pending",
        expiresAt: new Date(Date.now() - 1000), // 1초 전 만료
      });

      const expired = await db.getExpiredPayments();
      expect(expired.length).toBeGreaterThan(0);
      expect(expired.some((p) => p.depositorName === "만료테스트")).toBe(true);
    });
  });
});
