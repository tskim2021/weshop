import { describe, it, expect } from "vitest";
import { isInternationalTrackingNumber, detectShippingType, needsKoreaPostCrawling } from "./trackingNumberUtils";

describe("trackingNumberUtils", () => {
  describe("isInternationalTrackingNumber", () => {
    it("should detect LP (Letter Post) tracking numbers", () => {
      expect(isInternationalTrackingNumber("LP081797327IN")).toBe(true);
      expect(isInternationalTrackingNumber("LP081795723IN")).toBe(true);
      expect(isInternationalTrackingNumber("LP057879048IN")).toBe(true);
      expect(isInternationalTrackingNumber("LP057823914IN")).toBe(true);
    });

    it("should detect RM (Registered Mail) tracking numbers", () => {
      expect(isInternationalTrackingNumber("RM767807288IN")).toBe(true);
      expect(isInternationalTrackingNumber("RM060772744IN")).toBe(true);
    });

    it("should detect EA/EM (EMS) tracking numbers", () => {
      expect(isInternationalTrackingNumber("EA123456789KR")).toBe(true);
      expect(isInternationalTrackingNumber("EM987654321JP")).toBe(true);
      expect(isInternationalTrackingNumber("EX123456789US")).toBe(true);
    });

    it("should detect CP (Parcel) tracking numbers", () => {
      expect(isInternationalTrackingNumber("CP123456789CN")).toBe(true);
      expect(isInternationalTrackingNumber("CX987654321DE")).toBe(true);
    });

    it("should detect RR (Registered) tracking numbers", () => {
      expect(isInternationalTrackingNumber("RR123456789FR")).toBe(true);
    });

    it("should reject domestic tracking numbers", () => {
      expect(isInternationalTrackingNumber("1234567890")).toBe(false);
      expect(isInternationalTrackingNumber("6000123456789")).toBe(false);
      expect(isInternationalTrackingNumber("BULK001")).toBe(false);
      expect(isInternationalTrackingNumber("BULK002")).toBe(false);
    });

    it("should reject invalid formats", () => {
      expect(isInternationalTrackingNumber("")).toBe(false);
      expect(isInternationalTrackingNumber("LP12345IN")).toBe(false); // 숫자 9자리 미만
      expect(isInternationalTrackingNumber("LP1234567890IN")).toBe(false); // 숫자 10자리
      expect(isInternationalTrackingNumber("XX123456789IN")).toBe(false); // XX는 유효한 서비스코드 아님
      expect(isInternationalTrackingNumber("AB123456789IN")).toBe(false); // AB는 유효한 서비스코드 아님
    });

    it("should handle case insensitivity via uppercase conversion", () => {
      expect(isInternationalTrackingNumber("lp081797327in")).toBe(true);
      expect(isInternationalTrackingNumber("Lp081797327In")).toBe(true);
    });

    it("should handle whitespace trimming", () => {
      expect(isInternationalTrackingNumber(" LP081797327IN ")).toBe(true);
      expect(isInternationalTrackingNumber("  RM767807288IN  ")).toBe(true);
    });
  });

  describe("detectShippingType", () => {
    it("should return international for international tracking numbers", () => {
      expect(detectShippingType("LP081797327IN")).toBe("international");
      expect(detectShippingType("RM767807288IN")).toBe("international");
      expect(detectShippingType("EA123456789KR")).toBe("international");
    });

    it("should return domestic for domestic tracking numbers", () => {
      expect(detectShippingType("1234567890")).toBe("domestic");
      expect(detectShippingType("6000123456789")).toBe("domestic");
    });

    it("should preserve current type for non-international numbers", () => {
      expect(detectShippingType("1234567890", "international")).toBe("international");
      expect(detectShippingType("1234567890", "domestic")).toBe("domestic");
    });

    it("should override current type for international numbers", () => {
      expect(detectShippingType("LP081797327IN", "domestic")).toBe("international");
    });
  });

  describe("needsKoreaPostCrawling", () => {
    it("should return true for international postal numbers", () => {
      expect(needsKoreaPostCrawling("LP081797327IN")).toBe(true);
      expect(needsKoreaPostCrawling("RM767807288IN")).toBe(true);
      expect(needsKoreaPostCrawling("EA123456789KR")).toBe(true);
    });

    it("should return false for domestic tracking numbers", () => {
      expect(needsKoreaPostCrawling("1234567890")).toBe(false);
      expect(needsKoreaPostCrawling("BULK001")).toBe(false);
    });
  });
});
