import { describe, it, expect } from "vitest";
import {
  cleanKoreaPostDetails,
  formatShippingDescription,
  buildKoreaPostDescription,
  mapStatusDisplay,
} from "./shippingDescriptionFormatter";

describe("mapStatusDisplay", () => {
  it("발송준비를 항공발송으로 변환", () => {
    expect(mapStatusDisplay("발송준비")).toBe("항공발송");
  });

  it("발송교환국에도착을 발송교환국 도착으로 변환", () => {
    expect(mapStatusDisplay("발송교환국에도착")).toBe("발송교환국 도착");
  });

  it("매핑에 없는 상태는 그대로 반환", () => {
    expect(mapStatusDisplay("접수")).toBe("접수");
    expect(mapStatusDisplay("배달완료")).toBe("배달완료");
    expect(mapStatusDisplay("통관검사대기")).toBe("통관검사대기");
  });
});

describe("cleanKoreaPostDetails", () => {
  it("접수 이벤트 details 정리", () => {
    const raw = "접수우체국우편번호 :\r, IN400099, \r, \r, \t\t\t    ,  중계국 또는 도착국가 : 대한민국(KR)";
    const result = cleanKoreaPostDetails(raw);
    expect(result).toBe("접수우체국우편번호 : IN400099 - 중계국 또는 도착국가 : 대한민국(KR)");
  });

  it("발송준비 이벤트 details 정리 - 불필요한 발송횟수/운송편명 제거", () => {
    const raw = "발송국 : INBOMA, \r, \r, \t\t\t                도착예정 교환국 : KRSELB(서울국제), \r, \r, \r, \t\t\t\t 발송횟수 : INBOMAKRSELBAUX60129 , \r, \t\t\t\t 운송편명 :";
    const result = cleanKoreaPostDetails(raw);
    expect(result).toBe("발송국 : INBOMA - 도착예정 교환국 : KRSELB(서울국제)");
  });

  it("통관검사대기 이벤트 details 정리", () => {
    const raw = "인천공항본부세관\r, \t\t\t\t\t\r, \t\t\t\t\t통관번호:242471";
    const result = cleanKoreaPostDetails(raw);
    expect(result).toContain("인천공항본부세관");
    expect(result).toContain("통관번호:242471");
    expect(result).not.toContain("\r");
    expect(result).not.toContain("\t");
  });

  it("배달준비 (집배원 정보 보기) 정리", () => {
    const raw = "배달준비 (집배원 정보 보기)";
    const result = cleanKoreaPostDetails(raw);
    expect(result).toBe("배달준비");
    expect(result).not.toContain("집배원 정보 보기");
  });

  it("배달준비를 배송 시작으로 변환", () => {
    expect(mapStatusDisplay("배달준비")).toBe("배송 시작");
  });

  it("교환국도착을 국내 도착으로 변환", () => {
    expect(mapStatusDisplay("교환국도착")).toBe("국내 도착");
  });

  it("교환국 도착(띄어쓰기)을 국내 도착으로 변환", () => {
    expect(mapStatusDisplay("교환국 도착")).toBe("국내 도착");
  });

  it("빈 문자열 처리", () => {
    expect(cleanKoreaPostDetails("")).toBe("");
  });

  it("정상 텍스트는 그대로 반환", () => {
    expect(cleanKoreaPostDetails("정상 텍스트")).toBe("정상 텍스트");
  });
});

describe("formatShippingDescription", () => {
  it("접수 이벤트 전체 description 포맷팅", () => {
    const raw = "접수 - IN400099 (접수우체국우편번호 :\r, IN400099, \r, \r, \t\t\t    ,  중계국 또는 도착국가 : 대한민국(KR))";
    const result = formatShippingDescription(raw);
    expect(result).toBe("접수 - IN400099 (접수우체국우편번호 : IN400099 - 중계국 또는 도착국가 : 대한민국(KR))");
  });

  it("발송준비를 항공발송으로 변환하고 details 정리", () => {
    const raw = "발송준비 - INBOMA (발송국 : INBOMA, \r, \r, \t\t\t                도착예정 교환국 : KRSELB(서울국제), \r, \r, \r, \t\t\t\t 발송횟수 : INBOMAKRSELBAUX60129 , \r, \t\t\t\t 운송편명 :)";
    const result = formatShippingDescription(raw);
    expect(result).toBe("항공발송 - INBOMA (발송국 : INBOMA - 도착예정 교환국 : KRSELB(서울국제))");
  });

  it("발송교환국에도착을 발송교환국 도착으로 변환", () => {
    const raw = "발송교환국에도착 - INBOMA";
    const result = formatShippingDescription(raw);
    expect(result).toBe("발송교환국 도착 - INBOMA");
  });

  it("통관검사대기 이벤트 포맷팅", () => {
    const raw = "통관검사대기 - 국제우편물류센터 (인천공항본부세관\r, \t\t\t\t\t\r, \t\t\t\t\t통관번호:242471)";
    const result = formatShippingDescription(raw);
    expect(result).toContain("통관검사대기 - 국제우편물류센터");
    expect(result).toContain("인천공항본부세관");
    expect(result).toContain("통관번호:242471");
    expect(result).not.toContain("\r");
    expect(result).not.toContain("\t");
  });

  it("배달준비 이벤트 포맷팅 - 집배원 정보 보기 제거 + 배송 시작으로 변환", () => {
    const raw = "배달준비 - 안산우체국 (배달준비 (집배원 정보 보기))";
    const result = formatShippingDescription(raw);
    expect(result).toBe("배송 시작 - 안산우체국 (배달준비)");
    expect(result).not.toContain("집배원 정보 보기");
  });

  it("배달완료 이벤트 포맷팅", () => {
    const raw = "배달완료 - 안산우체국 (배달우체국전화번호 : 031 -483-0014,   수령인 : 수**(우편수취함),   배달결과 : 배달)";
    const result = formatShippingDescription(raw);
    expect(result).toContain("배달완료 - 안산우체국");
    expect(result).toContain("배달우체국전화번호");
  });

  it("단순 상태 - 위치 형식 (details 없음)", () => {
    const raw = "도착 - 광주우편집중국";
    const result = formatShippingDescription(raw);
    expect(result).toBe("도착 - 광주우편집중국");
  });

  it("운송장 등록 메시지는 그대로", () => {
    const raw = "운송장이 등록되었습니다.";
    const result = formatShippingDescription(raw);
    expect(result).toBe("운송장이 등록되었습니다.");
  });

  it("빈 문자열 처리", () => {
    expect(formatShippingDescription("")).toBe("");
  });
});

describe("buildKoreaPostDescription", () => {
  it("접수 이벤트 description 생성", () => {
    const result = buildKoreaPostDescription(
      "접수",
      "IN400099",
      "접수우체국우편번호 :\nIN400099\n\n\t\t\t    \n 중계국 또는 도착국가 : 대한민국(KR)"
    );
    expect(result).toBe("접수 - IN400099 (접수우체국우편번호 : IN400099 - 중계국 또는 도착국가 : 대한민국(KR))");
  });

  it("발송준비 이벤트 description 생성 - 항공발송으로 변환", () => {
    const result = buildKoreaPostDescription(
      "발송준비",
      "INBOMA",
      "발송국 : INBOMA\n\n\t\t\t                도착예정 교환국 : KRSELB(서울국제)\n\n\n\t\t\t\t 발송횟수 : INBOMAKRSELBAUX60129 \n\t\t\t\t 운송편명 :"
    );
    expect(result).toBe("항공발송 - INBOMA (발송국 : INBOMA - 도착예정 교환국 : KRSELB(서울국제))");
  });

  it("details가 없는 경우", () => {
    const result = buildKoreaPostDescription("도착", "광주우편집중국", "");
    expect(result).toBe("도착 - 광주우편집중국");
  });

  it("발송교환국에도착 변환", () => {
    const result = buildKoreaPostDescription("발송교환국에도착", "INBOMA", "");
    expect(result).toBe("발송교환국 도착 - INBOMA");
  });
});
