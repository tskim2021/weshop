<?php
/**
 * 탈모2 연동 API - 상품 재고/상태 역반영
 * /page/talmo2_update_product.php
 *
 * POST body (JSON):
 * {
 *   "token": "SECRET",
 *   "it_id": "product_id",
 *   "it_stock_qty": 10,    // 재고 수량 (선택)
 *   "it_soldout": 0,       // 0=판매중, 1=품절 (선택)
 *   "it_use": 1            // 0=미사용, 1=사용 (선택)
 * }
 */

define('TALMO2_TOKEN', getenv('TALMO2_API_TOKEN') ?: 'CHANGE_ME_STRONG_SECRET');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Talmo2-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit;
}

$body = json_decode(file_get_contents('php://input'), true);
if (!$body) { http_response_code(400); echo json_encode(['error' => 'Invalid JSON']); exit; }

$token = $body['token'] ?? $_SERVER['HTTP_X_TALMO2_TOKEN'] ?? '';
if ($token !== TALMO2_TOKEN) { http_response_code(401); echo json_encode(['error' => 'Unauthorized']); exit; }

$it_id = trim($body['it_id'] ?? '');
if (!$it_id) { http_response_code(400); echo json_encode(['error' => 'it_id required']); exit; }

// DB 연결
$g5_path = dirname(__FILE__, 2);
if (file_exists($g5_path . '/lib/common.lib.php')) {
    @include_once $g5_path . '/lib/common.lib.php';
    $db = $GLOBALS['connect_db'] ?? null;
    if (!$db) { $db = new mysqli(G5_MYSQL_HOST, G5_MYSQL_USER, G5_MYSQL_PASSWORD, G5_MYSQL_DB); $db->set_charset('utf8mb4'); }
} else {
    $db = new mysqli(
        getenv('TALMO_MYSQL_HOST') ?: 'localhost',
        getenv('TALMO_MYSQL_USER') ?: 'root',
        getenv('TALMO_MYSQL_PASSWORD') ?: '',
        getenv('TALMO_MYSQL_DATABASE') ?: 'talmo2026'
    );
    $db->set_charset('utf8mb4');
}
if ($db->connect_errno) { http_response_code(500); echo json_encode(['error' => 'DB error']); exit; }

// 상품 존재 확인
$chk = $db->prepare("SELECT it_id FROM g5_shop_item WHERE it_id = ?");
$chk->bind_param('s', $it_id);
$chk->execute();
if ($chk->get_result()->num_rows === 0) {
    http_response_code(404); echo json_encode(['error' => "Product not found: $it_id"]); exit;
}

// 변경할 필드 동적으로 구성
$sets = [];
$params = [];
$types = '';

if (isset($body['it_stock_qty'])) {
    $sets[] = 'it_stock_qty = ?';
    $params[] = (int)$body['it_stock_qty'];
    $types .= 'i';
}
if (isset($body['it_soldout'])) {
    $sets[] = 'it_soldout = ?';
    $params[] = (int)$body['it_soldout'];
    $types .= 'i';
}
if (isset($body['it_use'])) {
    $sets[] = 'it_use = ?';
    $params[] = (int)$body['it_use'];
    $types .= 'i';
}

if (empty($sets)) {
    http_response_code(400); echo json_encode(['error' => 'No fields to update']); exit;
}

$params[] = $it_id;
$types .= 's';

$sql = "UPDATE g5_shop_item SET " . implode(', ', $sets) . " WHERE it_id = ?";
$stmt = $db->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();

echo json_encode([
    'success'  => true,
    'it_id'    => $it_id,
    'affected' => $stmt->affected_rows,
], JSON_UNESCAPED_UNICODE);
