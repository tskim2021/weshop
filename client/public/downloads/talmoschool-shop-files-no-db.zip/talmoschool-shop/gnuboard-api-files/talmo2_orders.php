<?php
/**
 * 탈모2 연동 API - 주문 목록 제공
 * 탈모학교 Gnuboard5 /page/talmo2_orders.php 에 업로드
 *
 * 호출 예시:
 *   GET /page/talmo2_orders.php?token=YOUR_TOKEN&since=2024-01-01T00:00:00&limit=200
 */

// ─── 설정 ───────────────────────────────────────────────
define('TALMO2_TOKEN', getenv('TALMO2_API_TOKEN') ?: 'CHANGE_ME_STRONG_SECRET');

// ─── 인증 ────────────────────────────────────────────────
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$token = $_GET['token'] ?? $_SERVER['HTTP_X_TALMO2_TOKEN'] ?? '';
if ($token !== TALMO2_TOKEN) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

// ─── 그누보드 연결 ────────────────────────────────────────
$g5_path = dirname(__FILE__, 2); // /page 에서 두 단계 위 = 그누보드 루트
if (!file_exists($g5_path . '/lib/common.lib.php') && !file_exists($g5_path . '/common.php')) {
    // fallback: 직접 DB 연결
    $db_host = getenv('TALMO_MYSQL_HOST') ?: 'localhost';
    $db_user = getenv('TALMO_MYSQL_USER') ?: 'root';
    $db_pass = getenv('TALMO_MYSQL_PASSWORD') ?: '';
    $db_name = getenv('TALMO_MYSQL_DATABASE') ?: 'talmo2026';
    $db = new mysqli($db_host, $db_user, $db_pass, $db_name);
    $db->set_charset('utf8mb4');
} else {
    // 그누보드 환경 활용
    @include_once $g5_path . '/lib/common.lib.php';
    $db = $GLOBALS['connect_db'] ?? null;
    if (!$db) {
        $db = new mysqli(G5_MYSQL_HOST, G5_MYSQL_USER, G5_MYSQL_PASSWORD, G5_MYSQL_DB);
        $db->set_charset('utf8mb4');
    }
}

if ($db->connect_errno) {
    http_response_code(500);
    echo json_encode(['error' => 'DB connection failed: ' . $db->connect_error]);
    exit;
}

// ─── 파라미터 ─────────────────────────────────────────────
$since = $_GET['since'] ?? ''; // ISO8601 또는 'YYYY-MM-DD HH:MM:SS'
$limit = max(1, min(500, (int)($_GET['limit'] ?? 200)));
$offset = max(0, (int)($_GET['offset'] ?? 0));

// ─── 주문 조회 ────────────────────────────────────────────
$where_since = '';
$params = [];
if ($since) {
    $since_dt = date('Y-m-d H:i:s', strtotime($since));
    $where_since = "WHERE o.od_time >= ?";
    $params[] = $since_dt;
}

$sql = "
    SELECT
        o.od_id, o.mb_id,
        o.od_name, o.od_tel, o.od_hp,
        o.od_b_name, o.od_b_tel, o.od_b_hp,
        o.od_zip1, o.od_zip2, o.od_b_zip1, o.od_b_zip2,
        o.od_addr1, o.od_addr2, o.od_addr3,
        o.od_b_addr1, o.od_b_addr2, o.od_b_addr3,
        o.od_memo, o.od_shop_memo,
        o.od_cart_price, o.od_send_cost, o.od_cart_coupon,
        o.od_receipt_point, o.od_settle_case, o.od_receipt_price,
        o.od_status, o.od_time,
        o.od_invoice, o.od_delivery_company,
        o.od_updated_at
    FROM g5_shop_order o
    $where_since
    ORDER BY o.od_time DESC
    LIMIT ? OFFSET ?
";
$params[] = $limit;
$params[] = $offset;

$stmt = $db->prepare($sql);
if (!$stmt) {
    // od_updated_at 컬럼이 없을 수도 있음 - fallback
    $sql2 = str_replace('o.od_updated_at', 'o.od_time AS od_updated_at', $sql);
    $stmt = $db->prepare($sql2);
}

if ($params) {
    $types = str_repeat('s', count($params) - 2) . 'ii';
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$order_rows = $result->fetch_all(MYSQLI_ASSOC);

// ─── 주문별 상품 조회 ─────────────────────────────────────
$od_ids = array_column($order_rows, 'od_id');
$items_by_order = [];
if ($od_ids) {
    $placeholders = implode(',', array_fill(0, count($od_ids), '?'));
    $item_sql = "SELECT od_id, it_id, it_name, ct_price, ct_qty, ct_option FROM g5_shop_cart WHERE od_id IN ($placeholders) AND od_id != ''";
    $istmt = $db->prepare($item_sql);
    $istmt->bind_param(str_repeat('s', count($od_ids)), ...$od_ids);
    $istmt->execute();
    $item_result = $istmt->get_result();
    while ($row = $item_result->fetch_assoc()) {
        $items_by_order[$row['od_id']][] = [
            'it_id'     => $row['it_id'],
            'it_name'   => $row['it_name'],
            'ct_price'  => (int)$row['ct_price'],
            'ct_qty'    => (int)$row['ct_qty'],
            'ct_option' => $row['ct_option'],
        ];
    }
}

// ─── 응답 조립 ────────────────────────────────────────────
$orders = [];
foreach ($order_rows as $o) {
    $orders[] = [
        'od_id'              => $o['od_id'],
        'mb_id'              => $o['mb_id'],
        'od_name'            => $o['od_name'],
        'od_hp'              => $o['od_hp'] ?: $o['od_tel'],
        'od_b_name'          => $o['od_b_name'],
        'od_b_hp'            => $o['od_b_hp'] ?: $o['od_b_tel'],
        'od_b_zip'           => ($o['od_b_zip1'] ?? '') . ($o['od_b_zip2'] ?? ''),
        'od_b_addr1'         => $o['od_b_addr1'],
        'od_b_addr2'         => $o['od_b_addr2'],
        'od_b_addr3'         => $o['od_b_addr3'],
        'od_memo'            => $o['od_memo'],
        'od_shop_memo'       => $o['od_shop_memo'],
        'od_cart_price'      => (int)$o['od_cart_price'],
        'od_send_cost'       => (int)$o['od_send_cost'],
        'od_cart_coupon'     => (int)$o['od_cart_coupon'],
        'od_receipt_point'   => (int)$o['od_receipt_point'],
        'od_settle_case'     => $o['od_settle_case'],
        'od_receipt_price'   => (int)$o['od_receipt_price'],
        'od_status'          => $o['od_status'],
        'od_time'            => $o['od_time'],
        'od_updated_at'      => $o['od_updated_at'] ?? $o['od_time'],
        'od_invoice'         => $o['od_invoice'],
        'od_delivery_company'=> $o['od_delivery_company'],
        'items'              => $items_by_order[$o['od_id']] ?? [],
    ];
}

// 전체 개수
$count_sql = "SELECT COUNT(*) as cnt FROM g5_shop_order " . ($where_since ? "WHERE od_time >= ?" : "");
$cstmt = $db->prepare($count_sql);
if ($where_since) {
    $cstmt->bind_param('s', $since_dt);
}
$cstmt->execute();
$count_row = $cstmt->get_result()->fetch_assoc();

echo json_encode([
    'success' => true,
    'total'   => (int)($count_row['cnt'] ?? 0),
    'limit'   => $limit,
    'offset'  => $offset,
    'orders'  => $orders,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
