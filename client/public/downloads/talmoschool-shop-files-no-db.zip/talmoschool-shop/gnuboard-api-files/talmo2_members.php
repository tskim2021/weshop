<?php
/**
 * 탈모2 연동 API - 회원 목록 제공
 * /page/talmo2_members.php
 */

define('TALMO2_TOKEN', getenv('TALMO2_API_TOKEN') ?: 'CHANGE_ME_STRONG_SECRET');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$token = $_GET['token'] ?? $_SERVER['HTTP_X_TALMO2_TOKEN'] ?? '';
if ($token !== TALMO2_TOKEN) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$g5_path = dirname(__FILE__, 2);
if (file_exists($g5_path . '/lib/common.lib.php')) {
    @include_once $g5_path . '/lib/common.lib.php';
    $db = $GLOBALS['connect_db'] ?? null;
    if (!$db) {
        $db = new mysqli(G5_MYSQL_HOST, G5_MYSQL_USER, G5_MYSQL_PASSWORD, G5_MYSQL_DB);
        $db->set_charset('utf8mb4');
    }
} else {
    $db = new mysqli(
        getenv('TALMO_MYSQL_HOST') ?: 'localhost',
        getenv('TALMO_MYSQL_USER') ?: 'root',
        getenv('TALMO_MYSQL_PASSWORD') ?: '',
        getenv('TALMO_MYSQL_DATABASE') ?: 'talmo2026'
    );
    $db->set_charset('utf8mb4');
}

if ($db->connect_errno) {
    http_response_code(500);
    echo json_encode(['error' => 'DB connection failed']);
    exit;
}

$since = $_GET['since'] ?? '';
$limit = max(1, min(1000, (int)($_GET['limit'] ?? 500)));
$offset = max(0, (int)($_GET['offset'] ?? 0));

$where = "WHERE mb_leave_date='' AND mb_intercept_date=''";
if ($since) {
    $since_dt = date('Y-m-d H:i:s', strtotime($since));
    $where .= " AND mb_datetime >= '" . $db->real_escape_string($since_dt) . "'";
}

$sql = "
    SELECT mb_id, mb_password, mb_name, mb_nick, mb_email, mb_hp, mb_tel,
           mb_level, mb_point, mb_datetime, mb_today_login
    FROM g5_member
    $where
    ORDER BY mb_datetime DESC
    LIMIT $limit OFFSET $offset
";

$result = $db->query($sql);
$members = [];
while ($row = $result->fetch_assoc()) {
    $members[] = [
        'mb_id'         => $row['mb_id'],
        'mb_password'   => $row['mb_password'],
        'mb_name'       => $row['mb_name'],
        'mb_nick'       => $row['mb_nick'],
        'mb_email'      => $row['mb_email'],
        'mb_hp'         => $row['mb_hp'],
        'mb_tel'        => $row['mb_tel'],
        'mb_level'      => (int)$row['mb_level'],
        'mb_point'      => (int)$row['mb_point'],
        'mb_datetime'   => $row['mb_datetime'],
        'mb_today_login'=> $row['mb_today_login'],
    ];
}

$count_result = $db->query("SELECT COUNT(*) as cnt FROM g5_member $where");
$total = (int)($count_result->fetch_assoc()['cnt'] ?? 0);

echo json_encode([
    'success' => true,
    'total'   => $total,
    'limit'   => $limit,
    'offset'  => $offset,
    'members' => $members,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
