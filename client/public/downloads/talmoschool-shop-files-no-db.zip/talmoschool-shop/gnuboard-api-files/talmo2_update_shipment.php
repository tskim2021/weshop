<?php
/**
 * 탈모2 연동 API - 배송 상태/송장 역반영
 * /page/talmo2_update_shipment.php
 *
 * 탈모2에서 배송처리 후 이 엔드포인트를 POST로 호출
 *
 * POST body (JSON):
 * {
 *   "token": "SECRET",
 *   "od_id": "20240101123456789",       // 그누보드 주문번호 (GNU- 접두사 제외)
 *   "od_status": "배송",               // 그누보드 상태값
 *   "od_invoice": "1234567890",         // 송장번호
 *   "od_delivery_company": "CJ대한통운"
 * }
 */

define('TALMO2_TOKEN', getenv('TALMO2_API_TOKEN') ?: 'CHANGE_ME_STRONG_SECRET');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Talmo2-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

$body = json_decode(file_get_contents('php://input'), true);
if (!$body) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON body']);
    exit;
}

$token = $body['token'] ?? $_SERVER['HTTP_X_TALMO2_TOKEN'] ?? '';
if ($token !== TALMO2_TOKEN) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$od_id = trim($body['od_id'] ?? '');
$od_status = trim($body['od_status'] ?? '');
$od_invoice = trim($body['od_invoice'] ?? '');
$od_delivery_company = trim($body['od_delivery_company'] ?? '');

if (!$od_id || !$od_status) {
    http_response_code(400);
    echo json_encode(['error' => 'od_id and od_status are required']);
    exit;
}

// 허용된 상태값만 허용
$allowed_statuses = ['주문', '입금', '준비', '배송', '완료', '취소', '환불'];
if (!in_array($od_status, $allowed_statuses)) {
    http_response_code(400);
    echo json_encode(['error' => "Invalid od_status. Allowed: " . implode(', ', $allowed_statuses)]);
    exit;
}

$g5_path = dirname(__FILE__, 2);
if (file_exists($g5_path . '/lib/common.lib.php')) {
    @include_once $g5_path . '/lib/common.lib.php';
    $db = $GLOBALS['connect_db'] ?? null;
    if (!$db) {
        $db = new mysqli(G5_MYSQL_HOST, G5_MYSQL_USER, G5_MYSQL_PASSWORD, G5_MYSQL_DB);
        $db->set_charset('utf8mb4');
    }
} else {
    $db = new mysqli(
        getenv('TALMO_MYSQL_HOST') ?: 'localhost',
        getenv('TALMO_MYSQL_USER') ?: 'root',
        getenv('TALMO_MYSQL_PASSWORD') ?: '',
        getenv('TALMO_MYSQL_DATABASE') ?: 'talmo2026'
    );
    $db->set_charset('utf8mb4');
}

if ($db->connect_errno) {
    http_response_code(500);
    echo json_encode(['error' => 'DB connection failed: ' . $db->connect_error]);
    exit;
}

// 주문 존재 확인
$check = $db->prepare("SELECT od_id FROM g5_shop_order WHERE od_id = ?");
$check->bind_param('s', $od_id);
$check->execute();
$check_result = $check->get_result();
if ($check_result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(['error' => "Order not found: $od_id"]);
    exit;
}

// 업데이트
if ($od_invoice) {
    $stmt = $db->prepare("UPDATE g5_shop_order SET od_status=?, od_invoice=?, od_delivery_company=? WHERE od_id=?");
    $stmt->bind_param('ssss', $od_status, $od_invoice, $od_delivery_company, $od_id);
} else {
    $stmt = $db->prepare("UPDATE g5_shop_order SET od_status=? WHERE od_id=?");
    $stmt->bind_param('ss', $od_status, $od_id);
}

if (!$stmt->execute()) {
    http_response_code(500);
    echo json_encode(['error' => 'Update failed: ' . $stmt->error]);
    exit;
}

echo json_encode([
    'success'   => true,
    'od_id'     => $od_id,
    'od_status' => $od_status,
    'od_invoice'=> $od_invoice,
    'updated'   => $stmt->affected_rows,
], JSON_UNESCAPED_UNICODE);
