<?php
/**
 * 탈모2 연동 API - 주문 상태/메모/입금 역반영
 * /page/talmo2_update_order.php
 *
 * POST body (JSON):
 * {
 *   "token": "SECRET",
 *   "od_id": "20240101123456789",
 *   "action": "status" | "confirm_payment" | "memo" | "cancel",
 *   "od_status": "주문|입금|준비|배송|완료|취소|환불",   // action=status 시
 *   "od_shop_memo": "관리자 메모",                       // action=memo 시
 *   "od_invoice": "1234567890",                         // 선택
 *   "od_delivery_company": "CJ대한통운"                 // 선택
 * }
 */

define('TALMO2_TOKEN', getenv('TALMO2_API_TOKEN') ?: 'CHANGE_ME_STRONG_SECRET');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Talmo2-Token');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error' => 'Method not allowed']); exit;
}

$body = json_decode(file_get_contents('php://input'), true);
if (!$body) { http_response_code(400); echo json_encode(['error' => 'Invalid JSON']); exit; }

$token = $body['token'] ?? $_SERVER['HTTP_X_TALMO2_TOKEN'] ?? '';
if ($token !== TALMO2_TOKEN) { http_response_code(401); echo json_encode(['error' => 'Unauthorized']); exit; }

$od_id  = trim($body['od_id'] ?? '');
$action = trim($body['action'] ?? 'status');

if (!$od_id) { http_response_code(400); echo json_encode(['error' => 'od_id required']); exit; }

// DB 연결
$g5_path = dirname(__FILE__, 2);
if (file_exists($g5_path . '/lib/common.lib.php')) {
    @include_once $g5_path . '/lib/common.lib.php';
    $db = $GLOBALS['connect_db'] ?? null;
    if (!$db) { $db = new mysqli(G5_MYSQL_HOST, G5_MYSQL_USER, G5_MYSQL_PASSWORD, G5_MYSQL_DB); $db->set_charset('utf8mb4'); }
} else {
    $db = new mysqli(
        getenv('TALMO_MYSQL_HOST') ?: 'localhost',
        getenv('TALMO_MYSQL_USER') ?: 'root',
        getenv('TALMO_MYSQL_PASSWORD') ?: '',
        getenv('TALMO_MYSQL_DATABASE') ?: 'talmo2026'
    );
    $db->set_charset('utf8mb4');
}
if ($db->connect_errno) { http_response_code(500); echo json_encode(['error' => 'DB error: ' . $db->connect_error]); exit; }

// 주문 존재 확인
$chk = $db->prepare("SELECT od_id, od_status, mb_id FROM g5_shop_order WHERE od_id = ?");
$chk->bind_param('s', $od_id);
$chk->execute();
$chk_row = $chk->get_result()->fetch_assoc();
if (!$chk_row) { http_response_code(404); echo json_encode(['error' => "Order not found: $od_id"]); exit; }

$allowed = ['주문','입금','준비','배송','완료','취소','환불'];
$affected = 0;

if ($action === 'status') {
    $od_status = trim($body['od_status'] ?? '');
    if (!in_array($od_status, $allowed)) {
        http_response_code(400); echo json_encode(['error' => 'Invalid od_status']); exit;
    }
    $od_invoice          = trim($body['od_invoice'] ?? '');
    $od_delivery_company = trim($body['od_delivery_company'] ?? '');
    if ($od_invoice) {
        $stmt = $db->prepare("UPDATE g5_shop_order SET od_status=?, od_invoice=?, od_delivery_company=? WHERE od_id=?");
        $stmt->bind_param('ssss', $od_status, $od_invoice, $od_delivery_company, $od_id);
    } else {
        $stmt = $db->prepare("UPDATE g5_shop_order SET od_status=? WHERE od_id=?");
        $stmt->bind_param('ss', $od_status, $od_id);
    }
    $stmt->execute();
    $affected = $stmt->affected_rows;

} elseif ($action === 'confirm_payment') {
    // 입금 확인: 상태를 "입금"으로, od_receipt_price를 실입금액으로 설정
    $receipt_price = (int)($body['receipt_price'] ?? 0);
    if ($receipt_price > 0) {
        $stmt = $db->prepare("UPDATE g5_shop_order SET od_status='입금', od_receipt_price=? WHERE od_id=?");
        $stmt->bind_param('is', $receipt_price, $od_id);
    } else {
        $stmt = $db->prepare("UPDATE g5_shop_order SET od_status='입금' WHERE od_id=?");
        $stmt->bind_param('s', $od_id);
    }
    $stmt->execute();
    $affected = $stmt->affected_rows;

} elseif ($action === 'memo') {
    $memo = $body['od_shop_memo'] ?? '';
    $stmt = $db->prepare("UPDATE g5_shop_order SET od_shop_memo=? WHERE od_id=?");
    $stmt->bind_param('ss', $memo, $od_id);
    $stmt->execute();
    $affected = $stmt->affected_rows;

} elseif ($action === 'cancel') {
    $stmt = $db->prepare("UPDATE g5_shop_order SET od_status='취소' WHERE od_id=?");
    $stmt->bind_param('s', $od_id);
    $stmt->execute();
    $affected = $stmt->affected_rows;

} else {
    http_response_code(400); echo json_encode(['error' => "Unknown action: $action"]); exit;
}

echo json_encode([
    'success'  => true,
    'od_id'    => $od_id,
    'action'   => $action,
    'affected' => $affected,
], JSON_UNESCAPED_UNICODE);
