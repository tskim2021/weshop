<?php
/**
 * 탈모2 연동 API - 상품/재고 목록 제공
 * /page/talmo2_products.php
 */

define('TALMO2_TOKEN', getenv('TALMO2_API_TOKEN') ?: 'CHANGE_ME_STRONG_SECRET');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$token = $_GET['token'] ?? $_SERVER['HTTP_X_TALMO2_TOKEN'] ?? '';
if ($token !== TALMO2_TOKEN) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$g5_path = dirname(__FILE__, 2);
if (file_exists($g5_path . '/lib/common.lib.php')) {
    @include_once $g5_path . '/lib/common.lib.php';
    $db = $GLOBALS['connect_db'] ?? null;
    if (!$db) {
        $db = new mysqli(G5_MYSQL_HOST, G5_MYSQL_USER, G5_MYSQL_PASSWORD, G5_MYSQL_DB);
        $db->set_charset('utf8mb4');
    }
} else {
    $db = new mysqli(
        getenv('TALMO_MYSQL_HOST') ?: 'localhost',
        getenv('TALMO_MYSQL_USER') ?: 'root',
        getenv('TALMO_MYSQL_PASSWORD') ?: '',
        getenv('TALMO_MYSQL_DATABASE') ?: 'talmo2026'
    );
    $db->set_charset('utf8mb4');
}

if ($db->connect_errno) {
    http_response_code(500);
    echo json_encode(['error' => 'DB connection failed']);
    exit;
}

$img_base = 'https://talmoschool.com/data/item';

// 카테고리
$cats = [];
$cat_result = $db->query("SELECT ca_id, ca_name, ca_order FROM g5_shop_category WHERE ca_use=1 ORDER BY ca_order, ca_id");
while ($row = $cat_result->fetch_assoc()) {
    $cats[] = $row;
}

// 상품
$items = [];
$item_result = $db->query("
    SELECT it_id, ca_id, it_name, it_basic, it_explan,
           it_cust_price, it_price, it_stock_qty, it_soldout, it_use,
           it_hit, it_order,
           it_img1, it_img2, it_img3, it_img4, it_img5,
           it_img6, it_img7, it_img8, it_img9, it_img10
    FROM g5_shop_item ORDER BY it_order, it_id
");
while ($row = $item_result->fetch_assoc()) {
    $imgs = [];
    for ($i = 1; $i <= 10; $i++) {
        $img = trim($row["it_img$i"] ?? '');
        if ($img) $imgs[] = "$img_base/$img";
    }
    $items[] = [
        'it_id'         => $row['it_id'],
        'ca_id'         => $row['ca_id'],
        'it_name'       => $row['it_name'],
        'it_basic'      => $row['it_basic'],
        'it_cust_price' => (int)$row['it_cust_price'],
        'it_price'      => (int)$row['it_price'],
        'it_stock_qty'  => (int)$row['it_stock_qty'],
        'it_soldout'    => (int)$row['it_soldout'],
        'it_use'        => (int)$row['it_use'],
        'it_hit'        => (int)$row['it_hit'],
        'it_order'      => (int)$row['it_order'],
        'images'        => $imgs,
    ];
}

// 옵션
$opts = [];
$opt_result = $db->query("SELECT it_id, io_id, io_price, io_stock_qty FROM g5_shop_item_option WHERE io_use=1 ORDER BY it_id, io_no");
while ($row = $opt_result->fetch_assoc()) {
    $opts[$row['it_id']][] = [
        'io_id'       => $row['io_id'],
        'io_price'    => (int)$row['io_price'],
        'io_stock_qty'=> (int)$row['io_stock_qty'],
    ];
}

echo json_encode([
    'success'    => true,
    'categories' => $cats,
    'products'   => $items,
    'options'    => $opts,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
